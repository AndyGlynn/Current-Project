Public Class Class2

End Class
