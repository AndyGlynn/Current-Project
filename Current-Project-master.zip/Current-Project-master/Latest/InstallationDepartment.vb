Public Class InstallationDepartment

End Class