﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestingForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.cboDataTables = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cboFormat = New System.Windows.Forms.ComboBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lsProdEX = New System.Windows.Forms.ListView()
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCat = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMeasurement = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.cboProd1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnTestGetMarketers = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboGetMarketers = New System.Windows.Forms.ComboBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboPLS = New System.Windows.Forms.ComboBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.cboSLS = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtValidatePHONE = New System.Windows.Forms.MaskedTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtValidateEmail = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.txtMM = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtValidateTest = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtStAddress = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.cboIPs = New System.Windows.Forms.ComboBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtSQL = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtNetwork = New System.Windows.Forms.TextBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtHostName = New System.Windows.Forms.TextBox()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.lblTempPath = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1064, 622)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox6)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1056, 596)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "sqlOperations"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Button21)
        Me.GroupBox6.Controls.Add(Me.Button16)
        Me.GroupBox6.Controls.Add(Me.Label31)
        Me.GroupBox6.Controls.Add(Me.cboDataTables)
        Me.GroupBox6.Controls.Add(Me.Label29)
        Me.GroupBox6.Controls.Add(Me.cboFormat)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Location = New System.Drawing.Point(20, 302)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(337, 219)
        Me.GroupBox6.TabIndex = 22
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "sqlOperations.ExportData"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(237, 94)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(75, 23)
        Me.Button21.TabIndex = 8
        Me.Button21.Text = "Open DIR"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(237, 65)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(75, 23)
        Me.Button16.TabIndex = 7
        Me.Button16.Text = "Test"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(7, 95)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(65, 13)
        Me.Label31.TabIndex = 6
        Me.Label31.Text = "What Data :"
        '
        'cboDataTables
        '
        Me.cboDataTables.FormattingEnabled = True
        Me.cboDataTables.Location = New System.Drawing.Point(78, 92)
        Me.cboDataTables.Name = "cboDataTables"
        Me.cboDataTables.Size = New System.Drawing.Size(124, 21)
        Me.cboDataTables.TabIndex = 5
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(7, 68)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(45, 13)
        Me.Label29.TabIndex = 2
        Me.Label29.Text = "Format :"
        '
        'cboFormat
        '
        Me.cboFormat.FormattingEnabled = True
        Me.cboFormat.Items.AddRange(New Object() {"XML", "CSV", "JSON"})
        Me.cboFormat.Location = New System.Drawing.Point(78, 65)
        Me.cboFormat.Name = "cboFormat"
        Me.cboFormat.Size = New System.Drawing.Size(124, 21)
        Me.cboFormat.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 31)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(160, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Export Data ( format , whatdata )"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button8)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.lsProdEX)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Button7)
        Me.GroupBox3.Controls.Add(Me.cboProd1)
        Me.GroupBox3.Location = New System.Drawing.Point(373, 20)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(569, 276)
        Me.GroupBox3.TabIndex = 21
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "sqlOperations.Products"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(478, 200)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 23)
        Me.Button8.TabIndex = 14
        Me.Button8.Text = "Test"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 205)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(88, 13)
        Me.Label18.TabIndex = 13
        Me.Label18.Text = "Insert Product ( ) "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 57)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(113, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "GetProdEX ( ProdCat )"
        '
        'lsProdEX
        '
        Me.lsProdEX.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colID, Me.colCat, Me.colName, Me.colModel, Me.colMeasurement})
        Me.lsProdEX.Location = New System.Drawing.Point(125, 54)
        Me.lsProdEX.Name = "lsProdEX"
        Me.lsProdEX.Size = New System.Drawing.Size(428, 97)
        Me.lsProdEX.TabIndex = 11
        Me.lsProdEX.UseCompatibleStateImageBehavior = False
        Me.lsProdEX.View = System.Windows.Forms.View.Details
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 39
        '
        'colCat
        '
        Me.colCat.Text = "Category"
        Me.colCat.Width = 95
        '
        'colName
        '
        Me.colName.Text = "Name"
        Me.colName.Width = 74
        '
        'colModel
        '
        Me.colModel.Text = "Model"
        Me.colModel.Width = 115
        '
        'colMeasurement
        '
        Me.colMeasurement.Text = "Unit Of Measure"
        Me.colMeasurement.Width = 95
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 27)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(81, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "GetProducts ( ) "
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(478, 22)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "Test"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'cboProd1
        '
        Me.cboProd1.FormattingEnabled = True
        Me.cboProd1.Location = New System.Drawing.Point(125, 22)
        Me.cboProd1.Name = "cboProd1"
        Me.cboProd1.Size = New System.Drawing.Size(181, 21)
        Me.cboProd1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Button9)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.btnTestGetMarketers)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.cboGetMarketers)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Location = New System.Drawing.Point(20, 20)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(337, 276)
        Me.GroupBox2.TabIndex = 20
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "sqlOperations.MarketerOperations"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(23, 230)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(284, 13)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "InsertMarketer ( fname, lname , mname,  job title, cell , Ext )"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(237, 246)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 9
        Me.Button9.Text = "Test"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "GetMarketers()"
        '
        'btnTestGetMarketers
        '
        Me.btnTestGetMarketers.Location = New System.Drawing.Point(237, 22)
        Me.btnTestGetMarketers.Name = "btnTestGetMarketers"
        Me.btnTestGetMarketers.Size = New System.Drawing.Size(75, 23)
        Me.btnTestGetMarketers.TabIndex = 0
        Me.btnTestGetMarketers.Text = "Test"
        Me.btnTestGetMarketers.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 188)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(202, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "PullMarketerInfoSingle ( FName, LName )"
        '
        'cboGetMarketers
        '
        Me.cboGetMarketers.FormattingEnabled = True
        Me.cboGetMarketers.Location = New System.Drawing.Point(24, 54)
        Me.cboGetMarketers.Name = "cboGetMarketers"
        Me.cboGetMarketers.Size = New System.Drawing.Size(288, 21)
        Me.cboGetMarketers.TabIndex = 2
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(237, 183)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "Test"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(237, 103)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Test"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 142)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "FormatPhone ( telnum )"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Capitalize ( text to cap )"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(237, 142)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Test"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.cboPLS)
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.cboSLS)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Location = New System.Drawing.Point(373, 302)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(569, 219)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "sqlOperations.LeadSources"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 33)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Get Primaries"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(26, 184)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(177, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "SecondaryLeadSource ( PLS, SLS )"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(478, 145)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Test"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(480, 182)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 17
        Me.Button6.Text = "Test"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "PrimaryLeadSource ( PLS )"
        '
        'cboPLS
        '
        Me.cboPLS.FormattingEnabled = True
        Me.cboPLS.Location = New System.Drawing.Point(359, 70)
        Me.cboPLS.Name = "cboPLS"
        Me.cboPLS.Size = New System.Drawing.Size(194, 21)
        Me.cboPLS.TabIndex = 11
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(478, 31)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "Test"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'cboSLS
        '
        Me.cboSLS.FormattingEnabled = True
        Me.cboSLS.Location = New System.Drawing.Point(359, 107)
        Me.cboSLS.Name = "cboSLS"
        Me.cboSLS.Size = New System.Drawing.Size(194, 21)
        Me.cboSLS.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 107)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Secondary"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Primary"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1056, 596)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Enter Lead Operations"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtValidatePHONE)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.txtValidateEmail)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.txtCode)
        Me.GroupBox4.Controls.Add(Me.txtMM)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.txtValidateTest)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Location = New System.Drawing.Point(15, 15)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(299, 284)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "utilityOperations.vb"
        '
        'txtValidatePHONE
        '
        Me.txtValidatePHONE.Location = New System.Drawing.Point(94, 250)
        Me.txtValidatePHONE.Mask = "(999) 000-0000"
        Me.txtValidatePHONE.Name = "txtValidatePHONE"
        Me.txtValidatePHONE.Size = New System.Drawing.Size(79, 20)
        Me.txtValidatePHONE.TabIndex = 10
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(9, 229)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(249, 13)
        Me.Label17.TabIndex = 9
        Me.Label17.Text = "Validate_PHONE ( phonenum )   ||  onLostFocus ( ) " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtValidateEmail
        '
        Me.txtValidateEmail.Location = New System.Drawing.Point(6, 190)
        Me.txtValidateEmail.Name = "txtValidateEmail"
        Me.txtValidateEmail.Size = New System.Drawing.Size(275, 20)
        Me.txtValidateEmail.TabIndex = 8
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 170)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(230, 13)
        Me.Label16.TabIndex = 7
        Me.Label16.Text = "Validate_EMAIL ( address )   ||  onLostFocus ( ) " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 26)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(93, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Capitalize ( what ) "
        '
        'txtCode
        '
        Me.txtCode.Location = New System.Drawing.Point(9, 136)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(272, 20)
        Me.txtCode.TabIndex = 6
        '
        'txtMM
        '
        Me.txtMM.Location = New System.Drawing.Point(105, 26)
        Me.txtMM.Name = "txtMM"
        Me.txtMM.Size = New System.Drawing.Size(176, 20)
        Me.txtMM.TabIndex = 1
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 117)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(120, 13)
        Me.Label15.TabIndex = 5
        Me.Label15.Text = "Only A-Z , a-z , 0-9 valid"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 71)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(153, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Validate Text Input ( keyCode )" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtValidateTest
        '
        Me.txtValidateTest.Location = New System.Drawing.Point(229, 71)
        Me.txtValidateTest.Name = "txtValidateTest"
        Me.txtValidateTest.Size = New System.Drawing.Size(52, 20)
        Me.txtValidateTest.TabIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 97)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(253, 13)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "OnKeyUp ( validateString ( input ) )  | OnKeyDown ( )"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1056, 596)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "mappingOperations.vb"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button15)
        Me.GroupBox5.Controls.Add(Me.Button14)
        Me.GroupBox5.Controls.Add(Me.Button13)
        Me.GroupBox5.Controls.Add(Me.Button12)
        Me.GroupBox5.Controls.Add(Me.Button11)
        Me.GroupBox5.Controls.Add(Me.txtZip)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Controls.Add(Me.txtState)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.Button10)
        Me.GroupBox5.Controls.Add(Me.txtCity)
        Me.GroupBox5.Controls.Add(Me.Label21)
        Me.GroupBox5.Controls.Add(Me.txtStAddress)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Location = New System.Drawing.Point(15, 16)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(399, 251)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Mappoint 2013 Functions / Subs"
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(149, 222)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(234, 23)
        Me.Button15.TabIndex = 13
        Me.Button15.Text = "Show %TEMP% Directory For Maps"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(18, 222)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(125, 23)
        Me.Button14.TabIndex = 12
        Me.Button14.Text = "Kill All Mappoint's"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(18, 197)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(125, 23)
        Me.Button13.TabIndex = 11
        Me.Button13.Text = "View Google Maps"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(149, 197)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(234, 23)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "View Scrubbed Address ( No Map )"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(149, 168)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(234, 23)
        Me.Button11.TabIndex = 9
        Me.Button11.Text = "View Map Centered (Push Pin Balloon)"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(133, 132)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(250, 20)
        Me.txtZip.TabIndex = 8
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(15, 135)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(31, 13)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Zip : "
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(133, 96)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(250, 20)
        Me.txtState.TabIndex = 6
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(15, 99)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(41, 13)
        Me.Label22.TabIndex = 5
        Me.Label22.Text = "State : "
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(18, 168)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(125, 23)
        Me.Button10.TabIndex = 4
        Me.Button10.Text = "View Map Centered"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(133, 60)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(250, 20)
        Me.txtCity.TabIndex = 3
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(15, 63)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(33, 13)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "City : "
        '
        'txtStAddress
        '
        Me.txtStAddress.Location = New System.Drawing.Point(133, 27)
        Me.txtStAddress.Name = "txtStAddress"
        Me.txtStAddress.Size = New System.Drawing.Size(250, 20)
        Me.txtStAddress.TabIndex = 1
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(15, 30)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(82, 13)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Street Address: "
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1056, 596)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "networkOperations.vb"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txtUser)
        Me.GroupBox7.Controls.Add(Me.Button23)
        Me.GroupBox7.Controls.Add(Me.Label32)
        Me.GroupBox7.Controls.Add(Me.cboIPs)
        Me.GroupBox7.Controls.Add(Me.Button20)
        Me.GroupBox7.Controls.Add(Me.Label28)
        Me.GroupBox7.Controls.Add(Me.txtSQL)
        Me.GroupBox7.Controls.Add(Me.Button19)
        Me.GroupBox7.Controls.Add(Me.Label27)
        Me.GroupBox7.Controls.Add(Me.txtNetwork)
        Me.GroupBox7.Controls.Add(Me.Button18)
        Me.GroupBox7.Controls.Add(Me.Label26)
        Me.GroupBox7.Controls.Add(Me.txtHostName)
        Me.GroupBox7.Controls.Add(Me.Button17)
        Me.GroupBox7.Controls.Add(Me.Label25)
        Me.GroupBox7.Location = New System.Drawing.Point(19, 20)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(405, 212)
        Me.GroupBox7.TabIndex = 0
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Host Information"
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(191, 179)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(100, 20)
        Me.txtUser.TabIndex = 14
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(309, 177)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(75, 23)
        Me.Button23.TabIndex = 13
        Me.Button23.Text = "Test"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(26, 182)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(136, 13)
        Me.Label32.TabIndex = 12
        Me.Label32.Text = "GET_CURRENT_USER ( )"
        '
        'cboIPs
        '
        Me.cboIPs.FormattingEnabled = True
        Me.cboIPs.Location = New System.Drawing.Point(170, 143)
        Me.cboIPs.Name = "cboIPs"
        Me.cboIPs.Size = New System.Drawing.Size(121, 21)
        Me.cboIPs.TabIndex = 11
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(309, 141)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(75, 23)
        Me.Button20.TabIndex = 10
        Me.Button20.Text = "Test"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(26, 146)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(140, 13)
        Me.Label28.TabIndex = 9
        Me.Label28.Text = "Get_IPV4 ( machine name ) "
        '
        'txtSQL
        '
        Me.txtSQL.Location = New System.Drawing.Point(220, 105)
        Me.txtSQL.Name = "txtSQL"
        Me.txtSQL.Size = New System.Drawing.Size(71, 20)
        Me.txtSQL.TabIndex = 8
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(309, 103)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(75, 23)
        Me.Button19.TabIndex = 7
        Me.Button19.Text = "Test"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(26, 108)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(188, 13)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "Check_CONNECTION_AVAIL ( CNX )"
        '
        'txtNetwork
        '
        Me.txtNetwork.Location = New System.Drawing.Point(191, 67)
        Me.txtNetwork.Name = "txtNetwork"
        Me.txtNetwork.Size = New System.Drawing.Size(100, 20)
        Me.txtNetwork.TabIndex = 5
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(309, 65)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(75, 23)
        Me.Button18.TabIndex = 4
        Me.Button18.Text = "Test"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(26, 70)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(151, 13)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "Check_NETWORK_AVAIL ( ) "
        '
        'txtHostName
        '
        Me.txtHostName.Location = New System.Drawing.Point(191, 30)
        Me.txtHostName.Name = "txtHostName"
        Me.txtHostName.Size = New System.Drawing.Size(100, 20)
        Me.txtHostName.TabIndex = 2
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(309, 28)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(75, 23)
        Me.Button17.TabIndex = 1
        Me.Button17.Text = "Test"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(26, 33)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(83, 13)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "HOST_NAME : "
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox8)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1056, 596)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "directoryOperations.vb"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Button27)
        Me.GroupBox8.Controls.Add(Me.Button26)
        Me.GroupBox8.Controls.Add(Me.Button25)
        Me.GroupBox8.Controls.Add(Me.Label34)
        Me.GroupBox8.Controls.Add(Me.Label33)
        Me.GroupBox8.Controls.Add(Me.Button24)
        Me.GroupBox8.Controls.Add(Me.Button22)
        Me.GroupBox8.Controls.Add(Me.lblTempPath)
        Me.GroupBox8.Controls.Add(Me.Label30)
        Me.GroupBox8.Location = New System.Drawing.Point(18, 16)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(1021, 171)
        Me.GroupBox8.TabIndex = 0
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "GroupBox8"
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(940, 23)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(75, 23)
        Me.Button22.TabIndex = 2
        Me.Button22.Text = "Test"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'lblTempPath
        '
        Me.lblTempPath.AutoSize = True
        Me.lblTempPath.Location = New System.Drawing.Point(219, 28)
        Me.lblTempPath.Name = "lblTempPath"
        Me.lblTempPath.Size = New System.Drawing.Size(10, 13)
        Me.lblTempPath.TabIndex = 1
        Me.lblTempPath.Text = " "
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(19, 28)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(194, 13)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "%CURRENT_USER% \ %TEMP% Path"
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(940, 63)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(75, 23)
        Me.Button24.TabIndex = 3
        Me.Button24.Text = "Test"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(29, 63)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(123, 13)
        Me.Label33.TabIndex = 4
        Me.Label33.Text = "Path for Attached Files : "
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(29, 88)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(117, 13)
        Me.Label34.TabIndex = 5
        Me.Label34.Text = "Path For Job Pictures : "
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(940, 92)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(75, 23)
        Me.Button25.TabIndex = 6
        Me.Button25.Text = "Test"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(835, 63)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(75, 23)
        Me.Button26.TabIndex = 7
        Me.Button26.Text = "Create Path"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(835, 92)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(75, 23)
        Me.Button27.TabIndex = 8
        Me.Button27.Text = "Create Path"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'TestingForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1088, 646)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "TestingForm"
        Me.ShowIcon = False
        Me.Text = "Admin Testing Form"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnTestGetMarketers As System.Windows.Forms.Button
    Friend WithEvents cboGetMarketers As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboSLS As System.Windows.Forms.ComboBox
    Friend WithEvents cboPLS As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents cboProd1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lsProdEX As System.Windows.Forms.ListView
    Friend WithEvents colID As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCat As System.Windows.Forms.ColumnHeader
    Friend WithEvents colName As System.Windows.Forms.ColumnHeader
    Friend WithEvents colModel As System.Windows.Forms.ColumnHeader
    Friend WithEvents colMeasurement As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtMM As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtValidateTest As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtValidateEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtValidatePHONE As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents txtZip As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtStAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents txtHostName As System.Windows.Forms.TextBox
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtNetwork As System.Windows.Forms.TextBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtSQL As System.Windows.Forms.TextBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents cboIPs As System.Windows.Forms.ComboBox
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents cboDataTables As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents cboFormat As System.Windows.Forms.ComboBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents lblTempPath As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtUser As System.Windows.Forms.TextBox
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
End Class
