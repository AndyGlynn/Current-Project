<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SDResult
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SDResult))
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.cboSalesResults = New System.Windows.Forms.ComboBox()
        Me.cboRep2 = New System.Windows.Forms.ComboBox()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.cboRep1 = New System.Windows.Forms.ComboBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DeleteThisProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.lvPrevious = New System.Windows.Forms.ListView()
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.pnlFirst = New System.Windows.Forms.Panel()
        Me.pnlLast = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboautonotes = New System.Windows.Forms.ComboBox()
        Me.lblsalesnotes = New System.Windows.Forms.Label()
        Me.rtfNote = New System.Windows.Forms.RichTextBox()
        Me.pnlDemo = New System.Windows.Forms.Panel()
        Me.txt1Par = New System.Windows.Forms.TextBox()
        Me.txt2Par = New System.Windows.Forms.TextBox()
        Me.txt1Quoted = New System.Windows.Forms.TextBox()
        Me.txt2Quoted = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkRecoverable = New System.Windows.Forms.CheckBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pnlSale1 = New System.Windows.Forms.Panel()
        Me.txt1ContractAmt = New System.Windows.Forms.TextBox()
        Me.txt2ContractAmt = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.grpPaymentOptions = New System.Windows.Forms.GroupBox()
        Me.rdoCash = New System.Windows.Forms.RadioButton()
        Me.rdoFinance = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpRecDate = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnlSale2 = New System.Windows.Forms.Panel()
        Me.dtpDelay = New System.Windows.Forms.DateTimePicker()
        Me.chkDelay = New System.Windows.Forms.CheckBox()
        Me.lblContractNotes = New System.Windows.Forms.Label()
        Me.txtContractNotes = New System.Windows.Forms.RichTextBox()
        Me.pnlSale4 = New System.Windows.Forms.Panel()
        Me.btnDeleteProduct = New System.Windows.Forms.Button()
        Me.cboProducts = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnMovetoFuture = New System.Windows.Forms.Button()
        Me.lstSold = New System.Windows.Forms.ListBox()
        Me.btnMovetoSold = New System.Windows.Forms.Button()
        Me.lstManage = New System.Windows.Forms.ListBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnlSale5 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtP1 = New System.Windows.Forms.TextBox()
        Me.txtP1Amnt = New System.Windows.Forms.TextBox()
        Me.lnkP1 = New System.Windows.Forms.LinkLabel()
        Me.txtP2 = New System.Windows.Forms.TextBox()
        Me.txtP2Amnt = New System.Windows.Forms.TextBox()
        Me.lnkP2 = New System.Windows.Forms.LinkLabel()
        Me.txtP3 = New System.Windows.Forms.TextBox()
        Me.txtP3Amnt = New System.Windows.Forms.TextBox()
        Me.lnkP3 = New System.Windows.Forms.LinkLabel()
        Me.txtP4 = New System.Windows.Forms.TextBox()
        Me.txtP4Amnt = New System.Windows.Forms.TextBox()
        Me.lnkP4 = New System.Windows.Forms.LinkLabel()
        Me.txtP5 = New System.Windows.Forms.TextBox()
        Me.txtP5Amnt = New System.Windows.Forms.TextBox()
        Me.lnkP5 = New System.Windows.Forms.LinkLabel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lnkCalc = New System.Windows.Forms.LinkLabel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pctRecoveryPC = New System.Windows.Forms.PictureBox()
        Me.lblRecoveryPC = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.pnlFirst.SuspendLayout()
        Me.pnlLast.SuspendLayout()
        Me.pnlDemo.SuspendLayout()
        Me.pnlSale1.SuspendLayout()
        Me.grpPaymentOptions.SuspendLayout()
        Me.pnlSale2.SuspendLayout()
        Me.pnlSale4.SuspendLayout()
        Me.pnlSale5.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctRecoveryPC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label141.ForeColor = System.Drawing.Color.Black
        Me.Label141.Location = New System.Drawing.Point(8, 22)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(76, 13)
        Me.Label141.TabIndex = 459
        Me.Label141.Text = "Sales Rep1:"
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label140.ForeColor = System.Drawing.Color.Black
        Me.Label140.Location = New System.Drawing.Point(8, 49)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(76, 13)
        Me.Label140.TabIndex = 460
        Me.Label140.Text = "Sales Rep2:"
        '
        'cboSalesResults
        '
        Me.cboSalesResults.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSalesResults.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSalesResults.BackColor = System.Drawing.SystemColors.Window
        Me.cboSalesResults.DropDownHeight = 140
        Me.cboSalesResults.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSalesResults.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSalesResults.FormattingEnabled = True
        Me.ErrorProvider1.SetIconPadding(Me.cboSalesResults, 5)
        Me.cboSalesResults.IntegralHeight = False
        Me.cboSalesResults.Items.AddRange(New Object() {"Demo/No Sale", "No Demo", "Reset", "Not Hit", "Not Issued", "Sale", "Recission Cancel", "Bank Approved", "Bank Rejected", "Lost Result"})
        Me.cboSalesResults.Location = New System.Drawing.Point(110, 73)
        Me.cboSalesResults.Name = "cboSalesResults"
        Me.cboSalesResults.Size = New System.Drawing.Size(234, 21)
        Me.cboSalesResults.TabIndex = 3
        '
        'cboRep2
        '
        Me.cboRep2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboRep2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboRep2.BackColor = System.Drawing.SystemColors.Window
        Me.cboRep2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRep2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboRep2.FormattingEnabled = True
        Me.cboRep2.Location = New System.Drawing.Point(110, 46)
        Me.cboRep2.Name = "cboRep2"
        Me.cboRep2.Size = New System.Drawing.Size(234, 21)
        Me.cboRep2.TabIndex = 2
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.BackColor = System.Drawing.Color.Transparent
        Me.Label139.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label139.ForeColor = System.Drawing.Color.Black
        Me.Label139.Location = New System.Drawing.Point(8, 76)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(47, 13)
        Me.Label139.TabIndex = 461
        Me.Label139.Text = "Result:"
        '
        'cboRep1
        '
        Me.cboRep1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboRep1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboRep1.BackColor = System.Drawing.SystemColors.Window
        Me.cboRep1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.cboRep1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRep1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboRep1.FormattingEnabled = True
        Me.cboRep1.Location = New System.Drawing.Point(110, 19)
        Me.cboRep1.Name = "cboRep1"
        Me.cboRep1.Size = New System.Drawing.Size(234, 21)
        Me.cboRep1.TabIndex = 1
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteThisProductToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(168, 26)
        '
        'DeleteThisProductToolStripMenuItem
        '
        Me.DeleteThisProductToolStripMenuItem.Image = CType(resources.GetObject("DeleteThisProductToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteThisProductToolStripMenuItem.Name = "DeleteThisProductToolStripMenuItem"
        Me.DeleteThisProductToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.DeleteThisProductToolStripMenuItem.Text = "Delete This Result"
        '
        'btnNext
        '
        Me.btnNext.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.ForeColor = System.Drawing.Color.Black
        Me.btnNext.Image = CType(resources.GetObject("btnNext.Image"), System.Drawing.Image)
        Me.btnNext.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnNext.Location = New System.Drawing.Point(321, 152)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(59, 33)
        Me.btnNext.TabIndex = 11
        Me.btnNext.Text = "Next"
        Me.btnNext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'lvPrevious
        '
        Me.lvPrevious.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader4, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.lvPrevious.ContextMenuStrip = Me.ContextMenuStrip1
        Me.lvPrevious.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvPrevious.FullRowSelect = True
        Me.lvPrevious.HideSelection = False
        Me.lvPrevious.Location = New System.Drawing.Point(12, 219)
        Me.lvPrevious.MultiSelect = False
        Me.lvPrevious.Name = "lvPrevious"
        Me.lvPrevious.Size = New System.Drawing.Size(368, 87)
        Me.lvPrevious.SmallImageList = Me.ImageList1
        Me.lvPrevious.TabIndex = 511
        Me.lvPrevious.UseCompatibleStateImageBehavior = False
        Me.lvPrevious.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = ""
        Me.ColumnHeader4.Width = 31
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Date"
        Me.ColumnHeader1.Width = 73
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Result"
        Me.ColumnHeader2.Width = 111
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Rep 1"
        Me.ColumnHeader3.Width = 130
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "arrow-down.ico")
        Me.ImageList1.Images.SetKeyName(1, "arrow-up.ico")
        Me.ImageList1.Images.SetKeyName(2, "lock.ico")
        Me.ImageList1.Images.SetKeyName(3, "locked.ico")
        Me.ImageList1.Images.SetKeyName(4, "arrow-right.ico")
        Me.ImageList1.Images.SetKeyName(5, "recoveryIcon.ico")
        Me.ImageList1.Images.SetKeyName(6, "Previous Customer.ico")
        '
        'pnlFirst
        '
        Me.pnlFirst.BackColor = System.Drawing.Color.White
        Me.pnlFirst.Controls.Add(Me.cboRep2)
        Me.pnlFirst.Controls.Add(Me.cboRep1)
        Me.pnlFirst.Controls.Add(Me.Label139)
        Me.pnlFirst.Controls.Add(Me.cboSalesResults)
        Me.pnlFirst.Controls.Add(Me.Label140)
        Me.pnlFirst.Controls.Add(Me.Label141)
        Me.pnlFirst.Location = New System.Drawing.Point(12, 12)
        Me.pnlFirst.Name = "pnlFirst"
        Me.pnlFirst.Size = New System.Drawing.Size(368, 125)
        Me.pnlFirst.TabIndex = 1
        '
        'pnlLast
        '
        Me.pnlLast.BackColor = System.Drawing.Color.White
        Me.pnlLast.Controls.Add(Me.Label1)
        Me.pnlLast.Controls.Add(Me.cboautonotes)
        Me.pnlLast.Controls.Add(Me.lblsalesnotes)
        Me.pnlLast.Controls.Add(Me.rtfNote)
        Me.pnlLast.Location = New System.Drawing.Point(12, 12)
        Me.pnlLast.Name = "pnlLast"
        Me.pnlLast.Size = New System.Drawing.Size(368, 125)
        Me.pnlLast.TabIndex = 520
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gray
        Me.Label1.Location = New System.Drawing.Point(8, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(336, 21)
        Me.Label1.TabIndex = 509
        Me.Label1.Text = "select auto note here"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboautonotes
        '
        Me.cboautonotes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboautonotes.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboautonotes.FormattingEnabled = True
        Me.cboautonotes.Location = New System.Drawing.Point(8, 14)
        Me.cboautonotes.Name = "cboautonotes"
        Me.cboautonotes.Size = New System.Drawing.Size(357, 21)
        Me.cboautonotes.TabIndex = 508
        '
        'lblsalesnotes
        '
        Me.lblsalesnotes.AutoSize = True
        Me.lblsalesnotes.BackColor = System.Drawing.Color.White
        Me.lblsalesnotes.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.lblsalesnotes.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsalesnotes.ForeColor = System.Drawing.Color.Gray
        Me.lblsalesnotes.Location = New System.Drawing.Point(94, 70)
        Me.lblsalesnotes.Name = "lblsalesnotes"
        Me.lblsalesnotes.Size = New System.Drawing.Size(180, 13)
        Me.lblsalesnotes.TabIndex = 503
        Me.lblsalesnotes.Text = "Enter notes to log w/ this sale result"
        '
        'rtfNote
        '
        Me.rtfNote.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.rtfNote.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtfNote.Location = New System.Drawing.Point(8, 43)
        Me.rtfNote.Name = "rtfNote"
        Me.rtfNote.Size = New System.Drawing.Size(357, 79)
        Me.rtfNote.TabIndex = 2
        Me.rtfNote.Text = ""
        '
        'pnlDemo
        '
        Me.pnlDemo.BackColor = System.Drawing.Color.White
        Me.pnlDemo.Controls.Add(Me.txt1Par)
        Me.pnlDemo.Controls.Add(Me.txt2Par)
        Me.pnlDemo.Controls.Add(Me.txt1Quoted)
        Me.pnlDemo.Controls.Add(Me.txt2Quoted)
        Me.pnlDemo.Controls.Add(Me.Label10)
        Me.pnlDemo.Controls.Add(Me.Label9)
        Me.pnlDemo.Controls.Add(Me.chkRecoverable)
        Me.pnlDemo.Controls.Add(Me.Label137)
        Me.pnlDemo.Controls.Add(Me.Label138)
        Me.pnlDemo.Controls.Add(Me.Label12)
        Me.pnlDemo.Controls.Add(Me.Label11)
        Me.pnlDemo.Location = New System.Drawing.Point(12, 12)
        Me.pnlDemo.Name = "pnlDemo"
        Me.pnlDemo.Size = New System.Drawing.Size(368, 125)
        Me.pnlDemo.TabIndex = 521
        '
        'txt1Par
        '
        Me.txt1Par.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1Par.Location = New System.Drawing.Point(121, 46)
        Me.txt1Par.MaxLength = 7
        Me.txt1Par.Name = "txt1Par"
        Me.txt1Par.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt1Par.Size = New System.Drawing.Size(66, 21)
        Me.txt1Par.TabIndex = 2
        '
        'txt2Par
        '
        Me.txt2Par.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2Par.Location = New System.Drawing.Point(197, 46)
        Me.txt2Par.MaxLength = 2
        Me.txt2Par.Name = "txt2Par"
        Me.txt2Par.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt2Par.Size = New System.Drawing.Size(20, 21)
        Me.txt2Par.TabIndex = 465
        Me.txt2Par.TabStop = False
        Me.txt2Par.Text = "00"
        '
        'txt1Quoted
        '
        Me.txt1Quoted.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1Quoted.Location = New System.Drawing.Point(121, 19)
        Me.txt1Quoted.MaxLength = 7
        Me.txt1Quoted.Name = "txt1Quoted"
        Me.txt1Quoted.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt1Quoted.Size = New System.Drawing.Size(66, 21)
        Me.txt1Quoted.TabIndex = 1
        '
        'txt2Quoted
        '
        Me.txt2Quoted.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2Quoted.Location = New System.Drawing.Point(197, 19)
        Me.txt2Quoted.MaxLength = 2
        Me.txt2Quoted.Name = "txt2Quoted"
        Me.txt2Quoted.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt2Quoted.Size = New System.Drawing.Size(20, 21)
        Me.txt2Quoted.TabIndex = 463
        Me.txt2Quoted.TabStop = False
        Me.txt2Quoted.Text = "00"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(185, 22)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 16)
        Me.Label10.TabIndex = 462
        Me.Label10.Text = "."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(108, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(16, 16)
        Me.Label9.TabIndex = 461
        Me.Label9.Text = "$"
        '
        'chkRecoverable
        '
        Me.chkRecoverable.AutoSize = True
        Me.chkRecoverable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkRecoverable.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkRecoverable.ForeColor = System.Drawing.Color.Black
        Me.chkRecoverable.Location = New System.Drawing.Point(16, 91)
        Me.chkRecoverable.Name = "chkRecoverable"
        Me.chkRecoverable.Size = New System.Drawing.Size(218, 17)
        Me.chkRecoverable.TabIndex = 3
        Me.chkRecoverable.Text = "Send this record to be Recovered"
        Me.chkRecoverable.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkRecoverable.UseVisualStyleBackColor = True
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.ForeColor = System.Drawing.Color.Black
        Me.Label137.Location = New System.Drawing.Point(8, 22)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(53, 13)
        Me.Label137.TabIndex = 457
        Me.Label137.Text = "Quoted:"
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label138.ForeColor = System.Drawing.Color.Black
        Me.Label138.Location = New System.Drawing.Point(8, 49)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(63, 13)
        Me.Label138.TabIndex = 456
        Me.Label138.Text = "Par Price:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(185, 47)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(12, 16)
        Me.Label12.TabIndex = 468
        Me.Label12.Text = "."
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(108, 47)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(16, 16)
        Me.Label11.TabIndex = 467
        Me.Label11.Text = "$"
        '
        'pnlSale1
        '
        Me.pnlSale1.BackColor = System.Drawing.Color.White
        Me.pnlSale1.Controls.Add(Me.txt1ContractAmt)
        Me.pnlSale1.Controls.Add(Me.txt2ContractAmt)
        Me.pnlSale1.Controls.Add(Me.Label13)
        Me.pnlSale1.Controls.Add(Me.Label14)
        Me.pnlSale1.Controls.Add(Me.Label8)
        Me.pnlSale1.Controls.Add(Me.grpPaymentOptions)
        Me.pnlSale1.Controls.Add(Me.Label2)
        Me.pnlSale1.Controls.Add(Me.dtpRecDate)
        Me.pnlSale1.Controls.Add(Me.Label3)
        Me.pnlSale1.Location = New System.Drawing.Point(12, 12)
        Me.pnlSale1.Name = "pnlSale1"
        Me.pnlSale1.Size = New System.Drawing.Size(368, 125)
        Me.pnlSale1.TabIndex = 522
        '
        'txt1ContractAmt
        '
        Me.txt1ContractAmt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ErrorProvider1.SetIconPadding(Me.txt1ContractAmt, 25)
        Me.txt1ContractAmt.Location = New System.Drawing.Point(144, 58)
        Me.txt1ContractAmt.MaxLength = 9
        Me.txt1ContractAmt.Name = "txt1ContractAmt"
        Me.txt1ContractAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt1ContractAmt.Size = New System.Drawing.Size(66, 21)
        Me.txt1ContractAmt.TabIndex = 1
        '
        'txt2ContractAmt
        '
        Me.txt2ContractAmt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2ContractAmt.Location = New System.Drawing.Point(218, 58)
        Me.txt2ContractAmt.MaxLength = 2
        Me.txt2ContractAmt.Name = "txt2ContractAmt"
        Me.txt2ContractAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txt2ContractAmt.Size = New System.Drawing.Size(20, 21)
        Me.txt2ContractAmt.TabIndex = 2
        Me.txt2ContractAmt.TabStop = False
        Me.txt2ContractAmt.Text = "00"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(209, 61)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(13, 16)
        Me.Label13.TabIndex = 466
        Me.Label13.Text = "."
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(130, 61)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(16, 16)
        Me.Label14.TabIndex = 465
        Me.Label14.Text = "$"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 13)
        Me.Label8.TabIndex = 462
        Me.Label8.Text = "Payment Method:"
        '
        'grpPaymentOptions
        '
        Me.grpPaymentOptions.Controls.Add(Me.rdoCash)
        Me.grpPaymentOptions.Controls.Add(Me.rdoFinance)
        Me.grpPaymentOptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpPaymentOptions.Location = New System.Drawing.Point(130, 86)
        Me.grpPaymentOptions.Name = "grpPaymentOptions"
        Me.grpPaymentOptions.Size = New System.Drawing.Size(163, 31)
        Me.grpPaymentOptions.TabIndex = 3
        Me.grpPaymentOptions.TabStop = False
        '
        'rdoCash
        '
        Me.rdoCash.AutoSize = True
        Me.rdoCash.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoCash.ForeColor = System.Drawing.Color.Black
        Me.rdoCash.Location = New System.Drawing.Point(14, 12)
        Me.rdoCash.Name = "rdoCash"
        Me.rdoCash.Size = New System.Drawing.Size(54, 17)
        Me.rdoCash.TabIndex = 3
        Me.rdoCash.TabStop = True
        Me.rdoCash.Text = "Cash"
        Me.rdoCash.UseVisualStyleBackColor = True
        '
        'rdoFinance
        '
        Me.rdoFinance.AutoSize = True
        Me.rdoFinance.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoFinance.ForeColor = System.Drawing.Color.Black
        Me.rdoFinance.Location = New System.Drawing.Point(83, 12)
        Me.rdoFinance.Name = "rdoFinance"
        Me.rdoFinance.Size = New System.Drawing.Size(68, 17)
        Me.rdoFinance.TabIndex = 4
        Me.rdoFinance.TabStop = True
        Me.rdoFinance.Text = "Finance"
        Me.rdoFinance.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 13)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Recission period expires on:"
        '
        'dtpRecDate
        '
        Me.dtpRecDate.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpRecDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpRecDate.Location = New System.Drawing.Point(182, 18)
        Me.dtpRecDate.Name = "dtpRecDate"
        Me.dtpRecDate.Size = New System.Drawing.Size(99, 21)
        Me.dtpRecDate.TabIndex = 50
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 13)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Contract Amount:"
        '
        'pnlSale2
        '
        Me.pnlSale2.BackColor = System.Drawing.Color.White
        Me.pnlSale2.Controls.Add(Me.dtpDelay)
        Me.pnlSale2.Controls.Add(Me.chkDelay)
        Me.pnlSale2.Controls.Add(Me.lblContractNotes)
        Me.pnlSale2.Controls.Add(Me.txtContractNotes)
        Me.pnlSale2.Location = New System.Drawing.Point(12, 12)
        Me.pnlSale2.Name = "pnlSale2"
        Me.pnlSale2.Size = New System.Drawing.Size(368, 125)
        Me.pnlSale2.TabIndex = 523
        '
        'dtpDelay
        '
        Me.dtpDelay.Enabled = False
        Me.dtpDelay.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDelay.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDelay.Location = New System.Drawing.Point(164, 7)
        Me.dtpDelay.Name = "dtpDelay"
        Me.dtpDelay.Size = New System.Drawing.Size(130, 21)
        Me.dtpDelay.TabIndex = 513
        '
        'chkDelay
        '
        Me.chkDelay.AutoSize = True
        Me.chkDelay.Location = New System.Drawing.Point(28, 10)
        Me.chkDelay.Name = "chkDelay"
        Me.chkDelay.Size = New System.Drawing.Size(130, 17)
        Me.chkDelay.TabIndex = 512
        Me.chkDelay.Text = "Delay Installation Until"
        Me.chkDelay.UseVisualStyleBackColor = True
        '
        'lblContractNotes
        '
        Me.lblContractNotes.AutoSize = True
        Me.lblContractNotes.BackColor = System.Drawing.Color.White
        Me.lblContractNotes.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.lblContractNotes.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContractNotes.ForeColor = System.Drawing.Color.Gray
        Me.lblContractNotes.Location = New System.Drawing.Point(94, 75)
        Me.lblContractNotes.Name = "lblContractNotes"
        Me.lblContractNotes.Size = New System.Drawing.Size(169, 13)
        Me.lblContractNotes.TabIndex = 505
        Me.lblContractNotes.Text = "Enter Contract Notes for this Sale"
        '
        'txtContractNotes
        '
        Me.txtContractNotes.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtContractNotes.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtContractNotes.Location = New System.Drawing.Point(8, 34)
        Me.txtContractNotes.Name = "txtContractNotes"
        Me.txtContractNotes.Size = New System.Drawing.Size(357, 88)
        Me.txtContractNotes.TabIndex = 1
        Me.txtContractNotes.Text = ""
        '
        'pnlSale4
        '
        Me.pnlSale4.BackColor = System.Drawing.Color.White
        Me.pnlSale4.Controls.Add(Me.btnDeleteProduct)
        Me.pnlSale4.Controls.Add(Me.cboProducts)
        Me.pnlSale4.Controls.Add(Me.Label4)
        Me.pnlSale4.Controls.Add(Me.Label5)
        Me.pnlSale4.Controls.Add(Me.btnMovetoFuture)
        Me.pnlSale4.Controls.Add(Me.lstSold)
        Me.pnlSale4.Controls.Add(Me.btnMovetoSold)
        Me.pnlSale4.Controls.Add(Me.lstManage)
        Me.pnlSale4.Controls.Add(Me.Label15)
        Me.pnlSale4.Location = New System.Drawing.Point(12, 12)
        Me.pnlSale4.Name = "pnlSale4"
        Me.pnlSale4.Size = New System.Drawing.Size(368, 125)
        Me.pnlSale4.TabIndex = 524
        '
        'btnDeleteProduct
        '
        Me.btnDeleteProduct.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteProduct.ForeColor = System.Drawing.Color.Black
        Me.btnDeleteProduct.Image = CType(resources.GetObject("btnDeleteProduct.Image"), System.Drawing.Image)
        Me.btnDeleteProduct.Location = New System.Drawing.Point(164, 98)
        Me.btnDeleteProduct.Name = "btnDeleteProduct"
        Me.btnDeleteProduct.Size = New System.Drawing.Size(40, 19)
        Me.btnDeleteProduct.TabIndex = 6
        Me.btnDeleteProduct.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDeleteProduct.UseVisualStyleBackColor = True
        '
        'cboProducts
        '
        Me.cboProducts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProducts.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboProducts.FormattingEnabled = True
        Me.cboProducts.Location = New System.Drawing.Point(149, 8)
        Me.cboProducts.Name = "cboProducts"
        Me.cboProducts.Size = New System.Drawing.Size(202, 21)
        Me.cboProducts.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(244, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 535
        Me.Label4.Text = "Sold Products"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(35, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 13)
        Me.Label5.TabIndex = 533
        Me.Label5.Text = "Future Interest"
        '
        'btnMovetoFuture
        '
        Me.btnMovetoFuture.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMovetoFuture.ForeColor = System.Drawing.Color.Black
        Me.btnMovetoFuture.Image = CType(resources.GetObject("btnMovetoFuture.Image"), System.Drawing.Image)
        Me.btnMovetoFuture.Location = New System.Drawing.Point(164, 73)
        Me.btnMovetoFuture.Name = "btnMovetoFuture"
        Me.btnMovetoFuture.Size = New System.Drawing.Size(40, 19)
        Me.btnMovetoFuture.TabIndex = 5
        Me.btnMovetoFuture.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnMovetoFuture.UseVisualStyleBackColor = True
        '
        'lstSold
        '
        Me.lstSold.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstSold.FormattingEnabled = True
        Me.lstSold.Location = New System.Drawing.Point(210, 48)
        Me.lstSold.Name = "lstSold"
        Me.lstSold.Size = New System.Drawing.Size(155, 69)
        Me.lstSold.TabIndex = 4
        '
        'btnMovetoSold
        '
        Me.btnMovetoSold.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMovetoSold.ForeColor = System.Drawing.Color.Black
        Me.btnMovetoSold.Image = CType(resources.GetObject("btnMovetoSold.Image"), System.Drawing.Image)
        Me.btnMovetoSold.Location = New System.Drawing.Point(164, 49)
        Me.btnMovetoSold.Name = "btnMovetoSold"
        Me.btnMovetoSold.Size = New System.Drawing.Size(40, 19)
        Me.btnMovetoSold.TabIndex = 3
        Me.btnMovetoSold.UseVisualStyleBackColor = True
        '
        'lstManage
        '
        Me.lstManage.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstManage.FormattingEnabled = True
        Me.lstManage.Items.AddRange(New Object() {"Roof", "Siding", "Windows", "Deck", "Porch"})
        Me.lstManage.Location = New System.Drawing.Point(3, 48)
        Me.lstManage.Name = "lstManage"
        Me.lstManage.Size = New System.Drawing.Size(155, 69)
        Me.lstManage.TabIndex = 1
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(17, 11)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(129, 13)
        Me.Label15.TabIndex = 530
        Me.Label15.Text = "Add More Product(s):"
        '
        'pnlSale5
        '
        Me.pnlSale5.BackColor = System.Drawing.Color.White
        Me.pnlSale5.Controls.Add(Me.FlowLayoutPanel1)
        Me.pnlSale5.Location = New System.Drawing.Point(12, 12)
        Me.pnlSale5.Name = "pnlSale5"
        Me.pnlSale5.Size = New System.Drawing.Size(368, 125)
        Me.pnlSale5.TabIndex = 525
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP1)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP1Amnt)
        Me.FlowLayoutPanel1.Controls.Add(Me.lnkP1)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP2)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP2Amnt)
        Me.FlowLayoutPanel1.Controls.Add(Me.lnkP2)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP3)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP3Amnt)
        Me.FlowLayoutPanel1.Controls.Add(Me.lnkP3)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP4)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP4Amnt)
        Me.FlowLayoutPanel1.Controls.Add(Me.lnkP4)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP5)
        Me.FlowLayoutPanel1.Controls.Add(Me.txtP5Amnt)
        Me.FlowLayoutPanel1.Controls.Add(Me.lnkP5)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(8, 11)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(357, 102)
        Me.FlowLayoutPanel1.TabIndex = 529
        '
        'txtP1
        '
        Me.txtP1.BackColor = System.Drawing.Color.White
        Me.txtP1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP1.Location = New System.Drawing.Point(3, 3)
        Me.txtP1.Name = "txtP1"
        Me.txtP1.ReadOnly = True
        Me.txtP1.Size = New System.Drawing.Size(147, 14)
        Me.txtP1.TabIndex = 3
        Me.txtP1.TabStop = False
        Me.txtP1.Visible = False
        '
        'txtP1Amnt
        '
        Me.txtP1Amnt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP1Amnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP1Amnt.Location = New System.Drawing.Point(156, 3)
        Me.txtP1Amnt.Name = "txtP1Amnt"
        Me.txtP1Amnt.Size = New System.Drawing.Size(80, 14)
        Me.txtP1Amnt.TabIndex = 1
        Me.txtP1Amnt.Visible = False
        '
        'lnkP1
        '
        Me.lnkP1.AutoSize = True
        Me.lnkP1.Location = New System.Drawing.Point(242, 3)
        Me.lnkP1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkP1.Name = "lnkP1"
        Me.lnkP1.Size = New System.Drawing.Size(101, 13)
        Me.lnkP1.TabIndex = 2
        Me.lnkP1.TabStop = True
        Me.lnkP1.Text = "Add Product Details"
        Me.lnkP1.Visible = False
        '
        'txtP2
        '
        Me.txtP2.BackColor = System.Drawing.Color.White
        Me.txtP2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP2.Location = New System.Drawing.Point(3, 23)
        Me.txtP2.Name = "txtP2"
        Me.txtP2.ReadOnly = True
        Me.txtP2.Size = New System.Drawing.Size(147, 14)
        Me.txtP2.TabIndex = 6
        Me.txtP2.TabStop = False
        Me.txtP2.Visible = False
        '
        'txtP2Amnt
        '
        Me.txtP2Amnt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP2Amnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP2Amnt.Location = New System.Drawing.Point(156, 23)
        Me.txtP2Amnt.Name = "txtP2Amnt"
        Me.txtP2Amnt.Size = New System.Drawing.Size(80, 14)
        Me.txtP2Amnt.TabIndex = 3
        Me.txtP2Amnt.Visible = False
        '
        'lnkP2
        '
        Me.lnkP2.AutoSize = True
        Me.lnkP2.Location = New System.Drawing.Point(242, 23)
        Me.lnkP2.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkP2.Name = "lnkP2"
        Me.lnkP2.Size = New System.Drawing.Size(101, 13)
        Me.lnkP2.TabIndex = 4
        Me.lnkP2.TabStop = True
        Me.lnkP2.Text = "Add Product Details"
        Me.lnkP2.Visible = False
        '
        'txtP3
        '
        Me.txtP3.BackColor = System.Drawing.Color.White
        Me.txtP3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP3.Location = New System.Drawing.Point(3, 43)
        Me.txtP3.Name = "txtP3"
        Me.txtP3.ReadOnly = True
        Me.txtP3.Size = New System.Drawing.Size(147, 14)
        Me.txtP3.TabIndex = 9
        Me.txtP3.TabStop = False
        Me.txtP3.Visible = False
        '
        'txtP3Amnt
        '
        Me.txtP3Amnt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP3Amnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP3Amnt.Location = New System.Drawing.Point(156, 43)
        Me.txtP3Amnt.Name = "txtP3Amnt"
        Me.txtP3Amnt.Size = New System.Drawing.Size(80, 14)
        Me.txtP3Amnt.TabIndex = 5
        Me.txtP3Amnt.Visible = False
        '
        'lnkP3
        '
        Me.lnkP3.AutoSize = True
        Me.lnkP3.Location = New System.Drawing.Point(242, 43)
        Me.lnkP3.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkP3.Name = "lnkP3"
        Me.lnkP3.Size = New System.Drawing.Size(101, 13)
        Me.lnkP3.TabIndex = 6
        Me.lnkP3.TabStop = True
        Me.lnkP3.Text = "Add Product Details"
        Me.lnkP3.Visible = False
        '
        'txtP4
        '
        Me.txtP4.BackColor = System.Drawing.Color.White
        Me.txtP4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP4.Location = New System.Drawing.Point(3, 63)
        Me.txtP4.Name = "txtP4"
        Me.txtP4.ReadOnly = True
        Me.txtP4.Size = New System.Drawing.Size(147, 14)
        Me.txtP4.TabIndex = 12
        Me.txtP4.TabStop = False
        Me.txtP4.Visible = False
        '
        'txtP4Amnt
        '
        Me.txtP4Amnt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP4Amnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP4Amnt.Location = New System.Drawing.Point(156, 63)
        Me.txtP4Amnt.Name = "txtP4Amnt"
        Me.txtP4Amnt.Size = New System.Drawing.Size(80, 14)
        Me.txtP4Amnt.TabIndex = 7
        Me.txtP4Amnt.Visible = False
        '
        'lnkP4
        '
        Me.lnkP4.AutoSize = True
        Me.lnkP4.Location = New System.Drawing.Point(242, 63)
        Me.lnkP4.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkP4.Name = "lnkP4"
        Me.lnkP4.Size = New System.Drawing.Size(101, 13)
        Me.lnkP4.TabIndex = 8
        Me.lnkP4.TabStop = True
        Me.lnkP4.Text = "Add Product Details"
        Me.lnkP4.Visible = False
        '
        'txtP5
        '
        Me.txtP5.BackColor = System.Drawing.Color.White
        Me.txtP5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP5.Location = New System.Drawing.Point(3, 83)
        Me.txtP5.Name = "txtP5"
        Me.txtP5.ReadOnly = True
        Me.txtP5.Size = New System.Drawing.Size(147, 14)
        Me.txtP5.TabIndex = 15
        Me.txtP5.TabStop = False
        Me.txtP5.Visible = False
        '
        'txtP5Amnt
        '
        Me.txtP5Amnt.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtP5Amnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP5Amnt.Location = New System.Drawing.Point(156, 83)
        Me.txtP5Amnt.Name = "txtP5Amnt"
        Me.txtP5Amnt.Size = New System.Drawing.Size(80, 14)
        Me.txtP5Amnt.TabIndex = 9
        Me.txtP5Amnt.Visible = False
        '
        'lnkP5
        '
        Me.lnkP5.AutoSize = True
        Me.lnkP5.Location = New System.Drawing.Point(242, 83)
        Me.lnkP5.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkP5.Name = "lnkP5"
        Me.lnkP5.Size = New System.Drawing.Size(101, 13)
        Me.lnkP5.TabIndex = 10
        Me.lnkP5.TabStop = True
        Me.lnkP5.Text = "Add Product Details"
        Me.lnkP5.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(12, 203)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(134, 13)
        Me.Label7.TabIndex = 526
        Me.Label7.Text = "Select Result Below to Edit"
        '
        'btnBack
        '
        Me.btnBack.Enabled = False
        Me.btnBack.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Black
        Me.btnBack.Image = CType(resources.GetObject("btnBack.Image"), System.Drawing.Image)
        Me.btnBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBack.Location = New System.Drawing.Point(256, 152)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(59, 33)
        Me.btnBack.TabIndex = 12
        Me.btnBack.Text = "Back"
        Me.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(191, 152)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(59, 33)
        Me.btnCancel.TabIndex = 13
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Black
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.Location = New System.Drawing.Point(321, 152)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(59, 33)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        Me.btnSave.Visible = False
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.ForeColor = System.Drawing.Color.Black
        Me.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnEdit.ImageIndex = 0
        Me.btnEdit.ImageList = Me.ImageList1
        Me.btnEdit.Location = New System.Drawing.Point(12, 152)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(147, 33)
        Me.btnEdit.TabIndex = 14
        Me.btnEdit.Text = "Edit Previous Result"
        Me.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.ErrorProvider1.ContainerControl = Me
        '
        'lnkCalc
        '
        Me.lnkCalc.AutoSize = True
        Me.lnkCalc.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnkCalc.Location = New System.Drawing.Point(29, 162)
        Me.lnkCalc.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lnkCalc.Name = "lnkCalc"
        Me.lnkCalc.Size = New System.Drawing.Size(109, 13)
        Me.lnkCalc.TabIndex = 14
        Me.lnkCalc.TabStop = True
        Me.lnkCalc.Text = "Launch Calculator"
        Me.lnkCalc.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gray
        Me.Label6.Location = New System.Drawing.Point(236, 203)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(144, 13)
        Me.Label6.TabIndex = 533
        Me.Label6.Text = "(Right Click Result to Delete)"
        '
        'pctRecoveryPC
        '
        Me.pctRecoveryPC.Location = New System.Drawing.Point(6, 4)
        Me.pctRecoveryPC.Name = "pctRecoveryPC"
        Me.pctRecoveryPC.Size = New System.Drawing.Size(18, 18)
        Me.pctRecoveryPC.TabIndex = 534
        Me.pctRecoveryPC.TabStop = False
        '
        'lblRecoveryPC
        '
        Me.lblRecoveryPC.AutoSize = True
        Me.lblRecoveryPC.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecoveryPC.ForeColor = System.Drawing.Color.Gray
        Me.lblRecoveryPC.Location = New System.Drawing.Point(29, 6)
        Me.lblRecoveryPC.Name = "lblRecoveryPC"
        Me.lblRecoveryPC.Size = New System.Drawing.Size(0, 13)
        Me.lblRecoveryPC.TabIndex = 535
        '
        'SDResult
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(391, 196)
        Me.Controls.Add(Me.lblRecoveryPC)
        Me.Controls.Add(Me.pctRecoveryPC)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lvPrevious)
        Me.Controls.Add(Me.lnkCalc)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.pnlLast)
        Me.Controls.Add(Me.pnlFirst)
        Me.Controls.Add(Me.pnlSale5)
        Me.Controls.Add(Me.pnlSale4)
        Me.Controls.Add(Me.pnlSale1)
        Me.Controls.Add(Me.pnlSale2)
        Me.Controls.Add(Me.pnlDemo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SDResult"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.pnlFirst.ResumeLayout(False)
        Me.pnlFirst.PerformLayout()
        Me.pnlLast.ResumeLayout(False)
        Me.pnlLast.PerformLayout()
        Me.pnlDemo.ResumeLayout(False)
        Me.pnlDemo.PerformLayout()
        Me.pnlSale1.ResumeLayout(False)
        Me.pnlSale1.PerformLayout()
        Me.grpPaymentOptions.ResumeLayout(False)
        Me.grpPaymentOptions.PerformLayout()
        Me.pnlSale2.ResumeLayout(False)
        Me.pnlSale2.PerformLayout()
        Me.pnlSale4.ResumeLayout(False)
        Me.pnlSale4.PerformLayout()
        Me.pnlSale5.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctRecoveryPC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents cboSalesResults As System.Windows.Forms.ComboBox
    Friend WithEvents cboRep2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents cboRep1 As System.Windows.Forms.ComboBox
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents lvPrevious As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents pnlFirst As System.Windows.Forms.Panel
    Friend WithEvents pnlLast As System.Windows.Forms.Panel
    Friend WithEvents lblsalesnotes As System.Windows.Forms.Label
    Friend WithEvents rtfNote As System.Windows.Forms.RichTextBox
    Friend WithEvents pnlDemo As System.Windows.Forms.Panel
    Friend WithEvents chkRecoverable As System.Windows.Forms.CheckBox
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents pnlSale1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpRecDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents pnlSale2 As System.Windows.Forms.Panel
    Friend WithEvents lblContractNotes As System.Windows.Forms.Label
    Friend WithEvents txtContractNotes As System.Windows.Forms.RichTextBox
    Friend WithEvents pnlSale4 As System.Windows.Forms.Panel
    Friend WithEvents pnlSale5 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents grpPaymentOptions As System.Windows.Forms.GroupBox
    Friend WithEvents rdoCash As System.Windows.Forms.RadioButton
    Friend WithEvents rdoFinance As System.Windows.Forms.RadioButton
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents txt2Quoted As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt1Par As System.Windows.Forms.TextBox
    Friend WithEvents txt2Par As System.Windows.Forms.TextBox
    Friend WithEvents txt1Quoted As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txt1ContractAmt As System.Windows.Forms.TextBox
    Friend WithEvents txt2ContractAmt As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents cboProducts As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnMovetoFuture As System.Windows.Forms.Button
    Friend WithEvents lstSold As System.Windows.Forms.ListBox
    Friend WithEvents btnMovetoSold As System.Windows.Forms.Button
    Friend WithEvents lstManage As System.Windows.Forms.ListBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents btnDeleteProduct As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents txtP1 As System.Windows.Forms.TextBox
    Friend WithEvents txtP1Amnt As System.Windows.Forms.TextBox
    Friend WithEvents lnkP1 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtP2Amnt As System.Windows.Forms.TextBox
    Friend WithEvents lnkP2 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtP3Amnt As System.Windows.Forms.TextBox
    Friend WithEvents lnkP3 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtP4 As System.Windows.Forms.TextBox
    Friend WithEvents txtP4Amnt As System.Windows.Forms.TextBox
    Friend WithEvents lnkP4 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtP5 As System.Windows.Forms.TextBox
    Friend WithEvents txtP5Amnt As System.Windows.Forms.TextBox
    Friend WithEvents lnkP5 As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkCalc As System.Windows.Forms.LinkLabel
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DeleteThisProductToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblRecoveryPC As System.Windows.Forms.Label
    Friend WithEvents pctRecoveryPC As System.Windows.Forms.PictureBox
    Friend WithEvents dtpDelay As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkDelay As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboautonotes As System.Windows.Forms.ComboBox
End Class
