Public Class PreviousCustomer

    Private Sub PreviousCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = Main
    End Sub
End Class