﻿Public Class newFrmSales

    Private Sub tsSalesDepartment_SizeChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub cboFilterGroups_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub cboDisplayMemorized_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub cboGroupByMemorized_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub lblgroupbymemorized_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub lbldisplaymemorized_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnExpandMemorize_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub lblFilterGroups_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub lnkOrderbyMem_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub
    Private Sub cboSalesList_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub SaveChangesToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ToolStripComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ToolStripComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub SetAppointmentToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub EditCustomerToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub RemoveThisApptToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub MemorizeThisApptToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub EnterSalesResultToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ShowNotesToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnExpandSalesList_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub cboDisplayColumn_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub cboGroupSales_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub lblGroupBy_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub lblDisplayColumn_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub
    Private Sub pnlScheduledTasks_MouseDown(sender As Object, e As MouseEventArgs)

    End Sub
    Private Sub pnlScheduledTasks_Paint(sender As Object, e As PaintEventArgs)

    End Sub
    Private Sub HideThisCompletedTaskToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub EditScheduledTaskToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub MarkTaskAsDoneToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub SCCustomerList_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub SCsalesresult_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnTiles_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnDetails_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnList_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnSmall_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnMedium_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnLarge_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnXLarge_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnRename_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnCopy_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnCut_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub btnOpen_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub EmailThisLeadToAssignedRepsToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub
End Class