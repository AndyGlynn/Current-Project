﻿Public Class validationLogic

    ''
    '' methods for string manipulation
    '' methods for string validation
    '' methods for input formatting
    '' 


End Class
