<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.TSMain = New System.Windows.Forms.ToolStrip()
        Me.tsbmarketing = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ColdCallingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WarmCallingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreviousCustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecoveryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfirmingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsbMarketingManager = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsbsales = New System.Windows.Forms.ToolStripButton()
        Me.tsbinstall = New System.Windows.Forms.ToolStripButton()
        Me.tsbfinance = New System.Windows.Forms.ToolStripButton()
        Me.tsbadmin = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbnew = New System.Windows.Forms.ToolStripButton()
        Me.tsbattach = New System.Windows.Forms.ToolStripButton()
        Me.tsbschedule = New System.Windows.Forms.ToolStripButton()
        Me.tsbalert = New System.Windows.Forms.ToolStripButton()
        Me.tsbfind = New System.Windows.Forms.ToolStripButton()
        Me.tsbmap = New System.Windows.Forms.ToolStripButton()
        Me.tsbtransfer = New System.Windows.Forms.ToolStripButton()
        Me.tsbrolodex = New System.Windows.Forms.ToolStripButton()
        Me.tsbchat = New System.Windows.Forms.ToolStripButton()
        Me.tsImportsPics = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Improveit360ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TestingFormACToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuggestionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BugsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnterASuggestionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompanyInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoNotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WorkHoursToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrimaryLeadSourcesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondaryLeadSourcesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnEditEmailTemplatesList = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ErrorLogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileVerticallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileHorizontallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ILIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.ILSmall = New System.Windows.Forms.ImageList(Me.components)
        Me.tmrAlerts = New System.Windows.Forms.Timer(Me.components)
        Me.tmrXFER = New System.Windows.Forms.Timer(Me.components)
        Me.tmrStartupLauncher = New System.Windows.Forms.Timer(Me.components)
        Me.ilCustomerHistory = New System.Windows.Forms.ImageList(Me.components)
        Me.tmrmanagealerts = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.ilScheduledTask = New System.Windows.Forms.ImageList(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsLoggedInAs = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsRecCount = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsProgress = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsNetworkStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsSqlSTatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TSMain.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TSMain
        '
        Me.TSMain.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TSMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.TSMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbmarketing, Me.tsbsales, Me.tsbinstall, Me.tsbfinance, Me.tsbadmin, Me.ToolStripSeparator1, Me.tsbnew, Me.tsbattach, Me.tsbschedule, Me.tsbalert, Me.tsbfind, Me.tsbmap, Me.tsbtransfer, Me.tsbrolodex, Me.tsbchat, Me.tsImportsPics})
        Me.TSMain.Location = New System.Drawing.Point(0, 24)
        Me.TSMain.Name = "TSMain"
        Me.TSMain.Size = New System.Drawing.Size(1016, 52)
        Me.TSMain.TabIndex = 1
        Me.TSMain.Text = "ToolStrip1"
        '
        'tsbmarketing
        '
        Me.tsbmarketing.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ColdCallingToolStripMenuItem, Me.WarmCallingToolStripMenuItem, Me.PreviousCustomersToolStripMenuItem, Me.RecoveryToolStripMenuItem, Me.ConfirmingToolStripMenuItem, Me.tsbMarketingManager})
        Me.tsbmarketing.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbmarketing.Image = CType(resources.GetObject("tsbmarketing.Image"), System.Drawing.Image)
        Me.tsbmarketing.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbmarketing.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbmarketing.Name = "tsbmarketing"
        Me.tsbmarketing.Size = New System.Drawing.Size(76, 49)
        Me.tsbmarketing.Text = "Marketing"
        Me.tsbmarketing.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ColdCallingToolStripMenuItem
        '
        Me.ColdCallingToolStripMenuItem.Image = CType(resources.GetObject("ColdCallingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ColdCallingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ColdCallingToolStripMenuItem.Name = "ColdCallingToolStripMenuItem"
        Me.ColdCallingToolStripMenuItem.Size = New System.Drawing.Size(205, 38)
        Me.ColdCallingToolStripMenuItem.Text = "Cold Calling"
        '
        'WarmCallingToolStripMenuItem
        '
        Me.WarmCallingToolStripMenuItem.Image = CType(resources.GetObject("WarmCallingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WarmCallingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.WarmCallingToolStripMenuItem.Name = "WarmCallingToolStripMenuItem"
        Me.WarmCallingToolStripMenuItem.Size = New System.Drawing.Size(205, 38)
        Me.WarmCallingToolStripMenuItem.Text = "Warm Calling"
        '
        'PreviousCustomersToolStripMenuItem
        '
        Me.PreviousCustomersToolStripMenuItem.Image = CType(resources.GetObject("PreviousCustomersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PreviousCustomersToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PreviousCustomersToolStripMenuItem.Name = "PreviousCustomersToolStripMenuItem"
        Me.PreviousCustomersToolStripMenuItem.Size = New System.Drawing.Size(205, 38)
        Me.PreviousCustomersToolStripMenuItem.Text = "Previous Customers"
        '
        'RecoveryToolStripMenuItem
        '
        Me.RecoveryToolStripMenuItem.Image = CType(resources.GetObject("RecoveryToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RecoveryToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RecoveryToolStripMenuItem.Name = "RecoveryToolStripMenuItem"
        Me.RecoveryToolStripMenuItem.Size = New System.Drawing.Size(205, 38)
        Me.RecoveryToolStripMenuItem.Text = "Recovery"
        '
        'ConfirmingToolStripMenuItem
        '
        Me.ConfirmingToolStripMenuItem.Image = Global.Latest.My.Resources.Resources.inetcpl_4480
        Me.ConfirmingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ConfirmingToolStripMenuItem.Name = "ConfirmingToolStripMenuItem"
        Me.ConfirmingToolStripMenuItem.Size = New System.Drawing.Size(205, 38)
        Me.ConfirmingToolStripMenuItem.Text = "Confirming"
        '
        'tsbMarketingManager
        '
        Me.tsbMarketingManager.Image = CType(resources.GetObject("tsbMarketingManager.Image"), System.Drawing.Image)
        Me.tsbMarketingManager.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbMarketingManager.Name = "tsbMarketingManager"
        Me.tsbMarketingManager.Size = New System.Drawing.Size(205, 38)
        Me.tsbMarketingManager.Text = "Marketing Manager"
        '
        'tsbsales
        '
        Me.tsbsales.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbsales.Image = CType(resources.GetObject("tsbsales.Image"), System.Drawing.Image)
        Me.tsbsales.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbsales.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbsales.Name = "tsbsales"
        Me.tsbsales.Size = New System.Drawing.Size(42, 49)
        Me.tsbsales.Text = "Sales"
        Me.tsbsales.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbinstall
        '
        Me.tsbinstall.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbinstall.Image = CType(resources.GetObject("tsbinstall.Image"), System.Drawing.Image)
        Me.tsbinstall.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbinstall.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbinstall.Name = "tsbinstall"
        Me.tsbinstall.Size = New System.Drawing.Size(74, 49)
        Me.tsbinstall.Text = "Installation"
        Me.tsbinstall.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbfinance
        '
        Me.tsbfinance.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbfinance.Image = CType(resources.GetObject("tsbfinance.Image"), System.Drawing.Image)
        Me.tsbfinance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbfinance.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbfinance.Name = "tsbfinance"
        Me.tsbfinance.Size = New System.Drawing.Size(64, 49)
        Me.tsbfinance.Text = "Financing"
        Me.tsbfinance.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbadmin
        '
        Me.tsbadmin.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbadmin.Image = CType(resources.GetObject("tsbadmin.Image"), System.Drawing.Image)
        Me.tsbadmin.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbadmin.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbadmin.Name = "tsbadmin"
        Me.tsbadmin.Size = New System.Drawing.Size(93, 49)
        Me.tsbadmin.Text = "Administration"
        Me.tsbadmin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 52)
        '
        'tsbnew
        '
        Me.tsbnew.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbnew.Image = CType(resources.GetObject("tsbnew.Image"), System.Drawing.Image)
        Me.tsbnew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbnew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbnew.Name = "tsbnew"
        Me.tsbnew.Size = New System.Drawing.Size(79, 49)
        Me.tsbnew.Text = "New Record"
        Me.tsbnew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbattach
        '
        Me.tsbattach.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbattach.Image = CType(resources.GetObject("tsbattach.Image"), System.Drawing.Image)
        Me.tsbattach.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbattach.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbattach.Name = "tsbattach"
        Me.tsbattach.Size = New System.Drawing.Size(76, 49)
        Me.tsbattach.Text = "Attach Files"
        Me.tsbattach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbschedule
        '
        Me.tsbschedule.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbschedule.Image = CType(resources.GetObject("tsbschedule.Image"), System.Drawing.Image)
        Me.tsbschedule.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbschedule.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbschedule.Name = "tsbschedule"
        Me.tsbschedule.Size = New System.Drawing.Size(102, 49)
        Me.tsbschedule.Text = "Schedule Action"
        Me.tsbschedule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbalert
        '
        Me.tsbalert.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbalert.Image = CType(resources.GetObject("tsbalert.Image"), System.Drawing.Image)
        Me.tsbalert.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbalert.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbalert.Name = "tsbalert"
        Me.tsbalert.Size = New System.Drawing.Size(38, 49)
        Me.tsbalert.Text = "Alert"
        Me.tsbalert.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbfind
        '
        Me.tsbfind.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbfind.Image = CType(resources.GetObject("tsbfind.Image"), System.Drawing.Image)
        Me.tsbfind.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbfind.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbfind.Name = "tsbfind"
        Me.tsbfind.Size = New System.Drawing.Size(36, 49)
        Me.tsbfind.Text = "Find"
        Me.tsbfind.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbmap
        '
        Me.tsbmap.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbmap.Image = CType(resources.GetObject("tsbmap.Image"), System.Drawing.Image)
        Me.tsbmap.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbmap.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbmap.Name = "tsbmap"
        Me.tsbmap.Size = New System.Drawing.Size(58, 49)
        Me.tsbmap.Text = "Mapping"
        Me.tsbmap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbtransfer
        '
        Me.tsbtransfer.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbtransfer.Image = CType(resources.GetObject("tsbtransfer.Image"), System.Drawing.Image)
        Me.tsbtransfer.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbtransfer.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbtransfer.Name = "tsbtransfer"
        Me.tsbtransfer.Size = New System.Drawing.Size(90, 49)
        Me.tsbtransfer.Text = "Transfer Lead"
        Me.tsbtransfer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbrolodex
        '
        Me.tsbrolodex.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbrolodex.Image = CType(resources.GetObject("tsbrolodex.Image"), System.Drawing.Image)
        Me.tsbrolodex.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbrolodex.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbrolodex.Name = "tsbrolodex"
        Me.tsbrolodex.Size = New System.Drawing.Size(57, 49)
        Me.tsbrolodex.Text = "Rolodex"
        Me.tsbrolodex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbchat
        '
        Me.tsbchat.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbchat.Image = Global.Latest.My.Resources.Resources.chat
        Me.tsbchat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbchat.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbchat.Name = "tsbchat"
        Me.tsbchat.Size = New System.Drawing.Size(38, 49)
        Me.tsbchat.Text = "Chat"
        Me.tsbchat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsImportsPics
        '
        Me.tsImportsPics.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsImportsPics.Image = CType(resources.GetObject("tsImportsPics.Image"), System.Drawing.Image)
        Me.tsImportsPics.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsImportsPics.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsImportsPics.Name = "tsImportsPics"
        Me.tsImportsPics.Size = New System.Drawing.Size(76, 49)
        Me.tsImportsPics.Text = "Import Pics"
        Me.tsImportsPics.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.UsersToolStripMenuItem, Me.SuggestionsToolStripMenuItem, Me.ViewToolStripMenuItem, Me.WindowsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1016, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportDataToolStripMenuItem, Me.ToolStripSeparator3, Me.ExitToolStripMenuItem, Me.TestingFormACToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ImportDataToolStripMenuItem
        '
        Me.ImportDataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Improveit360ToolStripMenuItem})
        Me.ImportDataToolStripMenuItem.Name = "ImportDataToolStripMenuItem"
        Me.ImportDataToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ImportDataToolStripMenuItem.Text = "Import D&ata"
        '
        'Improveit360ToolStripMenuItem
        '
        Me.Improveit360ToolStripMenuItem.Name = "Improveit360ToolStripMenuItem"
        Me.Improveit360ToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.Improveit360ToolStripMenuItem.Text = "Improveit! 360"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(168, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ExitToolStripMenuItem.Text = "Exit - ( ALT + F4 )"
        '
        'TestingFormACToolStripMenuItem
        '
        Me.TestingFormACToolStripMenuItem.Name = "TestingFormACToolStripMenuItem"
        Me.TestingFormACToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.TestingFormACToolStripMenuItem.Text = "Testing Form - AC"
        '
        'UsersToolStripMenuItem
        '
        Me.UsersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoginToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.UsersToolStripMenuItem.Name = "UsersToolStripMenuItem"
        Me.UsersToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.UsersToolStripMenuItem.Text = "Users"
        '
        'LoginToolStripMenuItem
        '
        Me.LoginToolStripMenuItem.Name = "LoginToolStripMenuItem"
        Me.LoginToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.LoginToolStripMenuItem.Text = "&Login"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.LogoutToolStripMenuItem.Text = "Lo&gout"
        '
        'SuggestionsToolStripMenuItem
        '
        Me.SuggestionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BugsToolStripMenuItem, Me.EnterASuggestionToolStripMenuItem})
        Me.SuggestionsToolStripMenuItem.Name = "SuggestionsToolStripMenuItem"
        Me.SuggestionsToolStripMenuItem.Size = New System.Drawing.Size(114, 20)
        Me.SuggestionsToolStripMenuItem.Text = "Suggestions/Bugs"
        '
        'BugsToolStripMenuItem
        '
        Me.BugsToolStripMenuItem.Name = "BugsToolStripMenuItem"
        Me.BugsToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.BugsToolStripMenuItem.Text = "Bugs"
        '
        'EnterASuggestionToolStripMenuItem
        '
        Me.EnterASuggestionToolStripMenuItem.Name = "EnterASuggestionToolStripMenuItem"
        Me.EnterASuggestionToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.EnterASuggestionToolStripMenuItem.Text = "Enter a Suggestion"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompanyInformationToolStripMenuItem, Me.AutoNotesToolStripMenuItem, Me.ToolStripMenuItem2, Me.ErrorLogsToolStripMenuItem, Me.BackupToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.ViewToolStripMenuItem.Text = "View / Edit"
        '
        'CompanyInformationToolStripMenuItem
        '
        Me.CompanyInformationToolStripMenuItem.Name = "CompanyInformationToolStripMenuItem"
        Me.CompanyInformationToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.CompanyInformationToolStripMenuItem.Text = "Company Information"
        '
        'AutoNotesToolStripMenuItem
        '
        Me.AutoNotesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.WorkHoursToolStripMenuItem, Me.PrimaryLeadSourcesToolStripMenuItem, Me.SecondaryLeadSourcesToolStripMenuItem, Me.ProductsToolStripMenuItem, Me.btnEditEmailTemplatesList})
        Me.AutoNotesToolStripMenuItem.Name = "AutoNotesToolStripMenuItem"
        Me.AutoNotesToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.AutoNotesToolStripMenuItem.Text = "Lists"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(201, 22)
        Me.ToolStripMenuItem1.Text = "Auto Notes"
        '
        'WorkHoursToolStripMenuItem
        '
        Me.WorkHoursToolStripMenuItem.Name = "WorkHoursToolStripMenuItem"
        Me.WorkHoursToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.WorkHoursToolStripMenuItem.Text = "Work Hours"
        '
        'PrimaryLeadSourcesToolStripMenuItem
        '
        Me.PrimaryLeadSourcesToolStripMenuItem.Name = "PrimaryLeadSourcesToolStripMenuItem"
        Me.PrimaryLeadSourcesToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.PrimaryLeadSourcesToolStripMenuItem.Text = "Primary Lead Sources"
        '
        'SecondaryLeadSourcesToolStripMenuItem
        '
        Me.SecondaryLeadSourcesToolStripMenuItem.Enabled = False
        Me.SecondaryLeadSourcesToolStripMenuItem.Name = "SecondaryLeadSourcesToolStripMenuItem"
        Me.SecondaryLeadSourcesToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.SecondaryLeadSourcesToolStripMenuItem.Text = "Secondary Lead Sources"
        '
        'ProductsToolStripMenuItem
        '
        Me.ProductsToolStripMenuItem.Name = "ProductsToolStripMenuItem"
        Me.ProductsToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.ProductsToolStripMenuItem.Text = "Products"
        '
        'btnEditEmailTemplatesList
        '
        Me.btnEditEmailTemplatesList.Name = "btnEditEmailTemplatesList"
        Me.btnEditEmailTemplatesList.Size = New System.Drawing.Size(201, 22)
        Me.btnEditEmailTemplatesList.Text = "Email Templates"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(189, 6)
        '
        'ErrorLogsToolStripMenuItem
        '
        Me.ErrorLogsToolStripMenuItem.Name = "ErrorLogsToolStripMenuItem"
        Me.ErrorLogsToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.ErrorLogsToolStripMenuItem.Text = "Error Logs"
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'WindowsToolStripMenuItem
        '
        Me.WindowsToolStripMenuItem.DoubleClickEnabled = True
        Me.WindowsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TileVerticallyToolStripMenuItem, Me.TileHorizontallyToolStripMenuItem, Me.ToolStripSeparator2})
        Me.WindowsToolStripMenuItem.Name = "WindowsToolStripMenuItem"
        Me.WindowsToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.WindowsToolStripMenuItem.Text = "Windows"
        '
        'TileVerticallyToolStripMenuItem
        '
        Me.TileVerticallyToolStripMenuItem.Name = "TileVerticallyToolStripMenuItem"
        Me.TileVerticallyToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.TileVerticallyToolStripMenuItem.Text = "Tile Vertically"
        '
        'TileHorizontallyToolStripMenuItem
        '
        Me.TileHorizontallyToolStripMenuItem.Name = "TileHorizontallyToolStripMenuItem"
        Me.TileHorizontallyToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.TileHorizontallyToolStripMenuItem.Text = "Tile Horizontally"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(157, 6)
        '
        'ILIcons
        '
        Me.ILIcons.ImageStream = CType(resources.GetObject("ILIcons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ILIcons.TransparentColor = System.Drawing.Color.Transparent
        Me.ILIcons.Images.SetKeyName(0, "ui_1074.ico")
        '
        'ILSmall
        '
        Me.ILSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ILSmall.ImageSize = New System.Drawing.Size(16, 16)
        Me.ILSmall.TransparentColor = System.Drawing.Color.Transparent
        '
        'tmrAlerts
        '
        Me.tmrAlerts.Interval = 30000
        '
        'tmrXFER
        '
        Me.tmrXFER.Interval = 1000
        '
        'tmrStartupLauncher
        '
        Me.tmrStartupLauncher.Interval = 2000
        '
        'ilCustomerHistory
        '
        Me.ilCustomerHistory.ImageStream = CType(resources.GetObject("ilCustomerHistory.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilCustomerHistory.TransparentColor = System.Drawing.Color.Transparent
        Me.ilCustomerHistory.Images.SetKeyName(0, "marketing manager4.ico")
        Me.ilCustomerHistory.Images.SetKeyName(1, "cash.ico")
        Me.ilCustomerHistory.Images.SetKeyName(2, "Finance Dept.ico")
        Me.ilCustomerHistory.Images.SetKeyName(3, "hammerused.ico")
        Me.ilCustomerHistory.Images.SetKeyName(4, "recovery2.ico")
        Me.ilCustomerHistory.Images.SetKeyName(5, "phone4.ico")
        Me.ilCustomerHistory.Images.SetKeyName(6, "lock.ico")
        Me.ilCustomerHistory.Images.SetKeyName(7, "inetcpl_4480.ico")
        Me.ilCustomerHistory.Images.SetKeyName(8, "Previous Customer.ico")
        Me.ilCustomerHistory.Images.SetKeyName(9, "setappt16.ico")
        Me.ilCustomerHistory.Images.SetKeyName(10, "Notes4.ico")
        Me.ilCustomerHistory.Images.SetKeyName(11, "Cancel.ico")
        Me.ilCustomerHistory.Images.SetKeyName(12, "Do not call2.ico")
        Me.ilCustomerHistory.Images.SetKeyName(13, "done2.ico")
        Me.ilCustomerHistory.Images.SetKeyName(14, "improveit360_logo.ico")
        Me.ilCustomerHistory.Images.SetKeyName(15, "Call&Cancel16.ico")
        Me.ilCustomerHistory.Images.SetKeyName(16, "new record32(2).ico")
        Me.ilCustomerHistory.Images.SetKeyName(17, "Warm Caller.ico")
        Me.ilCustomerHistory.Images.SetKeyName(18, "Call&Cancel16.ico")
        '
        'tmrmanagealerts
        '
        Me.tmrmanagealerts.Interval = 200
        '
        'ilScheduledTask
        '
        Me.ilScheduledTask.ImageStream = CType(resources.GetObject("ilScheduledTask.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilScheduledTask.TransparentColor = System.Drawing.Color.Transparent
        Me.ilScheduledTask.Images.SetKeyName(0, "done3.ico")
        Me.ilScheduledTask.Images.SetKeyName(1, "0135.ico")
        Me.ilScheduledTask.Images.SetKeyName(2, "Notes4.ico")
        Me.ilScheduledTask.Images.SetKeyName(3, "attached files icon.ico")
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.tsLoggedInAs, Me.ToolStripStatusLabel2, Me.tsRecCount, Me.ToolStripStatusLabel3, Me.tsProgress, Me.ToolStripStatusLabel4, Me.tsNetworkStatus, Me.ToolStripStatusLabel5, Me.tsSqlSTatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 712)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1016, 22)
        Me.StatusStrip1.TabIndex = 12
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(85, 17)
        Me.ToolStripStatusLabel1.Text = "Logged In As : "
        '
        'tsLoggedInAs
        '
        Me.tsLoggedInAs.Name = "tsLoggedInAs"
        Me.tsLoggedInAs.Size = New System.Drawing.Size(10, 17)
        Me.tsLoggedInAs.Text = " "
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(58, 17)
        Me.ToolStripStatusLabel2.Text = "Records : "
        '
        'tsRecCount
        '
        Me.tsRecCount.Name = "tsRecCount"
        Me.tsRecCount.Size = New System.Drawing.Size(10, 17)
        Me.tsRecCount.Text = " "
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(160, 17)
        Me.ToolStripStatusLabel3.Text = "Current Operation Progress : "
        '
        'tsProgress
        '
        Me.tsProgress.Name = "tsProgress"
        Me.tsProgress.Size = New System.Drawing.Size(100, 16)
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(93, 17)
        Me.ToolStripStatusLabel4.Text = "Network Status :"
        '
        'tsNetworkStatus
        '
        Me.tsNetworkStatus.Name = "tsNetworkStatus"
        Me.tsNetworkStatus.Size = New System.Drawing.Size(10, 17)
        Me.tsNetworkStatus.Text = " "
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(72, 17)
        Me.ToolStripStatusLabel5.Text = "SQL Status : "
        '
        'tsSqlSTatus
        '
        Me.tsSqlSTatus.Name = "tsSqlSTatus"
        Me.tsSqlSTatus.Size = New System.Drawing.Size(10, 17)
        Me.tsSqlSTatus.Text = " "
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 734)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.TSMain)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TSMain.ResumeLayout(False)
        Me.TSMain.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TSMain As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbsales As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbinstall As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbfinance As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbmarketing As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents ColdCallingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WarmCallingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PreviousCustomersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecoveryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConfirmingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbMarketingManager As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsbadmin As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbnew As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbattach As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbschedule As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbalert As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbfind As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbmap As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbtransfer As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbrolodex As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbchat As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsImportsPics As System.Windows.Forms.ToolStripButton
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ILIcons As System.Windows.Forms.ImageList
    Friend WithEvents ILSmall As System.Windows.Forms.ImageList
    Friend WithEvents UsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tmrAlerts As System.Windows.Forms.Timer
    Friend WithEvents tmrXFER As System.Windows.Forms.Timer
    Friend WithEvents tmrStartupLauncher As System.Windows.Forms.Timer
    Friend WithEvents SuggestionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BugsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnterASuggestionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ilCustomerHistory As System.Windows.Forms.ImageList
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompanyInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoNotesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WorkHoursToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrimaryLeadSourcesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SecondaryLeadSourcesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ErrorLogsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileVerticallyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileHorizontallyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tmrmanagealerts As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents ilScheduledTask As System.Windows.Forms.ImageList
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsLoggedInAs As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsProgress As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsRecCount As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsNetworkStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsSqlSTatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ImportDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Improveit360ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestingFormACToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnEditEmailTemplatesList As System.Windows.Forms.ToolStripMenuItem

End Class
