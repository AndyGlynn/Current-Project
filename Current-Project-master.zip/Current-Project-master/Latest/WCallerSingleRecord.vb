Public Class WCallerSingleRecord

End Class