Public Class open_setappt

    Public Sub New()
        SetAppt.ShowDialog()
    End Sub
End Class
