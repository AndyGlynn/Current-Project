Module PENDING_REQUEST_INFO
    Public Who As String = ""
    Public LineHoldingOn As String = ""
    Public XFER_NOTES As String = ""
    Public LeadNumber As String = ""
    Public Auto_RESPONSE As String = ""

    Public GetStartupForm As Boolean = False

    Public IncommingChatMsg As Boolean = False
    Public Sender As String = ""
    Public MSG As String = ""

End Module
