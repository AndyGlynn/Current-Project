﻿Imports MapPoint
Imports AxMapPoint

Public Class MAPPOINT_LOGIC_V3
    Public ctrl As AxMapPoint.AxMappointControl

    Public Sub New(ByVal MapControl As AxMapPoint.AxMappointControl)

    End Sub

End Class
