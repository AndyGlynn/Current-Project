﻿Public Class frmPCList

    Private Sub frmPCList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class