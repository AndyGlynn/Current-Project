﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTesting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbTesting = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.txtPWD = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txtLName = New System.Windows.Forms.TextBox()
        Me.txtFName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.cboIPV4s = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.rtfMSG = New System.Windows.Forms.RichTextBox()
        Me.txtSubject = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtFrom = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnBlast = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.txtScrubID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.rtfScrubbed = New System.Windows.Forms.RichTextBox()
        Me.rtfUnscrubbed = New System.Windows.Forms.RichTextBox()
        Me.txtRecID = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.rtfPreview = New System.Windows.Forms.RichTextBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.lblDepartment = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblCurrentUser = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.cboMailTemplates = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lstSimulated = New System.Windows.Forms.ListView()
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.txtCaptText = New System.Windows.Forms.TextBox()
        Me.txtValidText = New System.Windows.Forms.TextBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.txtStripSpecials = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.cboDomains = New System.Windows.Forms.ComboBox()
        Me.cboCityStateZip = New System.Windows.Forms.ComboBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.txtToTwoChar = New System.Windows.Forms.TextBox()
        Me.txtFromTwoChar = New System.Windows.Forms.TextBox()
        Me.tbTesting.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.SuspendLayout()
        '
        'tbTesting
        '
        Me.tbTesting.Controls.Add(Me.TabPage4)
        Me.tbTesting.Controls.Add(Me.TabPage1)
        Me.tbTesting.Controls.Add(Me.TabPage2)
        Me.tbTesting.Controls.Add(Me.TabPage3)
        Me.tbTesting.Controls.Add(Me.TabPage5)
        Me.tbTesting.Controls.Add(Me.TabPage6)
        Me.tbTesting.Controls.Add(Me.TabPage7)
        Me.tbTesting.Location = New System.Drawing.Point(12, 12)
        Me.tbTesting.Name = "tbTesting"
        Me.tbTesting.SelectedIndex = 0
        Me.tbTesting.Size = New System.Drawing.Size(992, 543)
        Me.tbTesting.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Button16)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(984, 517)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Import / Export"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button5)
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.txtPWD)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.txtLName)
        Me.TabPage1.Controls.Add(Me.txtFName)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.cboIPV4s)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(984, 517)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "USER_LOGICv2.vb"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(132, 211)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(121, 23)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "Form and Screen SZ"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(16, 211)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(110, 23)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "Get Usr OBJ"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'txtPWD
        '
        Me.txtPWD.Location = New System.Drawing.Point(132, 146)
        Me.txtPWD.Name = "txtPWD"
        Me.txtPWD.Size = New System.Drawing.Size(121, 20)
        Me.txtPWD.TabIndex = 9
        Me.txtPWD.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(47, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "PWD : "
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(132, 182)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(121, 23)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "Can Connect"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(132, 111)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(121, 20)
        Me.txtLName.TabIndex = 6
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(132, 78)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(121, 20)
        Me.txtFName.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "LName"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(47, 81)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "FName"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 182)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(110, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "User Exists : "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'cboIPV4s
        '
        Me.cboIPV4s.FormattingEnabled = True
        Me.cboIPV4s.Location = New System.Drawing.Point(132, 21)
        Me.cboIPV4s.Name = "cboIPV4s"
        Me.cboIPV4s.Size = New System.Drawing.Size(121, 21)
        Me.cboIPV4s.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(110, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Get IPV4s"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(984, 517)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "EmailIssueLead.vb"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.rtfMSG)
        Me.GroupBox1.Controls.Add(Me.txtSubject)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtFrom)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtTo)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.btnBlast)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 222)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Send Blast Mail"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(18, 193)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 9
        Me.Button6.Text = "Test Values"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 120)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(91, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Body / Message :"
        '
        'rtfMSG
        '
        Me.rtfMSG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.rtfMSG.Location = New System.Drawing.Point(145, 120)
        Me.rtfMSG.Name = "rtfMSG"
        Me.rtfMSG.Size = New System.Drawing.Size(117, 67)
        Me.rtfMSG.TabIndex = 7
        Me.rtfMSG.Text = ""
        '
        'txtSubject
        '
        Me.txtSubject.Location = New System.Drawing.Point(145, 93)
        Me.txtSubject.Name = "txtSubject"
        Me.txtSubject.Size = New System.Drawing.Size(117, 20)
        Me.txtSubject.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(15, 96)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Subject :"
        '
        'txtFrom
        '
        Me.txtFrom.Location = New System.Drawing.Point(145, 58)
        Me.txtFrom.Name = "txtFrom"
        Me.txtFrom.Size = New System.Drawing.Size(117, 20)
        Me.txtFrom.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 61)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "From (Display Name) :"
        '
        'txtTo
        '
        Me.txtTo.Location = New System.Drawing.Point(145, 23)
        Me.txtTo.Name = "txtTo"
        Me.txtTo.Size = New System.Drawing.Size(117, 20)
        Me.txtTo.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "To : "
        '
        'btnBlast
        '
        Me.btnBlast.Location = New System.Drawing.Point(187, 193)
        Me.btnBlast.Name = "btnBlast"
        Me.btnBlast.Size = New System.Drawing.Size(75, 23)
        Me.btnBlast.TabIndex = 0
        Me.btnBlast.Text = "Send Mail"
        Me.btnBlast.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Button9)
        Me.TabPage3.Controls.Add(Me.Button8)
        Me.TabPage3.Controls.Add(Me.CheckedListBox1)
        Me.TabPage3.Controls.Add(Me.Button7)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(984, 517)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Printing"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(19, 313)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(238, 23)
        Me.Button9.TabIndex = 3
        Me.Button9.Text = "Generate Table Of Leads"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(19, 284)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(238, 23)
        Me.Button8.TabIndex = 2
        Me.Button8.Text = "Simulate List Of Lead Numbers"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(19, 79)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(238, 199)
        Me.CheckedListBox1.TabIndex = 1
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(49, 21)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(132, 23)
        Me.Button7.TabIndex = 0
        Me.Button7.Text = "frmPrint Show()"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.txtScrubID)
        Me.TabPage5.Controls.Add(Me.Label11)
        Me.TabPage5.Controls.Add(Me.Button11)
        Me.TabPage5.Controls.Add(Me.Label10)
        Me.TabPage5.Controls.Add(Me.Label9)
        Me.TabPage5.Controls.Add(Me.rtfScrubbed)
        Me.TabPage5.Controls.Add(Me.rtfUnscrubbed)
        Me.TabPage5.Controls.Add(Me.txtRecID)
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Controls.Add(Me.Button10)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(984, 517)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Single Record Convert"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'txtScrubID
        '
        Me.txtScrubID.Location = New System.Drawing.Point(695, 21)
        Me.txtScrubID.Name = "txtScrubID"
        Me.txtScrubID.Size = New System.Drawing.Size(100, 20)
        Me.txtScrubID.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(483, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(133, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Test Lead Num To Scrub :"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(813, 18)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 23)
        Me.Button11.TabIndex = 7
        Me.Button11.Text = "Scrub It"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(483, 53)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Scrubbed Template Text :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(17, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(119, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Original Template Text :"
        '
        'rtfScrubbed
        '
        Me.rtfScrubbed.Location = New System.Drawing.Point(486, 72)
        Me.rtfScrubbed.Name = "rtfScrubbed"
        Me.rtfScrubbed.Size = New System.Drawing.Size(402, 433)
        Me.rtfScrubbed.TabIndex = 4
        Me.rtfScrubbed.Text = ""
        '
        'rtfUnscrubbed
        '
        Me.rtfUnscrubbed.Location = New System.Drawing.Point(17, 72)
        Me.rtfUnscrubbed.Name = "rtfUnscrubbed"
        Me.rtfUnscrubbed.Size = New System.Drawing.Size(402, 433)
        Me.rtfUnscrubbed.TabIndex = 3
        Me.rtfUnscrubbed.Text = ""
        '
        'txtRecID
        '
        Me.txtRecID.Location = New System.Drawing.Point(177, 18)
        Me.txtRecID.Name = "txtRecID"
        Me.txtRecID.Size = New System.Drawing.Size(100, 20)
        Me.txtRecID.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(148, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Lead Num / Record Number :"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(283, 16)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(136, 23)
        Me.Button10.TabIndex = 0
        Me.Button10.Text = "Convert Lead ( )"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.Button15)
        Me.TabPage6.Controls.Add(Me.Button14)
        Me.TabPage6.Controls.Add(Me.Button13)
        Me.TabPage6.Controls.Add(Me.Label15)
        Me.TabPage6.Controls.Add(Me.rtfPreview)
        Me.TabPage6.Controls.Add(Me.Button12)
        Me.TabPage6.Controls.Add(Me.lblDepartment)
        Me.TabPage6.Controls.Add(Me.Label16)
        Me.TabPage6.Controls.Add(Me.lblCurrentUser)
        Me.TabPage6.Controls.Add(Me.Label14)
        Me.TabPage6.Controls.Add(Me.cboMailTemplates)
        Me.TabPage6.Controls.Add(Me.Label13)
        Me.TabPage6.Controls.Add(Me.Label12)
        Me.TabPage6.Controls.Add(Me.lstSimulated)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(984, 517)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Bulk Template Mail"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(351, 474)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(157, 23)
        Me.Button15.TabIndex = 15
        Me.Button15.Text = "Send FIRST One ONLY"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(669, 474)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(236, 23)
        Me.Button14.TabIndex = 14
        Me.Button14.Text = "Send These 25 Leads [ TEST ACCOUNT ]"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(191, 76)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(129, 23)
        Me.Button13.TabIndex = 13
        Me.Button13.Text = "Pop Templates ( ) "
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(351, 23)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(139, 13)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Preview Template Applied : "
        '
        'rtfPreview
        '
        Me.rtfPreview.Location = New System.Drawing.Point(351, 49)
        Me.rtfPreview.Name = "rtfPreview"
        Me.rtfPreview.ReadOnly = True
        Me.rtfPreview.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rtfPreview.Size = New System.Drawing.Size(554, 418)
        Me.rtfPreview.TabIndex = 11
        Me.rtfPreview.Text = ""
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(18, 474)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(149, 23)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "Pop List ( )"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'lblDepartment
        '
        Me.lblDepartment.AutoSize = True
        Me.lblDepartment.Location = New System.Drawing.Point(195, 188)
        Me.lblDepartment.Name = "lblDepartment"
        Me.lblDepartment.Size = New System.Drawing.Size(10, 13)
        Me.lblDepartment.TabIndex = 9
        Me.lblDepartment.Text = " "
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(188, 163)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(108, 13)
        Me.Label16.TabIndex = 8
        Me.Label16.Text = "Current Department : "
        '
        'lblCurrentUser
        '
        Me.lblCurrentUser.AutoSize = True
        Me.lblCurrentUser.Location = New System.Drawing.Point(195, 138)
        Me.lblCurrentUser.Name = "lblCurrentUser"
        Me.lblCurrentUser.Size = New System.Drawing.Size(10, 13)
        Me.lblCurrentUser.TabIndex = 7
        Me.lblCurrentUser.Text = " "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(188, 113)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Current User : "
        '
        'cboMailTemplates
        '
        Me.cboMailTemplates.FormattingEnabled = True
        Me.cboMailTemplates.Location = New System.Drawing.Point(191, 49)
        Me.cboMailTemplates.Name = "cboMailTemplates"
        Me.cboMailTemplates.Size = New System.Drawing.Size(129, 21)
        Me.cboMailTemplates.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(188, 23)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(132, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Mock Template To Apply :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(15, 23)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 13)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Simulated List Of Lead Nums : "
        '
        'lstSimulated
        '
        Me.lstSimulated.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colID, Me.colName})
        Me.lstSimulated.Location = New System.Drawing.Point(18, 49)
        Me.lstSimulated.Name = "lstSimulated"
        Me.lstSimulated.Size = New System.Drawing.Size(149, 418)
        Me.lstSimulated.TabIndex = 2
        Me.lstSimulated.UseCompatibleStateImageBehavior = False
        Me.lstSimulated.View = System.Windows.Forms.View.Details
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 50
        '
        'colName
        '
        Me.colName.Text = "Name"
        Me.colName.Width = 93
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(12, 23)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(262, 23)
        Me.Button16.TabIndex = 0
        Me.Button16.Text = "Get Zip / Email Domains [ IMPORT ]"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.txtFromTwoChar)
        Me.TabPage7.Controls.Add(Me.txtToTwoChar)
        Me.TabPage7.Controls.Add(Me.Button23)
        Me.TabPage7.Controls.Add(Me.Button22)
        Me.TabPage7.Controls.Add(Me.cboCityStateZip)
        Me.TabPage7.Controls.Add(Me.Button21)
        Me.TabPage7.Controls.Add(Me.cboDomains)
        Me.TabPage7.Controls.Add(Me.Button20)
        Me.TabPage7.Controls.Add(Me.txtStripSpecials)
        Me.TabPage7.Controls.Add(Me.Button19)
        Me.TabPage7.Controls.Add(Me.txtValidText)
        Me.TabPage7.Controls.Add(Me.Button18)
        Me.TabPage7.Controls.Add(Me.txtCaptText)
        Me.TabPage7.Controls.Add(Me.Button17)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(984, 517)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Formatting / Validation"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(18, 19)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(152, 23)
        Me.Button17.TabIndex = 0
        Me.Button17.Text = "Capt Text / Format Names"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'txtCaptText
        '
        Me.txtCaptText.Location = New System.Drawing.Point(190, 22)
        Me.txtCaptText.Name = "txtCaptText"
        Me.txtCaptText.Size = New System.Drawing.Size(208, 20)
        Me.txtCaptText.TabIndex = 1
        '
        'txtValidText
        '
        Me.txtValidText.Location = New System.Drawing.Point(190, 59)
        Me.txtValidText.Name = "txtValidText"
        Me.txtValidText.Size = New System.Drawing.Size(208, 20)
        Me.txtValidText.TabIndex = 3
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(18, 56)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(152, 23)
        Me.Button18.TabIndex = 2
        Me.Button18.Text = "IsTextValid ( )"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'txtStripSpecials
        '
        Me.txtStripSpecials.Location = New System.Drawing.Point(190, 92)
        Me.txtStripSpecials.Name = "txtStripSpecials"
        Me.txtStripSpecials.Size = New System.Drawing.Size(208, 20)
        Me.txtStripSpecials.TabIndex = 5
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(18, 89)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(152, 23)
        Me.Button19.TabIndex = 4
        Me.Button19.Text = "StripSpecials( )"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(18, 131)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(152, 23)
        Me.Button20.TabIndex = 6
        Me.Button20.Text = "Get Valid Email Domains"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'cboDomains
        '
        Me.cboDomains.FormattingEnabled = True
        Me.cboDomains.Location = New System.Drawing.Point(190, 131)
        Me.cboDomains.Name = "cboDomains"
        Me.cboDomains.Size = New System.Drawing.Size(208, 21)
        Me.cboDomains.TabIndex = 7
        '
        'cboCityStateZip
        '
        Me.cboCityStateZip.FormattingEnabled = True
        Me.cboCityStateZip.Location = New System.Drawing.Point(190, 172)
        Me.cboCityStateZip.Name = "cboCityStateZip"
        Me.cboCityStateZip.Size = New System.Drawing.Size(352, 21)
        Me.cboCityStateZip.TabIndex = 9
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(18, 172)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(152, 23)
        Me.Button21.TabIndex = 8
        Me.Button21.Text = "Get US City State Zip"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(18, 215)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(152, 23)
        Me.Button22.TabIndex = 10
        Me.Button22.Text = "Convert State => Two Char"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(18, 254)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(152, 23)
        Me.Button23.TabIndex = 11
        Me.Button23.Text = "Convert State <= Two Char"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'txtToTwoChar
        '
        Me.txtToTwoChar.Location = New System.Drawing.Point(190, 217)
        Me.txtToTwoChar.Name = "txtToTwoChar"
        Me.txtToTwoChar.Size = New System.Drawing.Size(208, 20)
        Me.txtToTwoChar.TabIndex = 12
        '
        'txtFromTwoChar
        '
        Me.txtFromTwoChar.Location = New System.Drawing.Point(190, 254)
        Me.txtFromTwoChar.Name = "txtFromTwoChar"
        Me.txtFromTwoChar.Size = New System.Drawing.Size(208, 20)
        Me.txtFromTwoChar.TabIndex = 13
        '
        'frmTesting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 567)
        Me.Controls.Add(Me.tbTesting)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTesting"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin Testing Form"
        Me.tbTesting.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tbTesting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents cboIPV4s As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents txtLName As System.Windows.Forms.TextBox
    Friend WithEvents txtFName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtPWD As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnBlast As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents rtfMSG As System.Windows.Forms.RichTextBox
    Friend WithEvents txtSubject As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtTo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents txtRecID As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents rtfScrubbed As System.Windows.Forms.RichTextBox
    Friend WithEvents rtfUnscrubbed As System.Windows.Forms.RichTextBox
    Friend WithEvents txtScrubID As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents lblDepartment As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lblCurrentUser As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents cboMailTemplates As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lstSimulated As System.Windows.Forms.ListView
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents rtfPreview As System.Windows.Forms.RichTextBox
    Friend WithEvents colID As System.Windows.Forms.ColumnHeader
    Friend WithEvents colName As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents txtCaptText As System.Windows.Forms.TextBox
    Friend WithEvents txtValidText As System.Windows.Forms.TextBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents txtStripSpecials As System.Windows.Forms.TextBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents cboDomains As System.Windows.Forms.ComboBox
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents cboCityStateZip As System.Windows.Forms.ComboBox
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents txtFromTwoChar As System.Windows.Forms.TextBox
    Friend WithEvents txtToTwoChar As System.Windows.Forms.TextBox
End Class
