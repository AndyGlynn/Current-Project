Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Net.Sockets


Module STATIC_VARIABLES2
    Public Const ProgramName As String = "Improvit360"
    Public cnn2 As String = "Data Source=Server\SQLEXPRESS;Initial Catalog=iss;Trusted_Connection=true;"
#Region "User Information"
    'Public CurrentUser As String = ""
    'Public CurrentID As String = "0"
    'Public UserPWD As String = ""
    'Public ColdCall As Boolean
    'Public WarmCall As Boolean
    'Public PreviousCust As Boolean
    'Public Recovery As Boolean
    'Public Confirmer As Boolean
    'Public SalesManager As Boolean
    'Public MarketingManager As Boolean
    'Public Finance As Boolean
    'Public Install As Boolean
    'Public Administration As Boolean
    'Public StartUpForm As String = ""
    'Public CurrentForm As String = ""
    'Public LoggedOn As Boolean
    'Public DoNotShowMapping As Boolean
    'Public ManagerFirstName As String = ""
    'Public ManagerLastName As String = ""
    'Public MachineName As String = ""
    'Public IP As String = "127.0.0.1"
    'Public LicenseKey As String = "AAAAA-BBBBB-CCCCC-DDDDD-FFFFF-1"
    'Public LeaseKey As String = "000-00000-001"
    'Public Server_Assigned_Hash As String = ""
    'Public NET_CLIENT As TcpClient

    'Public PendingXFER As Boolean = False

#End Region

End Module
