<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CommonNFO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnClose = New System.Windows.Forms.Button
        Me.lblAddress = New System.Windows.Forms.Label
        Me.lblID = New System.Windows.Forms.Label
        Me.lblContact = New System.Windows.Forms.Label
        Me.lblHousePhone = New System.Windows.Forms.Label
        Me.lblAltPhone = New System.Windows.Forms.Label
        Me.lblPhone1Type = New System.Windows.Forms.Label
        Me.lblAltPhone2 = New System.Windows.Forms.Label
        Me.lblPhone2Type = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblPhone2Type)
        Me.GroupBox1.Controls.Add(Me.lblAltPhone2)
        Me.GroupBox1.Controls.Add(Me.lblPhone1Type)
        Me.GroupBox1.Controls.Add(Me.lblAltPhone)
        Me.GroupBox1.Controls.Add(Me.lblHousePhone)
        Me.GroupBox1.Controls.Add(Me.lblContact)
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Controls.Add(Me.lblAddress)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(489, 148)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(202, 166)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 1
        Me.btnClose.Text = "OK"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.Location = New System.Drawing.Point(19, 92)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(12, 16)
        Me.lblAddress.TabIndex = 0
        Me.lblAddress.Text = " "
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(19, 20)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(12, 16)
        Me.lblID.TabIndex = 1
        Me.lblID.Text = " "
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContact.Location = New System.Drawing.Point(19, 45)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(12, 16)
        Me.lblContact.TabIndex = 2
        Me.lblContact.Text = " "
        '
        'lblHousePhone
        '
        Me.lblHousePhone.AutoSize = True
        Me.lblHousePhone.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHousePhone.Location = New System.Drawing.Point(271, 50)
        Me.lblHousePhone.Name = "lblHousePhone"
        Me.lblHousePhone.Size = New System.Drawing.Size(12, 16)
        Me.lblHousePhone.TabIndex = 3
        Me.lblHousePhone.Text = " "
        '
        'lblAltPhone
        '
        Me.lblAltPhone.AutoSize = True
        Me.lblAltPhone.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAltPhone.Location = New System.Drawing.Point(271, 75)
        Me.lblAltPhone.Name = "lblAltPhone"
        Me.lblAltPhone.Size = New System.Drawing.Size(12, 16)
        Me.lblAltPhone.TabIndex = 4
        Me.lblAltPhone.Text = " "
        '
        'lblPhone1Type
        '
        Me.lblPhone1Type.AutoSize = True
        Me.lblPhone1Type.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone1Type.Location = New System.Drawing.Point(394, 53)
        Me.lblPhone1Type.Name = "lblPhone1Type"
        Me.lblPhone1Type.Size = New System.Drawing.Size(12, 16)
        Me.lblPhone1Type.TabIndex = 5
        Me.lblPhone1Type.Text = " "
        '
        'lblAltPhone2
        '
        Me.lblAltPhone2.AutoSize = True
        Me.lblAltPhone2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAltPhone2.Location = New System.Drawing.Point(271, 100)
        Me.lblAltPhone2.Name = "lblAltPhone2"
        Me.lblAltPhone2.Size = New System.Drawing.Size(12, 16)
        Me.lblAltPhone2.TabIndex = 6
        Me.lblAltPhone2.Text = " "
        '
        'lblPhone2Type
        '
        Me.lblPhone2Type.AutoSize = True
        Me.lblPhone2Type.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone2Type.Location = New System.Drawing.Point(394, 78)
        Me.lblPhone2Type.Name = "lblPhone2Type"
        Me.lblPhone2Type.Size = New System.Drawing.Size(12, 16)
        Me.lblPhone2Type.TabIndex = 7
        Me.lblPhone2Type.Text = " "
        '
        'CommonNFO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(513, 210)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CommonNFO"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Information:"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblPhone2Type As System.Windows.Forms.Label
    Friend WithEvents lblAltPhone2 As System.Windows.Forms.Label
    Friend WithEvents lblPhone1Type As System.Windows.Forms.Label
    Friend WithEvents lblAltPhone As System.Windows.Forms.Label
    Friend WithEvents lblHousePhone As System.Windows.Forms.Label
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
End Class
