﻿

Public Class listAF_and_listJP

    '' methods for separate threads
    ''
    '' populate directory() / change directory()
    ''
    '' get images() all sizes
    '' 

End Class
