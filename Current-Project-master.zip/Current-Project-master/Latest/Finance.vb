Public Class Finance

    Private Sub Finance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = Main

    End Sub
End Class