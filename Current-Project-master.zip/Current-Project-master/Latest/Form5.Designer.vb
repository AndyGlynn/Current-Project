<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"12/12/2007", "12345", "Earnest VanDielen"}, -1)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tpSummary = New System.Windows.Forms.TabPage
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lblAccuracy = New System.Windows.Forms.Label
        Me.pnlPerformanceReport = New System.Windows.Forms.Panel
        Me.Label15 = New System.Windows.Forms.Label
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label67 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.lblNoData = New System.Windows.Forms.Label
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.Label61 = New System.Windows.Forms.Label
        Me.Label60 = New System.Windows.Forms.Label
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.lvnoresults = New System.Windows.Forms.ListView
        Me.ColumnHeader6 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader8 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader7 = New System.Windows.Forms.ColumnHeader
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.pnlScheduledTasks = New System.Windows.Forms.Panel
        Me.lblResets = New System.Windows.Forms.Label
        Me.lblIssued = New System.Windows.Forms.Label
        Me.tpCustomerList = New System.Windows.Forms.TabPage
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.TabControl2 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel
        Me.lblDisplayColumn = New System.Windows.Forms.Label
        Me.lblGroupBy = New System.Windows.Forms.Label
        Me.cboGroupSales = New System.Windows.Forms.ComboBox
        Me.cboDisplayColumn = New System.Windows.Forms.ComboBox
        Me.btnExpandSalesList = New System.Windows.Forms.Button
        Me.lvSales = New System.Windows.Forms.ListView
        Me.LeadID = New System.Windows.Forms.ColumnHeader
        Me.Contact1 = New System.Windows.Forms.ColumnHeader
        Me.Address = New System.Windows.Forms.ColumnHeader
        Me.HousePhone = New System.Windows.Forms.ColumnHeader
        Me.Products = New System.Windows.Forms.ColumnHeader
        Me.ApptDateTime = New System.Windows.Forms.ColumnHeader
        Me.Reps = New System.Windows.Forms.ColumnHeader
        Me.lblConfimingPLS = New System.Windows.Forms.Label
        Me.cboSalesList = New System.Windows.Forms.ComboBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.lnkOrderbyMem = New System.Windows.Forms.LinkLabel
        Me.lvMemorized = New System.Windows.Forms.ListView
        Me.ColumnHeader9 = New System.Windows.Forms.ColumnHeader(8)
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader13 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader10 = New System.Windows.Forms.ColumnHeader
        Me.lblFilterGroups = New System.Windows.Forms.Label
        Me.btnExpandMemorize = New System.Windows.Forms.Button
        Me.lbldisplaymemorized = New System.Windows.Forms.Label
        Me.lblgroupbymemorized = New System.Windows.Forms.Label
        Me.cboGroupByMemorized = New System.Windows.Forms.ComboBox
        Me.cboDisplayMemorized = New System.Windows.Forms.ComboBox
        Me.cboFilterGroups = New System.Windows.Forms.ComboBox
        Me.tsAFPics = New System.Windows.Forms.ToolStrip
        Me.tscboAFPicsFilter = New System.Windows.Forms.ToolStripComboBox
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.tsbtnShowCH = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.tslblAFPic = New System.Windows.Forms.ToolStripLabel
        Me.tsCustomerLog = New System.Windows.Forms.ToolStrip
        Me.TScboCustomerHistory = New System.Windows.Forms.ToolStripComboBox
        Me.tslblShowDepartment = New System.Windows.Forms.ToolStripLabel
        Me.tsbtnAFPics = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripSeparator
        Me.btnLogCall = New System.Windows.Forms.ToolStripSplitButton
        Me.btnCalledandCancelled = New System.Windows.Forms.ToolStripMenuItem
        Me.tslblCustomerHistory = New System.Windows.Forms.ToolStripLabel
        Me.tpIssueLeads = New System.Windows.Forms.TabPage
        Me.tpReferences = New System.Windows.Forms.TabPage
        Me.tpReports = New System.Windows.Forms.TabPage
        Me.TabControl1.SuspendLayout()
        Me.tpSummary.SuspendLayout()
        Me.pnlPerformanceReport.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.tpCustomerList.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.tsAFPics.SuspendLayout()
        Me.tsCustomerLog.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControl1.Controls.Add(Me.tpSummary)
        Me.TabControl1.Controls.Add(Me.tpCustomerList)
        Me.TabControl1.Controls.Add(Me.tpIssueLeads)
        Me.TabControl1.Controls.Add(Me.tpReferences)
        Me.TabControl1.Controls.Add(Me.tpReports)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1187, 811)
        Me.TabControl1.TabIndex = 2
        '
        'tpSummary
        '
        Me.tpSummary.Controls.Add(Me.Label14)
        Me.tpSummary.Controls.Add(Me.Label3)
        Me.tpSummary.Controls.Add(Me.Label57)
        Me.tpSummary.Controls.Add(Me.Label7)
        Me.tpSummary.Controls.Add(Me.Label8)
        Me.tpSummary.Controls.Add(Me.Label9)
        Me.tpSummary.Controls.Add(Me.Label10)
        Me.tpSummary.Controls.Add(Me.lblAccuracy)
        Me.tpSummary.Controls.Add(Me.pnlPerformanceReport)
        Me.tpSummary.Controls.Add(Me.Label4)
        Me.tpSummary.Controls.Add(Me.Label38)
        Me.tpSummary.Controls.Add(Me.lvnoresults)
        Me.tpSummary.Controls.Add(Me.GroupBox4)
        Me.tpSummary.Controls.Add(Me.lblResets)
        Me.tpSummary.Controls.Add(Me.lblIssued)
        Me.tpSummary.ImageKey = "Summary- Selected.png"
        Me.tpSummary.Location = New System.Drawing.Point(23, 4)
        Me.tpSummary.Name = "tpSummary"
        Me.tpSummary.Padding = New System.Windows.Forms.Padding(3)
        Me.tpSummary.Size = New System.Drawing.Size(1160, 803)
        Me.tpSummary.TabIndex = 0
        Me.tpSummary.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(738, 329)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(122, 16)
        Me.Label14.TabIndex = 256
        Me.Label14.Text = "Recission Cancels"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(512, 329)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(122, 16)
        Me.Label3.TabIndex = 257
        Me.Label3.Text = "No Demos"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.BackColor = System.Drawing.Color.Transparent
        Me.Label57.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(12, 327)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(71, 16)
        Me.Label57.TabIndex = 249
        Me.Label57.Text = "Sales Rep"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(173, 329)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(122, 16)
        Me.Label7.TabIndex = 251
        Me.Label7.Text = "Demo/No Sales"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(286, 329)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(122, 16)
        Me.Label8.TabIndex = 253
        Me.Label8.Text = "Not Hits"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(625, 329)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(122, 16)
        Me.Label9.TabIndex = 254
        Me.Label9.Text = "Sales"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(851, 329)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 16)
        Me.Label10.TabIndex = 255
        Me.Label10.Text = "$Sold$"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAccuracy
        '
        Me.lblAccuracy.AutoSize = True
        Me.lblAccuracy.BackColor = System.Drawing.Color.Transparent
        Me.lblAccuracy.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccuracy.ForeColor = System.Drawing.Color.Black
        Me.lblAccuracy.Location = New System.Drawing.Point(12, 300)
        Me.lblAccuracy.Name = "lblAccuracy"
        Me.lblAccuracy.Size = New System.Drawing.Size(0, 13)
        Me.lblAccuracy.TabIndex = 229
        '
        'pnlPerformanceReport
        '
        Me.pnlPerformanceReport.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlPerformanceReport.AutoScroll = True
        Me.pnlPerformanceReport.BackColor = System.Drawing.Color.White
        Me.pnlPerformanceReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlPerformanceReport.Controls.Add(Me.Label15)
        Me.pnlPerformanceReport.Controls.Add(Me.LinkLabel1)
        Me.pnlPerformanceReport.Controls.Add(Me.Label19)
        Me.pnlPerformanceReport.Controls.Add(Me.Label20)
        Me.pnlPerformanceReport.Controls.Add(Me.Label67)
        Me.pnlPerformanceReport.Controls.Add(Me.Label66)
        Me.pnlPerformanceReport.Controls.Add(Me.lblNoData)
        Me.pnlPerformanceReport.Controls.Add(Me.Label64)
        Me.pnlPerformanceReport.Controls.Add(Me.Label63)
        Me.pnlPerformanceReport.Controls.Add(Me.Label62)
        Me.pnlPerformanceReport.Controls.Add(Me.Label61)
        Me.pnlPerformanceReport.Controls.Add(Me.Label60)
        Me.pnlPerformanceReport.Controls.Add(Me.Label59)
        Me.pnlPerformanceReport.Controls.Add(Me.Label58)
        Me.pnlPerformanceReport.Location = New System.Drawing.Point(3, 353)
        Me.pnlPerformanceReport.Name = "pnlPerformanceReport"
        Me.pnlPerformanceReport.Size = New System.Drawing.Size(1149, 447)
        Me.pnlPerformanceReport.TabIndex = 231
        '
        'Label15
        '
        Me.Label15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(396, 210)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 16)
        Me.Label15.TabIndex = 231
        Me.Label15.Text = "# - %"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(7, 12)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(95, 16)
        Me.LinkLabel1.TabIndex = 209
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Brice Starner"
        '
        'Label19
        '
        Me.Label19.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(805, 160)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 16)
        Me.Label19.TabIndex = 208
        Me.Label19.Text = "40%"
        '
        'Label20
        '
        Me.Label20.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(730, 160)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(16, 16)
        Me.Label20.TabIndex = 207
        Me.Label20.Text = "4"
        '
        'Label67
        '
        Me.Label67.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label67.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(882, 12)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(80, 235)
        Me.Label67.TabIndex = 206
        Me.Label67.Text = "$9,247,570"
        '
        'Label66
        '
        Me.Label66.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(875, 160)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(38, 16)
        Me.Label66.TabIndex = 205
        Me.Label66.Text = "40%"
        '
        'lblNoData
        '
        Me.lblNoData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNoData.AutoSize = True
        Me.lblNoData.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNoData.Location = New System.Drawing.Point(166, 83)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Size = New System.Drawing.Size(616, 25)
        Me.lblNoData.TabIndex = 204
        Me.lblNoData.Text = "There is No Data to Report for The Date Range Provided!"
        '
        'Label64
        '
        Me.Label64.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(465, 220)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(38, 16)
        Me.Label64.TabIndex = 203
        Me.Label64.Text = "35%"
        '
        'Label63
        '
        Me.Label63.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(319, 175)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(38, 16)
        Me.Label63.TabIndex = 202
        Me.Label63.Text = "59%"
        '
        'Label62
        '
        Me.Label62.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label62.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(225, 4)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(46, 235)
        Me.Label62.TabIndex = 201
        Me.Label62.Text = "100%"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label61
        '
        Me.Label61.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(403, 130)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(16, 16)
        Me.Label61.TabIndex = 200
        Me.Label61.Text = "1"
        '
        'Label60
        '
        Me.Label60.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label60.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(430, 12)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(82, 235)
        Me.Label60.TabIndex = 199
        Me.Label60.Text = "66     100%"
        '
        'Label59
        '
        Me.Label59.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(199, 160)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(24, 16)
        Me.Label59.TabIndex = 198
        Me.Label59.Text = "10"
        '
        'Label58
        '
        Me.Label58.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label58.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(188, 12)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(32, 235)
        Me.Label58.TabIndex = 197
        Me.Label58.Text = "999"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(368, 295)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(174, 19)
        Me.Label4.TabIndex = 225
        Me.Label4.Text = "Performance Report"
        '
        'Label38
        '
        Me.Label38.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(817, 6)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(226, 16)
        Me.Label38.TabIndex = 224
        Me.Label38.Text = "All Records Needing Sales Results"
        '
        'lvnoresults
        '
        Me.lvnoresults.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvnoresults.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvnoresults.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader6, Me.ColumnHeader8, Me.ColumnHeader7})
        Me.lvnoresults.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvnoresults.FullRowSelect = True
        Me.lvnoresults.HideSelection = False
        Me.lvnoresults.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1})
        Me.lvnoresults.Location = New System.Drawing.Point(820, 25)
        Me.lvnoresults.MultiSelect = False
        Me.lvnoresults.Name = "lvnoresults"
        Me.lvnoresults.Size = New System.Drawing.Size(332, 263)
        Me.lvnoresults.TabIndex = 223
        Me.lvnoresults.UseCompatibleStateImageBehavior = False
        Me.lvnoresults.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Date"
        Me.ColumnHeader6.Width = 79
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "ID"
        Me.ColumnHeader8.Width = 56
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Sales Rep 1"
        Me.ColumnHeader7.Width = 171
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.pnlScheduledTasks)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox4.Size = New System.Drawing.Size(805, 282)
        Me.GroupBox4.TabIndex = 221
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Scheduled Tasks - Sales Department"
        '
        'pnlScheduledTasks
        '
        Me.pnlScheduledTasks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlScheduledTasks.AutoScroll = True
        Me.pnlScheduledTasks.BackColor = System.Drawing.Color.White
        Me.pnlScheduledTasks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlScheduledTasks.Location = New System.Drawing.Point(8, 22)
        Me.pnlScheduledTasks.Name = "pnlScheduledTasks"
        Me.pnlScheduledTasks.Size = New System.Drawing.Size(787, 254)
        Me.pnlScheduledTasks.TabIndex = 246
        '
        'lblResets
        '
        Me.lblResets.BackColor = System.Drawing.Color.Transparent
        Me.lblResets.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResets.ForeColor = System.Drawing.Color.Black
        Me.lblResets.Location = New System.Drawing.Point(399, 329)
        Me.lblResets.Name = "lblResets"
        Me.lblResets.Size = New System.Drawing.Size(122, 16)
        Me.lblResets.TabIndex = 252
        Me.lblResets.Text = "Resets"
        Me.lblResets.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIssued
        '
        Me.lblIssued.BackColor = System.Drawing.Color.Transparent
        Me.lblIssued.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIssued.ForeColor = System.Drawing.Color.Black
        Me.lblIssued.Location = New System.Drawing.Point(74, 329)
        Me.lblIssued.Name = "lblIssued"
        Me.lblIssued.Size = New System.Drawing.Size(122, 16)
        Me.lblIssued.TabIndex = 250
        Me.lblIssued.Text = "Issued"
        Me.lblIssued.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tpCustomerList
        '
        Me.tpCustomerList.Controls.Add(Me.SplitContainer1)
        Me.tpCustomerList.ImageKey = "Customer List.png"
        Me.tpCustomerList.Location = New System.Drawing.Point(23, 4)
        Me.tpCustomerList.Name = "tpCustomerList"
        Me.tpCustomerList.Padding = New System.Windows.Forms.Padding(3)
        Me.tpCustomerList.Size = New System.Drawing.Size(1160, 803)
        Me.tpCustomerList.TabIndex = 1
        Me.tpCustomerList.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 3)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.tsAFPics)
        Me.SplitContainer1.Panel2.Controls.Add(Me.tsCustomerLog)
        Me.SplitContainer1.Size = New System.Drawing.Size(1154, 797)
        Me.SplitContainer1.SplitterDistance = 215
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 0
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.Location = New System.Drawing.Point(0, 0)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.ShowToolTips = True
        Me.TabControl2.Size = New System.Drawing.Size(215, 797)
        Me.TabControl2.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.LinkLabel2)
        Me.TabPage1.Controls.Add(Me.lblDisplayColumn)
        Me.TabPage1.Controls.Add(Me.lblGroupBy)
        Me.TabPage1.Controls.Add(Me.cboGroupSales)
        Me.TabPage1.Controls.Add(Me.cboDisplayColumn)
        Me.TabPage1.Controls.Add(Me.btnExpandSalesList)
        Me.TabPage1.Controls.Add(Me.lvSales)
        Me.TabPage1.Controls.Add(Me.lblConfimingPLS)
        Me.TabPage1.Controls.Add(Me.cboSalesList)
        Me.TabPage1.ImageIndex = 0
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(207, 771)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Sales List"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(114, 3)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(64, 13)
        Me.LinkLabel2.TabIndex = 97
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Order By ID"
        '
        'lblDisplayColumn
        '
        Me.lblDisplayColumn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDisplayColumn.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lblDisplayColumn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisplayColumn.ForeColor = System.Drawing.Color.Gray
        Me.lblDisplayColumn.Location = New System.Drawing.Point(3, 50)
        Me.lblDisplayColumn.Name = "lblDisplayColumn"
        Me.lblDisplayColumn.Size = New System.Drawing.Size(144, 21)
        Me.lblDisplayColumn.TabIndex = 96
        Me.lblDisplayColumn.Text = "Change Display Column"
        Me.lblDisplayColumn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblGroupBy
        '
        Me.lblGroupBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblGroupBy.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lblGroupBy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGroupBy.ForeColor = System.Drawing.Color.Gray
        Me.lblGroupBy.Location = New System.Drawing.Point(4, 77)
        Me.lblGroupBy.Name = "lblGroupBy"
        Me.lblGroupBy.Size = New System.Drawing.Size(144, 21)
        Me.lblGroupBy.TabIndex = 95
        Me.lblGroupBy.Text = "Group By"
        Me.lblGroupBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboGroupSales
        '
        Me.cboGroupSales.DropDownHeight = 150
        Me.cboGroupSales.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGroupSales.DropDownWidth = 200
        Me.cboGroupSales.FormattingEnabled = True
        Me.cboGroupSales.IntegralHeight = False
        Me.cboGroupSales.Items.AddRange(New Object() {"", "Primary Product", "Appt. Date", "Sales Result", "Marketing Result", "Sales Rep", "City, State", "Zip Code"})
        Me.cboGroupSales.Location = New System.Drawing.Point(4, 77)
        Me.cboGroupSales.Name = "cboGroupSales"
        Me.cboGroupSales.Size = New System.Drawing.Size(164, 21)
        Me.cboGroupSales.TabIndex = 94
        '
        'cboDisplayColumn
        '
        Me.cboDisplayColumn.DropDownHeight = 150
        Me.cboDisplayColumn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisplayColumn.DropDownWidth = 200
        Me.cboDisplayColumn.FormattingEnabled = True
        Me.cboDisplayColumn.IntegralHeight = False
        Me.cboDisplayColumn.Items.AddRange(New Object() {"", "Record ID (Default)", "Contact(s)", "House Phone", "Products", "Appt. Date/Time", "Rep(s)"})
        Me.cboDisplayColumn.Location = New System.Drawing.Point(4, 50)
        Me.cboDisplayColumn.Name = "cboDisplayColumn"
        Me.cboDisplayColumn.Size = New System.Drawing.Size(164, 21)
        Me.cboDisplayColumn.TabIndex = 93
        '
        'btnExpandSalesList
        '
        Me.btnExpandSalesList.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExpandSalesList.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExpandSalesList.Location = New System.Drawing.Point(176, 23)
        Me.btnExpandSalesList.Name = "btnExpandSalesList"
        Me.btnExpandSalesList.Size = New System.Drawing.Size(22, 75)
        Me.btnExpandSalesList.TabIndex = 92
        Me.btnExpandSalesList.UseVisualStyleBackColor = True
        '
        'lvSales
        '
        Me.lvSales.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvSales.AllowColumnReorder = True
        Me.lvSales.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvSales.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.LeadID, Me.Contact1, Me.Address, Me.HousePhone, Me.Products, Me.ApptDateTime, Me.Reps})
        Me.lvSales.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvSales.FullRowSelect = True
        Me.lvSales.HideSelection = False
        Me.lvSales.Location = New System.Drawing.Point(0, 104)
        Me.lvSales.MultiSelect = False
        Me.lvSales.Name = "lvSales"
        Me.lvSales.Size = New System.Drawing.Size(207, 667)
        Me.lvSales.TabIndex = 91
        Me.lvSales.UseCompatibleStateImageBehavior = False
        Me.lvSales.View = System.Windows.Forms.View.Details
        '
        'LeadID
        '
        Me.LeadID.Text = "ID"
        '
        'Contact1
        '
        Me.Contact1.Text = "Contact(s)"
        Me.Contact1.Width = 160
        '
        'Address
        '
        Me.Address.Text = "Address"
        Me.Address.Width = 255
        '
        'HousePhone
        '
        Me.HousePhone.Text = "House Phone"
        Me.HousePhone.Width = 101
        '
        'Products
        '
        Me.Products.Text = "Product(s)"
        Me.Products.Width = 82
        '
        'ApptDateTime
        '
        Me.ApptDateTime.Text = "Appt. Date/Time"
        Me.ApptDateTime.Width = 144
        '
        'Reps
        '
        Me.Reps.Text = "Rep(s)"
        Me.Reps.Width = 99
        '
        'lblConfimingPLS
        '
        Me.lblConfimingPLS.AutoSize = True
        Me.lblConfimingPLS.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.lblConfimingPLS.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfimingPLS.ForeColor = System.Drawing.Color.Black
        Me.lblConfimingPLS.Location = New System.Drawing.Point(12, 3)
        Me.lblConfimingPLS.Name = "lblConfimingPLS"
        Me.lblConfimingPLS.Size = New System.Drawing.Size(75, 13)
        Me.lblConfimingPLS.TabIndex = 90
        Me.lblConfimingPLS.Text = "Select a List"
        '
        'cboSalesList
        '
        Me.cboSalesList.DropDownHeight = 150
        Me.cboSalesList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSalesList.DropDownWidth = 200
        Me.cboSalesList.FormattingEnabled = True
        Me.cboSalesList.IntegralHeight = False
        Me.cboSalesList.Items.AddRange(New Object() {"Unfiltered Sales Dept. List", "Records Needing Sales Results", "Finance Dept. List", "Sales still within Recission Period", "Unconfirmed Appts. For Today", "Previous Customer List", "Recovery Dept. List", "Installation Dept. List", "Issue Leads List", "Scheduled Tasks List", "Custom..."})
        Me.cboSalesList.Location = New System.Drawing.Point(4, 23)
        Me.cboSalesList.Name = "cboSalesList"
        Me.cboSalesList.Size = New System.Drawing.Size(164, 21)
        Me.cboSalesList.TabIndex = 89
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.lnkOrderbyMem)
        Me.TabPage2.Controls.Add(Me.lvMemorized)
        Me.TabPage2.Controls.Add(Me.lblFilterGroups)
        Me.TabPage2.Controls.Add(Me.btnExpandMemorize)
        Me.TabPage2.Controls.Add(Me.lbldisplaymemorized)
        Me.TabPage2.Controls.Add(Me.lblgroupbymemorized)
        Me.TabPage2.Controls.Add(Me.cboGroupByMemorized)
        Me.TabPage2.Controls.Add(Me.cboDisplayMemorized)
        Me.TabPage2.Controls.Add(Me.cboFilterGroups)
        Me.TabPage2.ImageIndex = 4
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(207, 771)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Memorized List"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'lnkOrderbyMem
        '
        Me.lnkOrderbyMem.AutoSize = True
        Me.lnkOrderbyMem.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnkOrderbyMem.Location = New System.Drawing.Point(54, 3)
        Me.lnkOrderbyMem.Name = "lnkOrderbyMem"
        Me.lnkOrderbyMem.Size = New System.Drawing.Size(64, 13)
        Me.lnkOrderbyMem.TabIndex = 104
        Me.lnkOrderbyMem.TabStop = True
        Me.lnkOrderbyMem.Text = "Order By ID"
        '
        'lvMemorized
        '
        Me.lvMemorized.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvMemorized.AllowColumnReorder = True
        Me.lvMemorized.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvMemorized.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader9, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader13, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader10})
        Me.lvMemorized.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvMemorized.FullRowSelect = True
        Me.lvMemorized.HideSelection = False
        Me.lvMemorized.LabelEdit = True
        Me.lvMemorized.Location = New System.Drawing.Point(0, 104)
        Me.lvMemorized.MultiSelect = False
        Me.lvMemorized.Name = "lvMemorized"
        Me.lvMemorized.Size = New System.Drawing.Size(207, 667)
        Me.lvMemorized.TabIndex = 103
        Me.lvMemorized.UseCompatibleStateImageBehavior = False
        Me.lvMemorized.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = ""
        Me.ColumnHeader9.Width = 33
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Contact(s)"
        Me.ColumnHeader2.Width = 127
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Address"
        Me.ColumnHeader3.Width = 255
        '
        'ColumnHeader13
        '
        Me.ColumnHeader13.DisplayIndex = 6
        Me.ColumnHeader13.Text = "House Phone"
        Me.ColumnHeader13.Width = 101
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.DisplayIndex = 4
        Me.ColumnHeader4.Text = "Product(s)"
        Me.ColumnHeader4.Width = 82
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.DisplayIndex = 5
        Me.ColumnHeader5.Text = "Appt. Date/Time"
        Me.ColumnHeader5.Width = 144
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Rep(s)"
        Me.ColumnHeader10.Width = 99
        '
        'lblFilterGroups
        '
        Me.lblFilterGroups.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilterGroups.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lblFilterGroups.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFilterGroups.ForeColor = System.Drawing.Color.Gray
        Me.lblFilterGroups.Location = New System.Drawing.Point(4, 23)
        Me.lblFilterGroups.Name = "lblFilterGroups"
        Me.lblFilterGroups.Size = New System.Drawing.Size(144, 21)
        Me.lblFilterGroups.TabIndex = 102
        Me.lblFilterGroups.Text = "Filter Groups"
        Me.lblFilterGroups.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnExpandMemorize
        '
        Me.btnExpandMemorize.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExpandMemorize.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExpandMemorize.Location = New System.Drawing.Point(176, 23)
        Me.btnExpandMemorize.Name = "btnExpandMemorize"
        Me.btnExpandMemorize.Size = New System.Drawing.Size(22, 75)
        Me.btnExpandMemorize.TabIndex = 101
        Me.btnExpandMemorize.UseVisualStyleBackColor = True
        '
        'lbldisplaymemorized
        '
        Me.lbldisplaymemorized.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbldisplaymemorized.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lbldisplaymemorized.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldisplaymemorized.ForeColor = System.Drawing.Color.Gray
        Me.lbldisplaymemorized.Location = New System.Drawing.Point(4, 50)
        Me.lbldisplaymemorized.Name = "lbldisplaymemorized"
        Me.lbldisplaymemorized.Size = New System.Drawing.Size(144, 21)
        Me.lbldisplaymemorized.TabIndex = 100
        Me.lbldisplaymemorized.Text = "Change Display Column"
        Me.lbldisplaymemorized.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblgroupbymemorized
        '
        Me.lblgroupbymemorized.BackColor = System.Drawing.Color.Transparent
        Me.lblgroupbymemorized.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblgroupbymemorized.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lblgroupbymemorized.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgroupbymemorized.ForeColor = System.Drawing.Color.Gray
        Me.lblgroupbymemorized.Location = New System.Drawing.Point(3, 77)
        Me.lblgroupbymemorized.Name = "lblgroupbymemorized"
        Me.lblgroupbymemorized.Size = New System.Drawing.Size(144, 21)
        Me.lblgroupbymemorized.TabIndex = 99
        Me.lblgroupbymemorized.Text = "Group By"
        Me.lblgroupbymemorized.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboGroupByMemorized
        '
        Me.cboGroupByMemorized.DropDownHeight = 150
        Me.cboGroupByMemorized.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGroupByMemorized.DropDownWidth = 164
        Me.cboGroupByMemorized.FormattingEnabled = True
        Me.cboGroupByMemorized.IntegralHeight = False
        Me.cboGroupByMemorized.Items.AddRange(New Object() {"", "Primary Product", "Appt. Date", "Sales Result", "Marketing Result", "Sales Rep", "City, State", "Zip Code"})
        Me.cboGroupByMemorized.Location = New System.Drawing.Point(4, 77)
        Me.cboGroupByMemorized.Name = "cboGroupByMemorized"
        Me.cboGroupByMemorized.Size = New System.Drawing.Size(164, 21)
        Me.cboGroupByMemorized.TabIndex = 98
        '
        'cboDisplayMemorized
        '
        Me.cboDisplayMemorized.DropDownHeight = 150
        Me.cboDisplayMemorized.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisplayMemorized.DropDownWidth = 164
        Me.cboDisplayMemorized.FormattingEnabled = True
        Me.cboDisplayMemorized.IntegralHeight = False
        Me.cboDisplayMemorized.Items.AddRange(New Object() {"", "Record ID (Default)", "Contact(s)", "House Phone", "Products", "Appt. Date/Time", "Rep(s)"})
        Me.cboDisplayMemorized.Location = New System.Drawing.Point(4, 50)
        Me.cboDisplayMemorized.Name = "cboDisplayMemorized"
        Me.cboDisplayMemorized.Size = New System.Drawing.Size(164, 21)
        Me.cboDisplayMemorized.TabIndex = 97
        '
        'cboFilterGroups
        '
        Me.cboFilterGroups.DropDownHeight = 150
        Me.cboFilterGroups.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFilterGroups.DropDownWidth = 164
        Me.cboFilterGroups.FormattingEnabled = True
        Me.cboFilterGroups.IntegralHeight = False
        Me.cboFilterGroups.Items.AddRange(New Object() {"Unfiltered Sales Dept. List", "Leads Needing Sales Results", "Finance Sale Status List", "Sales still within Recission Period", "Unconfirmed Appts. For Today", "Previous Customer List", "Recovery List", "Installation Dept. List", "Issue Leads List", "Custom..."})
        Me.cboFilterGroups.Location = New System.Drawing.Point(4, 23)
        Me.cboFilterGroups.Name = "cboFilterGroups"
        Me.cboFilterGroups.Size = New System.Drawing.Size(164, 21)
        Me.cboFilterGroups.TabIndex = 90
        '
        'tsAFPics
        '
        Me.tsAFPics.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tsAFPics.AutoSize = False
        Me.tsAFPics.Dock = System.Windows.Forms.DockStyle.None
        Me.tsAFPics.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.tsAFPics.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tscboAFPicsFilter, Me.ToolStripLabel1, Me.tsbtnShowCH, Me.ToolStripSeparator2, Me.ToolStripButton1, Me.tslblAFPic})
        Me.tsAFPics.Location = New System.Drawing.Point(4, 354)
        Me.tsAFPics.Margin = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.tsAFPics.Name = "tsAFPics"
        Me.tsAFPics.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.tsAFPics.Size = New System.Drawing.Size(928, 33)
        Me.tsAFPics.TabIndex = 201
        Me.tsAFPics.Text = "ToolStrip1"
        Me.tsAFPics.Visible = False
        '
        'tscboAFPicsFilter
        '
        Me.tscboAFPicsFilter.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tscboAFPicsFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.tscboAFPicsFilter.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.tscboAFPicsFilter.Items.AddRange(New Object() {"All", "Job Pictures", "Attached Files"})
        Me.tscboAFPicsFilter.Margin = New System.Windows.Forms.Padding(1, 0, 10, 0)
        Me.tscboAFPicsFilter.Name = "tscboAFPicsFilter"
        Me.tscboAFPicsFilter.Size = New System.Drawing.Size(160, 33)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.Margin = New System.Windows.Forms.Padding(10, 1, 0, 2)
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(43, 30)
        Me.ToolStripLabel1.Text = "Show"
        '
        'tsbtnShowCH
        '
        Me.tsbtnShowCH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbtnShowCH.Image = CType(resources.GetObject("tsbtnShowCH.Image"), System.Drawing.Image)
        Me.tsbtnShowCH.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbtnShowCH.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbtnShowCH.Name = "tsbtnShowCH"
        Me.tsbtnShowCH.Size = New System.Drawing.Size(36, 30)
        Me.tsbtnShowCH.Text = "ShowAFPics"
        Me.tsbtnShowCH.ToolTipText = "Go Back to Customer History"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.AutoSize = False
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Enabled = False
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(36, 30)
        Me.ToolStripButton1.Text = "Up One Level"
        '
        'tslblAFPic
        '
        Me.tslblAFPic.Font = New System.Drawing.Font("Tahoma", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tslblAFPic.Margin = New System.Windows.Forms.Padding(5, 1, 0, 2)
        Me.tslblAFPic.Name = "tslblAFPic"
        Me.tslblAFPic.Size = New System.Drawing.Size(279, 30)
        Me.tslblAFPic.Text = "Attached Files and Job Pictures..."
        '
        'tsCustomerLog
        '
        Me.tsCustomerLog.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tsCustomerLog.AutoSize = False
        Me.tsCustomerLog.Dock = System.Windows.Forms.DockStyle.None
        Me.tsCustomerLog.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.tsCustomerLog.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TScboCustomerHistory, Me.tslblShowDepartment, Me.tsbtnAFPics, Me.ToolStripButton3, Me.btnLogCall, Me.tslblCustomerHistory})
        Me.tsCustomerLog.Location = New System.Drawing.Point(4, 354)
        Me.tsCustomerLog.Margin = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.tsCustomerLog.Name = "tsCustomerLog"
        Me.tsCustomerLog.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.tsCustomerLog.Size = New System.Drawing.Size(928, 33)
        Me.tsCustomerLog.TabIndex = 189
        Me.tsCustomerLog.Text = "ToolStrip1"
        Me.tsCustomerLog.Visible = False
        '
        'TScboCustomerHistory
        '
        Me.TScboCustomerHistory.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TScboCustomerHistory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TScboCustomerHistory.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.TScboCustomerHistory.Items.AddRange(New Object() {"All", "Marketing Department", "Sales Department", "Finance Department", "Installation Department", "Recovery Department", "Administration", "Phone Correspondence"})
        Me.TScboCustomerHistory.Margin = New System.Windows.Forms.Padding(1, 0, 10, 0)
        Me.TScboCustomerHistory.Name = "TScboCustomerHistory"
        Me.TScboCustomerHistory.Size = New System.Drawing.Size(160, 33)
        '
        'tslblShowDepartment
        '
        Me.tslblShowDepartment.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tslblShowDepartment.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tslblShowDepartment.Margin = New System.Windows.Forms.Padding(10, 1, 0, 2)
        Me.tslblShowDepartment.Name = "tslblShowDepartment"
        Me.tslblShowDepartment.Size = New System.Drawing.Size(43, 30)
        Me.tslblShowDepartment.Text = "Show"
        '
        'tsbtnAFPics
        '
        Me.tsbtnAFPics.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbtnAFPics.Image = CType(resources.GetObject("tsbtnAFPics.Image"), System.Drawing.Image)
        Me.tsbtnAFPics.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbtnAFPics.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbtnAFPics.Name = "tsbtnAFPics"
        Me.tsbtnAFPics.Size = New System.Drawing.Size(36, 30)
        Me.tsbtnAFPics.Text = "ShowAFPics"
        Me.tsbtnAFPics.ToolTipText = "Show Attached Files and Job Pictures for this Customer"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(6, 33)
        '
        'btnLogCall
        '
        Me.btnLogCall.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnCalledandCancelled})
        Me.btnLogCall.Image = CType(resources.GetObject("btnLogCall.Image"), System.Drawing.Image)
        Me.btnLogCall.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnLogCall.Name = "btnLogCall"
        Me.btnLogCall.Size = New System.Drawing.Size(272, 30)
        Me.btnLogCall.Text = "Log Phone Conversation with this Customer"
        '
        'btnCalledandCancelled
        '
        Me.btnCalledandCancelled.Image = Global.Latest.My.Resources.Resources.calledcancelled
        Me.btnCalledandCancelled.Name = "btnCalledandCancelled"
        Me.btnCalledandCancelled.Size = New System.Drawing.Size(254, 22)
        Me.btnCalledandCancelled.Text = "Log Appt. as Called and Cancelled"
        '
        'tslblCustomerHistory
        '
        Me.tslblCustomerHistory.Font = New System.Drawing.Font("Tahoma", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tslblCustomerHistory.Margin = New System.Windows.Forms.Padding(40, 1, 0, 2)
        Me.tslblCustomerHistory.Name = "tslblCustomerHistory"
        Me.tslblCustomerHistory.Size = New System.Drawing.Size(150, 30)
        Me.tslblCustomerHistory.Text = "Customer History"
        '
        'tpIssueLeads
        '
        Me.tpIssueLeads.ImageKey = "Issue Leads.png"
        Me.tpIssueLeads.Location = New System.Drawing.Point(23, 4)
        Me.tpIssueLeads.Name = "tpIssueLeads"
        Me.tpIssueLeads.Padding = New System.Windows.Forms.Padding(3)
        Me.tpIssueLeads.Size = New System.Drawing.Size(1160, 803)
        Me.tpIssueLeads.TabIndex = 2
        Me.tpIssueLeads.UseVisualStyleBackColor = True
        '
        'tpReferences
        '
        Me.tpReferences.ImageKey = "References.png"
        Me.tpReferences.Location = New System.Drawing.Point(23, 4)
        Me.tpReferences.Name = "tpReferences"
        Me.tpReferences.Padding = New System.Windows.Forms.Padding(3)
        Me.tpReferences.Size = New System.Drawing.Size(1160, 803)
        Me.tpReferences.TabIndex = 3
        Me.tpReferences.UseVisualStyleBackColor = True
        '
        'tpReports
        '
        Me.tpReports.ImageKey = "Reports.png"
        Me.tpReports.Location = New System.Drawing.Point(23, 4)
        Me.tpReports.Name = "tpReports"
        Me.tpReports.Padding = New System.Windows.Forms.Padding(3)
        Me.tpReports.Size = New System.Drawing.Size(1160, 803)
        Me.tpReports.TabIndex = 4
        Me.tpReports.UseVisualStyleBackColor = True
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1187, 811)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.TabControl1.ResumeLayout(False)
        Me.tpSummary.ResumeLayout(False)
        Me.tpSummary.PerformLayout()
        Me.pnlPerformanceReport.ResumeLayout(False)
        Me.pnlPerformanceReport.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.tpCustomerList.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.tsAFPics.ResumeLayout(False)
        Me.tsAFPics.PerformLayout()
        Me.tsCustomerLog.ResumeLayout(False)
        Me.tsCustomerLog.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tpSummary As System.Windows.Forms.TabPage
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblAccuracy As System.Windows.Forms.Label
    Friend WithEvents pnlPerformanceReport As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents lvnoresults As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents pnlScheduledTasks As System.Windows.Forms.Panel
    Friend WithEvents lblResets As System.Windows.Forms.Label
    Friend WithEvents lblIssued As System.Windows.Forms.Label
    Friend WithEvents tpCustomerList As System.Windows.Forms.TabPage
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents lblDisplayColumn As System.Windows.Forms.Label
    Friend WithEvents lblGroupBy As System.Windows.Forms.Label
    Friend WithEvents cboGroupSales As System.Windows.Forms.ComboBox
    Friend WithEvents cboDisplayColumn As System.Windows.Forms.ComboBox
    Friend WithEvents btnExpandSalesList As System.Windows.Forms.Button
    Friend WithEvents lvSales As System.Windows.Forms.ListView
    Friend WithEvents LeadID As System.Windows.Forms.ColumnHeader
    Friend WithEvents Contact1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Address As System.Windows.Forms.ColumnHeader
    Friend WithEvents HousePhone As System.Windows.Forms.ColumnHeader
    Friend WithEvents Products As System.Windows.Forms.ColumnHeader
    Friend WithEvents ApptDateTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents Reps As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblConfimingPLS As System.Windows.Forms.Label
    Friend WithEvents cboSalesList As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents lnkOrderbyMem As System.Windows.Forms.LinkLabel
    Friend WithEvents lvMemorized As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblFilterGroups As System.Windows.Forms.Label
    Friend WithEvents btnExpandMemorize As System.Windows.Forms.Button
    Friend WithEvents lbldisplaymemorized As System.Windows.Forms.Label
    Friend WithEvents lblgroupbymemorized As System.Windows.Forms.Label
    Friend WithEvents cboGroupByMemorized As System.Windows.Forms.ComboBox
    Friend WithEvents cboDisplayMemorized As System.Windows.Forms.ComboBox
    Friend WithEvents cboFilterGroups As System.Windows.Forms.ComboBox
    Friend WithEvents tsCustomerLog As System.Windows.Forms.ToolStrip
    Friend WithEvents TScboCustomerHistory As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents tslblShowDepartment As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tsbtnAFPics As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnLogCall As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents btnCalledandCancelled As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tslblCustomerHistory As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tpIssueLeads As System.Windows.Forms.TabPage
    Friend WithEvents tpReferences As System.Windows.Forms.TabPage
    Friend WithEvents tpReports As System.Windows.Forms.TabPage
    Friend WithEvents tsAFPics As System.Windows.Forms.ToolStrip
    Private WithEvents tscboAFPicsFilter As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tsbtnShowCH As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents tslblAFPic As System.Windows.Forms.ToolStripLabel
End Class
