﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMappointEX
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMappointEX))
        Me.btnXReference = New System.Windows.Forms.Button()
        Me.btnGenerateRadius = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbSalesAndMarketing = New System.Windows.Forms.TabPage()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.nmRadiusPlot = New System.Windows.Forms.NumericUpDown()
        Me.chkSecondaryDataSet = New System.Windows.Forms.CheckedListBox()
        Me.chkListPrimaryDataSet = New System.Windows.Forms.CheckedListBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.lsRadiusFound = New System.Windows.Forms.ListView()
        Me.colIDSandMRadius = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ctxViewIn = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarketingManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstallationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfirmingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WarmCallingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SeparateMapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.nmPvsSRecords = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dtpPvsSEnd = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dtpPvsSBegin = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpEndDM = New System.Windows.Forms.DateTimePicker()
        Me.dtpBeginDM = New System.Windows.Forms.DateTimePicker()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.bgPlotPriDSETS = New System.ComponentModel.BackgroundWorker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboTargetCity = New System.Windows.Forms.ComboBox()
        Me.chkFocusTargetCity = New System.Windows.Forms.CheckBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.grpDataOptions = New System.Windows.Forms.GroupBox()
        Me.chkNotHit = New System.Windows.Forms.CheckBox()
        Me.chkCandC = New System.Windows.Forms.CheckBox()
        Me.chkConfirmed = New System.Windows.Forms.CheckBox()
        Me.chkKill = New System.Windows.Forms.CheckBox()
        Me.chkReset = New System.Windows.Forms.CheckBox()
        Me.chkNotIssued = New System.Windows.Forms.CheckBox()
        Me.chkUnconfirmed = New System.Windows.Forms.CheckBox()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnGenDataMap = New System.Windows.Forms.Button()
        Me.tbReferences = New System.Windows.Forms.TabPage()
        Me.bgGetDataSet = New System.ComponentModel.BackgroundWorker()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.bgPlotDataSet = New System.ComponentModel.BackgroundWorker()
        Me.ttCTXMenu = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.bgDM = New System.ComponentModel.BackgroundWorker()
        Me.bgDMSalesResults = New System.ComponentModel.BackgroundWorker()
        Me.tbDriveTimesDistances = New System.Windows.Forms.TabPage()
        Me.bgPlotSecDSETS = New System.ComponentModel.BackgroundWorker()
        Me.cboCityStateFlag = New System.Windows.Forms.ComboBox()
        Me.rdoColumn = New System.Windows.Forms.RadioButton()
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.grpINFO = New System.Windows.Forms.GroupBox()
        Me.lblGeneratedOn = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblInterest = New System.Windows.Forms.Label()
        Me.lblPhones = New System.Windows.Forms.Label()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rdoPie = New System.Windows.Forms.RadioButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tslblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tspbOperationProgress = New System.Windows.Forms.ToolStripProgressBar()
        Me.axTarget = New AxMapPoint.AxMappointControl()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.zoomIn = New System.Windows.Forms.Button()
        Me.zoomOut = New System.Windows.Forms.Button()
        Me.pnDown = New System.Windows.Forms.Button()
        Me.pnUP = New System.Windows.Forms.Button()
        Me.pnRight = New System.Windows.Forms.Button()
        Me.pnLeft = New System.Windows.Forms.Button()
        Me.tbMain = New System.Windows.Forms.TabControl()
        Me.tbSingle = New System.Windows.Forms.TabPage()
        Me.lsFound = New System.Windows.Forms.ListView()
        Me.lblPlotCount = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.nmNumRecords = New System.Windows.Forms.NumericUpDown()
        Me.lblNumRecordsToPlot = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpEndSPR = New System.Windows.Forms.DateTimePicker()
        Me.dtpBeginSPR = New System.Windows.Forms.DateTimePicker()
        Me.cboMarketingSPR = New System.Windows.Forms.ComboBox()
        Me.lblMarketing = New System.Windows.Forms.Label()
        Me.cboSalesSPR = New System.Windows.Forms.ComboBox()
        Me.lblSales = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdoPCs = New System.Windows.Forms.RadioButton()
        Me.rdoMarketing = New System.Windows.Forms.RadioButton()
        Me.rdoSales = New System.Windows.Forms.RadioButton()
        Me.tbDataMaps = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rdoMarketingDM = New System.Windows.Forms.RadioButton()
        Me.rdoSalesDM = New System.Windows.Forms.RadioButton()
        Me.grpDataOptionsSales = New System.Windows.Forms.GroupBox()
        Me.chkNotHitSales = New System.Windows.Forms.CheckBox()
        Me.chkNoDemoSales = New System.Windows.Forms.CheckBox()
        Me.chkDemoNoSale = New System.Windows.Forms.CheckBox()
        Me.chkBankRejectedSales = New System.Windows.Forms.CheckBox()
        Me.chkLostResultSale = New System.Windows.Forms.CheckBox()
        Me.chkSalesSale = New System.Windows.Forms.CheckBox()
        Me.chkRecissionCancel = New System.Windows.Forms.CheckBox()
        Me.chkResetSales = New System.Windows.Forms.CheckBox()
        Me.chkSalesNotIssued = New System.Windows.Forms.CheckBox()
        Me.tbSalesAndMarketing.SuspendLayout()
        CType(Me.nmRadiusPlot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.ctxViewIn.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.nmPvsSRecords, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDataOptions.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.grpINFO.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.axTarget, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.tbMain.SuspendLayout()
        Me.tbSingle.SuspendLayout()
        CType(Me.nmNumRecords, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.tbDataMaps.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.grpDataOptionsSales.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnXReference
        '
        Me.btnXReference.Enabled = False
        Me.btnXReference.Location = New System.Drawing.Point(166, 200)
        Me.btnXReference.Name = "btnXReference"
        Me.btnXReference.Size = New System.Drawing.Size(147, 23)
        Me.btnXReference.TabIndex = 31
        Me.btnXReference.Text = "Find Within Radius"
        Me.btnXReference.UseVisualStyleBackColor = True
        '
        'btnGenerateRadius
        '
        Me.btnGenerateRadius.Location = New System.Drawing.Point(8, 200)
        Me.btnGenerateRadius.Name = "btnGenerateRadius"
        Me.btnGenerateRadius.Size = New System.Drawing.Size(151, 23)
        Me.btnGenerateRadius.TabIndex = 30
        Me.btnGenerateRadius.Text = "Plot Primary Choices"
        Me.btnGenerateRadius.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(237, 234)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(13, 13)
        Me.Label19.TabIndex = 29
        Me.Label19.Text = "?"
        Me.ttCTXMenu.SetToolTip(Me.Label19, "This is the actual size of the diameter of the circle on the map." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "To get the rad" & _
        "ius of your search divide this value by two." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Example: 10 Miles (value) = 5 Mile" & _
        " Radius (on map)")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 11)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(143, 13)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Search Around These Types"
        '
        'tbSalesAndMarketing
        '
        Me.tbSalesAndMarketing.Controls.Add(Me.btnXReference)
        Me.tbSalesAndMarketing.Controls.Add(Me.btnGenerateRadius)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label19)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label12)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label9)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label17)
        Me.tbSalesAndMarketing.Controls.Add(Me.nmRadiusPlot)
        Me.tbSalesAndMarketing.Controls.Add(Me.chkSecondaryDataSet)
        Me.tbSalesAndMarketing.Controls.Add(Me.chkListPrimaryDataSet)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label18)
        Me.tbSalesAndMarketing.Controls.Add(Me.GroupBox7)
        Me.tbSalesAndMarketing.Controls.Add(Me.GroupBox5)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label16)
        Me.tbSalesAndMarketing.Controls.Add(Me.nmPvsSRecords)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label15)
        Me.tbSalesAndMarketing.Controls.Add(Me.dtpPvsSEnd)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label14)
        Me.tbSalesAndMarketing.Controls.Add(Me.dtpPvsSBegin)
        Me.tbSalesAndMarketing.Controls.Add(Me.Label13)
        Me.tbSalesAndMarketing.Location = New System.Drawing.Point(23, 4)
        Me.tbSalesAndMarketing.Name = "tbSalesAndMarketing"
        Me.tbSalesAndMarketing.Size = New System.Drawing.Size(321, 677)
        Me.tbSalesAndMarketing.TabIndex = 2
        Me.tbSalesAndMarketing.Text = "Radius Plotting"
        Me.tbSalesAndMarketing.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(182, 11)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "For These Types"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(12, 234)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(153, 13)
        Me.Label17.TabIndex = 27
        Me.Label17.Text = "Default Radius To Plot (Miles) :"
        '
        'nmRadiusPlot
        '
        Me.nmRadiusPlot.Location = New System.Drawing.Point(256, 231)
        Me.nmRadiusPlot.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nmRadiusPlot.Name = "nmRadiusPlot"
        Me.nmRadiusPlot.Size = New System.Drawing.Size(57, 20)
        Me.nmRadiusPlot.TabIndex = 28
        Me.nmRadiusPlot.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'chkSecondaryDataSet
        '
        Me.chkSecondaryDataSet.Enabled = False
        Me.chkSecondaryDataSet.FormattingEnabled = True
        Me.chkSecondaryDataSet.Items.AddRange(New Object() {"Not Issued - (Sales)", "Reset - (Sales)", "Recission Cancel", "Sale", "Bank Rejected", "Demo/No Sale", "Lost Result", "No Demo", "Not Hit - (Sales)", "Not Issued - (Marketing)", "Reset (Marketing)", "Kill", "Confirmed", "Called and Cancelled", "Not Hit - (Marketing)", "Unconfirmed - (Marketing)"})
        Me.chkSecondaryDataSet.Location = New System.Drawing.Point(164, 31)
        Me.chkSecondaryDataSet.Name = "chkSecondaryDataSet"
        Me.chkSecondaryDataSet.Size = New System.Drawing.Size(150, 109)
        Me.chkSecondaryDataSet.TabIndex = 24
        '
        'chkListPrimaryDataSet
        '
        Me.chkListPrimaryDataSet.FormattingEnabled = True
        Me.chkListPrimaryDataSet.Items.AddRange(New Object() {"Not Issued - (Sales)", "Reset - (Sales)", "Recission Cancel", "Sale", "Bank Rejected", "Demo/No Sale", "Lost Result", "No Demo", "Not Hit - (Sales)", "Not Issued - (Marketing)", "Reset (Marketing)", "Kill", "Confirmed", "Called and Cancelled", "Not Hit - (Marketing)", "Unconfirmed - (Marketing)"})
        Me.chkListPrimaryDataSet.Location = New System.Drawing.Point(9, 31)
        Me.chkListPrimaryDataSet.Name = "chkListPrimaryDataSet"
        Me.chkListPrimaryDataSet.Size = New System.Drawing.Size(150, 109)
        Me.chkListPrimaryDataSet.TabIndex = 23
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(130, 178)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(13, 13)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "?"
        Me.ttCTXMenu.SetToolTip(Me.Label18, "The more records you plot," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the slower the performance." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.lsRadiusFound)
        Me.GroupBox7.Location = New System.Drawing.Point(9, 419)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(306, 254)
        Me.GroupBox7.TabIndex = 21
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Results Found:"
        '
        'lsRadiusFound
        '
        Me.lsRadiusFound.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colIDSandMRadius})
        Me.lsRadiusFound.ContextMenuStrip = Me.ctxViewIn
        Me.lsRadiusFound.Location = New System.Drawing.Point(6, 19)
        Me.lsRadiusFound.Name = "lsRadiusFound"
        Me.lsRadiusFound.Size = New System.Drawing.Size(75, 229)
        Me.lsRadiusFound.TabIndex = 0
        Me.lsRadiusFound.UseCompatibleStateImageBehavior = False
        Me.lsRadiusFound.View = System.Windows.Forms.View.Details
        '
        'colIDSandMRadius
        '
        Me.colIDSandMRadius.Text = "ID"
        Me.colIDSandMRadius.Width = 57
        '
        'ctxViewIn
        '
        Me.ctxViewIn.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalesToolStripMenuItem, Me.MarketingManagerToolStripMenuItem, Me.FinanceToolStripMenuItem, Me.InstallationToolStripMenuItem, Me.ConfirmingToolStripMenuItem, Me.WarmCallingToolStripMenuItem, Me.ToolStripSeparator1, Me.SeparateMapToolStripMenuItem})
        Me.ctxViewIn.Name = "ctxViewIn"
        Me.ctxViewIn.Size = New System.Drawing.Size(179, 164)
        '
        'SalesToolStripMenuItem
        '
        Me.SalesToolStripMenuItem.Name = "SalesToolStripMenuItem"
        Me.SalesToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.SalesToolStripMenuItem.Text = "Sales"
        '
        'MarketingManagerToolStripMenuItem
        '
        Me.MarketingManagerToolStripMenuItem.Name = "MarketingManagerToolStripMenuItem"
        Me.MarketingManagerToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.MarketingManagerToolStripMenuItem.Text = "Marketing Manager"
        '
        'FinanceToolStripMenuItem
        '
        Me.FinanceToolStripMenuItem.Name = "FinanceToolStripMenuItem"
        Me.FinanceToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.FinanceToolStripMenuItem.Text = "Finance"
        '
        'InstallationToolStripMenuItem
        '
        Me.InstallationToolStripMenuItem.Name = "InstallationToolStripMenuItem"
        Me.InstallationToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.InstallationToolStripMenuItem.Text = "Installation"
        '
        'ConfirmingToolStripMenuItem
        '
        Me.ConfirmingToolStripMenuItem.Name = "ConfirmingToolStripMenuItem"
        Me.ConfirmingToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.ConfirmingToolStripMenuItem.Text = "Confirming"
        '
        'WarmCallingToolStripMenuItem
        '
        Me.WarmCallingToolStripMenuItem.Name = "WarmCallingToolStripMenuItem"
        Me.WarmCallingToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.WarmCallingToolStripMenuItem.Text = "Warm Calling"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(175, 6)
        '
        'SeparateMapToolStripMenuItem
        '
        Me.SeparateMapToolStripMenuItem.Name = "SeparateMapToolStripMenuItem"
        Me.SeparateMapToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.SeparateMapToolStripMenuItem.Text = "Separate Map"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button18)
        Me.GroupBox5.Controls.Add(Me.Button19)
        Me.GroupBox5.Controls.Add(Me.Button20)
        Me.GroupBox5.Controls.Add(Me.Button21)
        Me.GroupBox5.Controls.Add(Me.Button22)
        Me.GroupBox5.Controls.Add(Me.Button23)
        Me.GroupBox5.Controls.Add(Me.Button24)
        Me.GroupBox5.Controls.Add(Me.Button25)
        Me.GroupBox5.Controls.Add(Me.Button26)
        Me.GroupBox5.Controls.Add(Me.Button27)
        Me.GroupBox5.Controls.Add(Me.Button28)
        Me.GroupBox5.Location = New System.Drawing.Point(9, 270)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(305, 143)
        Me.GroupBox5.TabIndex = 19
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Map Controls:"
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(134, 64)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(30, 23)
        Me.Button18.TabIndex = 10
        Me.Button18.Text = "X"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(185, 93)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(36, 23)
        Me.Button19.TabIndex = 9
        Me.Button19.Text = "SE"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(66, 93)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(36, 23)
        Me.Button20.TabIndex = 8
        Me.Button20.Text = "SW"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(185, 35)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(36, 23)
        Me.Button21.TabIndex = 7
        Me.Button21.Text = "NE"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(66, 35)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(36, 23)
        Me.Button22.TabIndex = 6
        Me.Button22.Text = "NW"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(170, 64)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(22, 23)
        Me.Button23.TabIndex = 5
        Me.Button23.Text = "+"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(101, 64)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(26, 23)
        Me.Button24.TabIndex = 4
        Me.Button24.Text = "-"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(111, 107)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(68, 23)
        Me.Button25.TabIndex = 3
        Me.Button25.Text = "S"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(111, 19)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(68, 23)
        Me.Button26.TabIndex = 2
        Me.Button26.Text = "N"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(202, 64)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(64, 23)
        Me.Button27.TabIndex = 1
        Me.Button27.Text = "E"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(27, 64)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(57, 23)
        Me.Button28.TabIndex = 0
        Me.Button28.Text = "W"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(182, 178)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(131, 13)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "Possible Results Returned"
        '
        'nmPvsSRecords
        '
        Me.nmPvsSRecords.Location = New System.Drawing.Point(70, 176)
        Me.nmPvsSRecords.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nmPvsSRecords.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nmPvsSRecords.Name = "nmPvsSRecords"
        Me.nmPvsSRecords.Size = New System.Drawing.Size(53, 20)
        Me.nmPvsSRecords.TabIndex = 9
        Me.nmPvsSRecords.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(7, 178)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Showing "
        '
        'dtpPvsSEnd
        '
        Me.dtpPvsSEnd.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPvsSEnd.Location = New System.Drawing.Point(228, 146)
        Me.dtpPvsSEnd.Name = "dtpPvsSEnd"
        Me.dtpPvsSEnd.Size = New System.Drawing.Size(86, 20)
        Me.dtpPvsSEnd.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(196, 149)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(26, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "And"
        '
        'dtpPvsSBegin
        '
        Me.dtpPvsSBegin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPvsSBegin.Location = New System.Drawing.Point(104, 146)
        Me.dtpPvsSBegin.Name = "dtpPvsSBegin"
        Me.dtpPvsSBegin.Size = New System.Drawing.Size(86, 20)
        Me.dtpPvsSBegin.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(9, 149)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(81, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Between dates:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(168, 35)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "End Date:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(167, 10)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Begin Date:"
        '
        'dtpEndDM
        '
        Me.dtpEndDM.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpEndDM.Location = New System.Drawing.Point(236, 33)
        Me.dtpEndDM.Name = "dtpEndDM"
        Me.dtpEndDM.Size = New System.Drawing.Size(78, 20)
        Me.dtpEndDM.TabIndex = 15
        '
        'dtpBeginDM
        '
        Me.dtpBeginDM.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpBeginDM.Location = New System.Drawing.Point(236, 8)
        Me.dtpBeginDM.Name = "dtpBeginDM"
        Me.dtpBeginDM.Size = New System.Drawing.Size(78, 20)
        Me.dtpBeginDM.TabIndex = 14
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(134, 64)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(30, 23)
        Me.Button7.TabIndex = 10
        Me.Button7.Text = "X"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(185, 93)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(36, 23)
        Me.Button8.TabIndex = 9
        Me.Button8.Text = "SE"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(66, 93)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(36, 23)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "SW"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(185, 35)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(36, 23)
        Me.Button10.TabIndex = 7
        Me.Button10.Text = "NE"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 346)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(108, 13)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Map By City Or State:"
        '
        'cboTargetCity
        '
        Me.cboTargetCity.FormattingEnabled = True
        Me.cboTargetCity.Location = New System.Drawing.Point(136, 370)
        Me.cboTargetCity.Name = "cboTargetCity"
        Me.cboTargetCity.Size = New System.Drawing.Size(172, 21)
        Me.cboTargetCity.TabIndex = 25
        '
        'chkFocusTargetCity
        '
        Me.chkFocusTargetCity.AutoSize = True
        Me.chkFocusTargetCity.Location = New System.Drawing.Point(12, 372)
        Me.chkFocusTargetCity.Name = "chkFocusTargetCity"
        Me.chkFocusTargetCity.Size = New System.Drawing.Size(115, 17)
        Me.chkFocusTargetCity.TabIndex = 24
        Me.chkFocusTargetCity.Text = "Focus Target City?"
        Me.chkFocusTargetCity.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(66, 35)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(36, 23)
        Me.Button11.TabIndex = 6
        Me.Button11.Text = "NW"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(170, 64)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(22, 23)
        Me.Button12.TabIndex = 5
        Me.Button12.Text = "+"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(101, 64)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(26, 23)
        Me.Button13.TabIndex = 4
        Me.Button13.Text = "-"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(111, 107)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(68, 23)
        Me.Button14.TabIndex = 3
        Me.Button14.Text = "S"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(111, 19)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(68, 23)
        Me.Button15.TabIndex = 2
        Me.Button15.Text = "N"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(202, 64)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(64, 23)
        Me.Button16.TabIndex = 1
        Me.Button16.Text = "E"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'grpDataOptions
        '
        Me.grpDataOptions.Controls.Add(Me.chkNotHit)
        Me.grpDataOptions.Controls.Add(Me.chkCandC)
        Me.grpDataOptions.Controls.Add(Me.chkConfirmed)
        Me.grpDataOptions.Controls.Add(Me.chkKill)
        Me.grpDataOptions.Controls.Add(Me.chkReset)
        Me.grpDataOptions.Controls.Add(Me.chkNotIssued)
        Me.grpDataOptions.Controls.Add(Me.chkUnconfirmed)
        Me.grpDataOptions.Location = New System.Drawing.Point(6, 53)
        Me.grpDataOptions.Name = "grpDataOptions"
        Me.grpDataOptions.Size = New System.Drawing.Size(305, 112)
        Me.grpDataOptions.TabIndex = 21
        Me.grpDataOptions.TabStop = False
        Me.grpDataOptions.Text = "Data To Plot: Marketing Results"
        '
        'chkNotHit
        '
        Me.chkNotHit.AutoSize = True
        Me.chkNotHit.Location = New System.Drawing.Point(99, 43)
        Me.chkNotHit.Name = "chkNotHit"
        Me.chkNotHit.Size = New System.Drawing.Size(59, 17)
        Me.chkNotHit.TabIndex = 6
        Me.chkNotHit.Text = "Not Hit"
        Me.chkNotHit.UseVisualStyleBackColor = True
        '
        'chkCandC
        '
        Me.chkCandC.AutoSize = True
        Me.chkCandC.Location = New System.Drawing.Point(99, 20)
        Me.chkCandC.Name = "chkCandC"
        Me.chkCandC.Size = New System.Drawing.Size(127, 17)
        Me.chkCandC.TabIndex = 5
        Me.chkCandC.Text = "Called And Cancelled"
        Me.chkCandC.UseVisualStyleBackColor = True
        '
        'chkConfirmed
        '
        Me.chkConfirmed.AutoSize = True
        Me.chkConfirmed.Location = New System.Drawing.Point(99, 66)
        Me.chkConfirmed.Name = "chkConfirmed"
        Me.chkConfirmed.Size = New System.Drawing.Size(73, 17)
        Me.chkConfirmed.TabIndex = 4
        Me.chkConfirmed.Text = "Confirmed"
        Me.chkConfirmed.UseVisualStyleBackColor = True
        '
        'chkKill
        '
        Me.chkKill.AutoSize = True
        Me.chkKill.Location = New System.Drawing.Point(6, 89)
        Me.chkKill.Name = "chkKill"
        Me.chkKill.Size = New System.Drawing.Size(39, 17)
        Me.chkKill.TabIndex = 3
        Me.chkKill.Text = "Kill"
        Me.chkKill.UseVisualStyleBackColor = True
        '
        'chkReset
        '
        Me.chkReset.AutoSize = True
        Me.chkReset.Location = New System.Drawing.Point(7, 66)
        Me.chkReset.Name = "chkReset"
        Me.chkReset.Size = New System.Drawing.Size(54, 17)
        Me.chkReset.TabIndex = 2
        Me.chkReset.Text = "Reset"
        Me.chkReset.UseVisualStyleBackColor = True
        '
        'chkNotIssued
        '
        Me.chkNotIssued.AutoSize = True
        Me.chkNotIssued.Location = New System.Drawing.Point(7, 43)
        Me.chkNotIssued.Name = "chkNotIssued"
        Me.chkNotIssued.Size = New System.Drawing.Size(77, 17)
        Me.chkNotIssued.TabIndex = 1
        Me.chkNotIssued.Text = "Not Issued"
        Me.chkNotIssued.UseVisualStyleBackColor = True
        '
        'chkUnconfirmed
        '
        Me.chkUnconfirmed.AutoSize = True
        Me.chkUnconfirmed.Location = New System.Drawing.Point(7, 20)
        Me.chkUnconfirmed.Name = "chkUnconfirmed"
        Me.chkUnconfirmed.Size = New System.Drawing.Size(86, 17)
        Me.chkUnconfirmed.TabIndex = 0
        Me.chkUnconfirmed.Text = "Unconfirmed"
        Me.chkUnconfirmed.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(27, 64)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(57, 23)
        Me.Button17.TabIndex = 0
        Me.Button17.Text = "W"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button7)
        Me.GroupBox3.Controls.Add(Me.Button8)
        Me.GroupBox3.Controls.Add(Me.Button9)
        Me.GroupBox3.Controls.Add(Me.Button10)
        Me.GroupBox3.Controls.Add(Me.Button11)
        Me.GroupBox3.Controls.Add(Me.Button12)
        Me.GroupBox3.Controls.Add(Me.Button13)
        Me.GroupBox3.Controls.Add(Me.Button14)
        Me.GroupBox3.Controls.Add(Me.Button15)
        Me.GroupBox3.Controls.Add(Me.Button16)
        Me.GroupBox3.Controls.Add(Me.Button17)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 424)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(305, 142)
        Me.GroupBox3.TabIndex = 18
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Map Controls:"
        '
        'btnGenDataMap
        '
        Me.btnGenDataMap.Location = New System.Drawing.Point(6, 395)
        Me.btnGenDataMap.Name = "btnGenDataMap"
        Me.btnGenDataMap.Size = New System.Drawing.Size(302, 23)
        Me.btnGenDataMap.TabIndex = 20
        Me.btnGenDataMap.Text = "Generate Data Map"
        Me.btnGenDataMap.UseVisualStyleBackColor = True
        '
        'tbReferences
        '
        Me.tbReferences.Location = New System.Drawing.Point(23, 4)
        Me.tbReferences.Name = "tbReferences"
        Me.tbReferences.Size = New System.Drawing.Size(321, 677)
        Me.tbReferences.TabIndex = 4
        Me.tbReferences.Text = "References"
        Me.tbReferences.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(0, 683)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(348, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Clear Map"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(108, 440)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(13, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "?"
        Me.ttCTXMenu.SetToolTip(Me.Label5, "Right Click an item in the list to view more commands.")
        '
        'tbDriveTimesDistances
        '
        Me.tbDriveTimesDistances.Location = New System.Drawing.Point(23, 4)
        Me.tbDriveTimesDistances.Name = "tbDriveTimesDistances"
        Me.tbDriveTimesDistances.Size = New System.Drawing.Size(321, 677)
        Me.tbDriveTimesDistances.TabIndex = 5
        Me.tbDriveTimesDistances.Text = "Drive Times And Distances"
        Me.tbDriveTimesDistances.UseVisualStyleBackColor = True
        '
        'cboCityStateFlag
        '
        Me.cboCityStateFlag.FormattingEnabled = True
        Me.cboCityStateFlag.Items.AddRange(New Object() {"City", "State"})
        Me.cboCityStateFlag.Location = New System.Drawing.Point(136, 343)
        Me.cboCityStateFlag.Name = "cboCityStateFlag"
        Me.cboCityStateFlag.Size = New System.Drawing.Size(172, 21)
        Me.cboCityStateFlag.TabIndex = 27
        Me.cboCityStateFlag.Text = "City"
        '
        'rdoColumn
        '
        Me.rdoColumn.AutoSize = True
        Me.rdoColumn.Location = New System.Drawing.Point(173, 19)
        Me.rdoColumn.Name = "rdoColumn"
        Me.rdoColumn.Size = New System.Drawing.Size(65, 17)
        Me.rdoColumn.TabIndex = 1
        Me.rdoColumn.TabStop = True
        Me.rdoColumn.Text = "Columns"
        Me.rdoColumn.UseVisualStyleBackColor = True
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 98
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(134, 64)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(30, 23)
        Me.Button6.TabIndex = 10
        Me.Button6.Text = "X"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(185, 93)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(36, 23)
        Me.Button5.TabIndex = 9
        Me.Button5.Text = "SE"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(66, 93)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(36, 23)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "SW"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(185, 35)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(36, 23)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "NE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'grpINFO
        '
        Me.grpINFO.Controls.Add(Me.lblGeneratedOn)
        Me.grpINFO.Controls.Add(Me.Label10)
        Me.grpINFO.Controls.Add(Me.lblInterest)
        Me.grpINFO.Controls.Add(Me.lblPhones)
        Me.grpINFO.Controls.Add(Me.lblContact)
        Me.grpINFO.Controls.Add(Me.Label6)
        Me.grpINFO.Controls.Add(Me.lblPhone)
        Me.grpINFO.Controls.Add(Me.lblName)
        Me.grpINFO.Location = New System.Drawing.Point(121, 440)
        Me.grpINFO.Name = "grpINFO"
        Me.grpINFO.Size = New System.Drawing.Size(194, 231)
        Me.grpINFO.TabIndex = 17
        Me.grpINFO.TabStop = False
        Me.grpINFO.Text = "Quick Info:"
        '
        'lblGeneratedOn
        '
        Me.lblGeneratedOn.AutoSize = True
        Me.lblGeneratedOn.Location = New System.Drawing.Point(97, 140)
        Me.lblGeneratedOn.Name = "lblGeneratedOn"
        Me.lblGeneratedOn.Size = New System.Drawing.Size(10, 13)
        Me.lblGeneratedOn.TabIndex = 7
        Me.lblGeneratedOn.Text = " "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(11, 140)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Generated On: "
        '
        'lblInterest
        '
        Me.lblInterest.AutoSize = True
        Me.lblInterest.Location = New System.Drawing.Point(97, 102)
        Me.lblInterest.Name = "lblInterest"
        Me.lblInterest.Size = New System.Drawing.Size(10, 13)
        Me.lblInterest.TabIndex = 5
        Me.lblInterest.Text = " "
        '
        'lblPhones
        '
        Me.lblPhones.AutoSize = True
        Me.lblPhones.Location = New System.Drawing.Point(97, 64)
        Me.lblPhones.Name = "lblPhones"
        Me.lblPhones.Size = New System.Drawing.Size(10, 13)
        Me.lblPhones.TabIndex = 4
        Me.lblPhones.Text = " "
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Location = New System.Drawing.Point(97, 24)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(10, 13)
        Me.lblContact.TabIndex = 3
        Me.lblContact.Text = " "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Interested In:"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(12, 64)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(52, 13)
        Me.lblPhone.TabIndex = 1
        Me.lblPhone.Text = "Phone(s):"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(11, 24)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rdoColumn)
        Me.GroupBox4.Controls.Add(Me.rdoPie)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 296)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(305, 41)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Chart Type Options"
        '
        'rdoPie
        '
        Me.rdoPie.AutoSize = True
        Me.rdoPie.Location = New System.Drawing.Point(72, 19)
        Me.rdoPie.Name = "rdoPie"
        Me.rdoPie.Size = New System.Drawing.Size(40, 17)
        Me.rdoPie.TabIndex = 0
        Me.rdoPie.TabStop = True
        Me.rdoPie.Text = "Pie"
        Me.rdoPie.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 440)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Records Returned:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.tslblStatus, Me.tspbOperationProgress})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 708)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1125, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(42, 17)
        Me.ToolStripStatusLabel1.Text = "Status:"
        '
        'tslblStatus
        '
        Me.tslblStatus.Name = "tslblStatus"
        Me.tslblStatus.Size = New System.Drawing.Size(10, 17)
        Me.tslblStatus.Text = " "
        '
        'tspbOperationProgress
        '
        Me.tspbOperationProgress.Name = "tspbOperationProgress"
        Me.tspbOperationProgress.Size = New System.Drawing.Size(100, 16)
        '
        'axTarget
        '
        Me.axTarget.Enabled = True
        Me.axTarget.Location = New System.Drawing.Point(348, 0)
        Me.axTarget.Name = "axTarget"
        Me.axTarget.OcxState = CType(resources.GetObject("axTarget.OcxState"), System.Windows.Forms.AxHost.State)
        Me.axTarget.Size = New System.Drawing.Size(777, 706)
        Me.axTarget.TabIndex = 4
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.zoomIn)
        Me.GroupBox2.Controls.Add(Me.zoomOut)
        Me.GroupBox2.Controls.Add(Me.pnDown)
        Me.GroupBox2.Controls.Add(Me.pnUP)
        Me.GroupBox2.Controls.Add(Me.pnRight)
        Me.GroupBox2.Controls.Add(Me.pnLeft)
        Me.GroupBox2.Location = New System.Drawing.Point(10, 275)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(305, 142)
        Me.GroupBox2.TabIndex = 13
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Map Controls:"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(66, 35)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "NW"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'zoomIn
        '
        Me.zoomIn.Location = New System.Drawing.Point(170, 64)
        Me.zoomIn.Name = "zoomIn"
        Me.zoomIn.Size = New System.Drawing.Size(22, 23)
        Me.zoomIn.TabIndex = 5
        Me.zoomIn.Text = "+"
        Me.zoomIn.UseVisualStyleBackColor = True
        '
        'zoomOut
        '
        Me.zoomOut.Location = New System.Drawing.Point(101, 64)
        Me.zoomOut.Name = "zoomOut"
        Me.zoomOut.Size = New System.Drawing.Size(26, 23)
        Me.zoomOut.TabIndex = 4
        Me.zoomOut.Text = "-"
        Me.zoomOut.UseVisualStyleBackColor = True
        '
        'pnDown
        '
        Me.pnDown.Location = New System.Drawing.Point(111, 107)
        Me.pnDown.Name = "pnDown"
        Me.pnDown.Size = New System.Drawing.Size(68, 23)
        Me.pnDown.TabIndex = 3
        Me.pnDown.Text = "S"
        Me.pnDown.UseVisualStyleBackColor = True
        '
        'pnUP
        '
        Me.pnUP.Location = New System.Drawing.Point(111, 19)
        Me.pnUP.Name = "pnUP"
        Me.pnUP.Size = New System.Drawing.Size(68, 23)
        Me.pnUP.TabIndex = 2
        Me.pnUP.Text = "N"
        Me.pnUP.UseVisualStyleBackColor = True
        '
        'pnRight
        '
        Me.pnRight.Location = New System.Drawing.Point(202, 64)
        Me.pnRight.Name = "pnRight"
        Me.pnRight.Size = New System.Drawing.Size(64, 23)
        Me.pnRight.TabIndex = 1
        Me.pnRight.Text = "E"
        Me.pnRight.UseVisualStyleBackColor = True
        '
        'pnLeft
        '
        Me.pnLeft.Location = New System.Drawing.Point(27, 64)
        Me.pnLeft.Name = "pnLeft"
        Me.pnLeft.Size = New System.Drawing.Size(57, 23)
        Me.pnLeft.TabIndex = 0
        Me.pnLeft.Text = "W"
        Me.pnLeft.UseVisualStyleBackColor = True
        '
        'tbMain
        '
        Me.tbMain.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.tbMain.Controls.Add(Me.tbSingle)
        Me.tbMain.Controls.Add(Me.tbDataMaps)
        Me.tbMain.Controls.Add(Me.tbSalesAndMarketing)
        Me.tbMain.Controls.Add(Me.tbReferences)
        Me.tbMain.Controls.Add(Me.tbDriveTimesDistances)
        Me.tbMain.Location = New System.Drawing.Point(0, 0)
        Me.tbMain.Multiline = True
        Me.tbMain.Name = "tbMain"
        Me.tbMain.SelectedIndex = 0
        Me.tbMain.Size = New System.Drawing.Size(348, 685)
        Me.tbMain.TabIndex = 6
        '
        'tbSingle
        '
        Me.tbSingle.Controls.Add(Me.grpINFO)
        Me.tbSingle.Controls.Add(Me.Label5)
        Me.tbSingle.Controls.Add(Me.Label4)
        Me.tbSingle.Controls.Add(Me.lsFound)
        Me.tbSingle.Controls.Add(Me.GroupBox2)
        Me.tbSingle.Controls.Add(Me.lblPlotCount)
        Me.tbSingle.Controls.Add(Me.Label3)
        Me.tbSingle.Controls.Add(Me.nmNumRecords)
        Me.tbSingle.Controls.Add(Me.lblNumRecordsToPlot)
        Me.tbSingle.Controls.Add(Me.Label2)
        Me.tbSingle.Controls.Add(Me.Label1)
        Me.tbSingle.Controls.Add(Me.dtpEndSPR)
        Me.tbSingle.Controls.Add(Me.dtpBeginSPR)
        Me.tbSingle.Controls.Add(Me.cboMarketingSPR)
        Me.tbSingle.Controls.Add(Me.lblMarketing)
        Me.tbSingle.Controls.Add(Me.cboSalesSPR)
        Me.tbSingle.Controls.Add(Me.lblSales)
        Me.tbSingle.Controls.Add(Me.GroupBox1)
        Me.tbSingle.Location = New System.Drawing.Point(23, 4)
        Me.tbSingle.Name = "tbSingle"
        Me.tbSingle.Padding = New System.Windows.Forms.Padding(3)
        Me.tbSingle.Size = New System.Drawing.Size(321, 677)
        Me.tbSingle.TabIndex = 0
        Me.tbSingle.Text = "Single Result Plot"
        Me.tbSingle.UseVisualStyleBackColor = True
        '
        'lsFound
        '
        Me.lsFound.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colID})
        Me.lsFound.ContextMenuStrip = Me.ctxViewIn
        Me.lsFound.Location = New System.Drawing.Point(10, 459)
        Me.lsFound.Name = "lsFound"
        Me.lsFound.Size = New System.Drawing.Size(102, 212)
        Me.lsFound.TabIndex = 14
        Me.lsFound.UseCompatibleStateImageBehavior = False
        Me.lsFound.View = System.Windows.Forms.View.Details
        '
        'lblPlotCount
        '
        Me.lblPlotCount.AutoSize = True
        Me.lblPlotCount.Location = New System.Drawing.Point(108, 229)
        Me.lblPlotCount.Name = "lblPlotCount"
        Me.lblPlotCount.Size = New System.Drawing.Size(10, 13)
        Me.lblPlotCount.TabIndex = 12
        Me.lblPlotCount.Text = " "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Items Plotted: "
        '
        'nmNumRecords
        '
        Me.nmNumRecords.Location = New System.Drawing.Point(212, 200)
        Me.nmNumRecords.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nmNumRecords.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nmNumRecords.Name = "nmNumRecords"
        Me.nmNumRecords.Size = New System.Drawing.Size(103, 20)
        Me.nmNumRecords.TabIndex = 10
        Me.nmNumRecords.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'lblNumRecordsToPlot
        '
        Me.lblNumRecordsToPlot.AutoSize = True
        Me.lblNumRecordsToPlot.Location = New System.Drawing.Point(7, 202)
        Me.lblNumRecordsToPlot.Name = "lblNumRecordsToPlot"
        Me.lblNumRecordsToPlot.Size = New System.Drawing.Size(140, 13)
        Me.lblNumRecordsToPlot.TabIndex = 9
        Me.lblNumRecordsToPlot.Text = "Number Of Records To Get:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "End Date:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 92)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Begin Date:"
        '
        'dtpEndSPR
        '
        Me.dtpEndSPR.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpEndSPR.Location = New System.Drawing.Point(237, 111)
        Me.dtpEndSPR.Name = "dtpEndSPR"
        Me.dtpEndSPR.Size = New System.Drawing.Size(78, 20)
        Me.dtpEndSPR.TabIndex = 6
        '
        'dtpBeginSPR
        '
        Me.dtpBeginSPR.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpBeginSPR.Location = New System.Drawing.Point(237, 86)
        Me.dtpBeginSPR.Name = "dtpBeginSPR"
        Me.dtpBeginSPR.Size = New System.Drawing.Size(78, 20)
        Me.dtpBeginSPR.TabIndex = 5
        '
        'cboMarketingSPR
        '
        Me.cboMarketingSPR.Enabled = False
        Me.cboMarketingSPR.FormattingEnabled = True
        Me.cboMarketingSPR.Location = New System.Drawing.Point(111, 165)
        Me.cboMarketingSPR.Name = "cboMarketingSPR"
        Me.cboMarketingSPR.Size = New System.Drawing.Size(204, 21)
        Me.cboMarketingSPR.TabIndex = 4
        '
        'lblMarketing
        '
        Me.lblMarketing.AutoSize = True
        Me.lblMarketing.Enabled = False
        Me.lblMarketing.Location = New System.Drawing.Point(7, 169)
        Me.lblMarketing.Name = "lblMarketing"
        Me.lblMarketing.Size = New System.Drawing.Size(98, 13)
        Me.lblMarketing.TabIndex = 3
        Me.lblMarketing.Text = "Marketing Results: "
        '
        'cboSalesSPR
        '
        Me.cboSalesSPR.Enabled = False
        Me.cboSalesSPR.FormattingEnabled = True
        Me.cboSalesSPR.Location = New System.Drawing.Point(111, 138)
        Me.cboSalesSPR.Name = "cboSalesSPR"
        Me.cboSalesSPR.Size = New System.Drawing.Size(204, 21)
        Me.cboSalesSPR.TabIndex = 2
        '
        'lblSales
        '
        Me.lblSales.AutoSize = True
        Me.lblSales.Enabled = False
        Me.lblSales.Location = New System.Drawing.Point(7, 142)
        Me.lblSales.Name = "lblSales"
        Me.lblSales.Size = New System.Drawing.Size(77, 13)
        Me.lblSales.TabIndex = 1
        Me.lblSales.Text = "Sales Results: "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoPCs)
        Me.GroupBox1.Controls.Add(Me.rdoMarketing)
        Me.GroupBox1.Controls.Add(Me.rdoSales)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 9)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(312, 71)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Plot What Results"
        '
        'rdoPCs
        '
        Me.rdoPCs.AutoSize = True
        Me.rdoPCs.Location = New System.Drawing.Point(224, 32)
        Me.rdoPCs.Name = "rdoPCs"
        Me.rdoPCs.Size = New System.Drawing.Size(44, 17)
        Me.rdoPCs.TabIndex = 2
        Me.rdoPCs.TabStop = True
        Me.rdoPCs.Text = "PCs"
        Me.rdoPCs.UseVisualStyleBackColor = True
        '
        'rdoMarketing
        '
        Me.rdoMarketing.AutoSize = True
        Me.rdoMarketing.Location = New System.Drawing.Point(105, 32)
        Me.rdoMarketing.Name = "rdoMarketing"
        Me.rdoMarketing.Size = New System.Drawing.Size(110, 17)
        Me.rdoMarketing.TabIndex = 1
        Me.rdoMarketing.TabStop = True
        Me.rdoMarketing.Text = "Marketing Results"
        Me.rdoMarketing.UseVisualStyleBackColor = True
        '
        'rdoSales
        '
        Me.rdoSales.AutoSize = True
        Me.rdoSales.Location = New System.Drawing.Point(10, 32)
        Me.rdoSales.Name = "rdoSales"
        Me.rdoSales.Size = New System.Drawing.Size(89, 17)
        Me.rdoSales.TabIndex = 0
        Me.rdoSales.TabStop = True
        Me.rdoSales.Text = "Sales Results"
        Me.rdoSales.UseVisualStyleBackColor = True
        '
        'tbDataMaps
        '
        Me.tbDataMaps.Controls.Add(Me.GroupBox6)
        Me.tbDataMaps.Controls.Add(Me.grpDataOptionsSales)
        Me.tbDataMaps.Controls.Add(Me.GroupBox4)
        Me.tbDataMaps.Controls.Add(Me.cboCityStateFlag)
        Me.tbDataMaps.Controls.Add(Me.Label11)
        Me.tbDataMaps.Controls.Add(Me.cboTargetCity)
        Me.tbDataMaps.Controls.Add(Me.chkFocusTargetCity)
        Me.tbDataMaps.Controls.Add(Me.grpDataOptions)
        Me.tbDataMaps.Controls.Add(Me.btnGenDataMap)
        Me.tbDataMaps.Controls.Add(Me.GroupBox3)
        Me.tbDataMaps.Controls.Add(Me.Label7)
        Me.tbDataMaps.Controls.Add(Me.Label8)
        Me.tbDataMaps.Controls.Add(Me.dtpEndDM)
        Me.tbDataMaps.Controls.Add(Me.dtpBeginDM)
        Me.tbDataMaps.Location = New System.Drawing.Point(23, 4)
        Me.tbDataMaps.Name = "tbDataMaps"
        Me.tbDataMaps.Padding = New System.Windows.Forms.Padding(3)
        Me.tbDataMaps.Size = New System.Drawing.Size(321, 677)
        Me.tbDataMaps.TabIndex = 1
        Me.tbDataMaps.Text = "Data Maps"
        Me.tbDataMaps.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rdoMarketingDM)
        Me.GroupBox6.Controls.Add(Me.rdoSalesDM)
        Me.GroupBox6.Location = New System.Drawing.Point(10, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(151, 42)
        Me.GroupBox6.TabIndex = 29
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Sales Or Marketing ?"
        '
        'rdoMarketingDM
        '
        Me.rdoMarketingDM.AutoSize = True
        Me.rdoMarketingDM.Location = New System.Drawing.Point(57, 20)
        Me.rdoMarketingDM.Name = "rdoMarketingDM"
        Me.rdoMarketingDM.Size = New System.Drawing.Size(72, 17)
        Me.rdoMarketingDM.TabIndex = 1
        Me.rdoMarketingDM.TabStop = True
        Me.rdoMarketingDM.Text = "Marketing"
        Me.rdoMarketingDM.UseVisualStyleBackColor = True
        '
        'rdoSalesDM
        '
        Me.rdoSalesDM.AutoSize = True
        Me.rdoSalesDM.Location = New System.Drawing.Point(7, 20)
        Me.rdoSalesDM.Name = "rdoSalesDM"
        Me.rdoSalesDM.Size = New System.Drawing.Size(51, 17)
        Me.rdoSalesDM.TabIndex = 0
        Me.rdoSalesDM.TabStop = True
        Me.rdoSalesDM.Text = "Sales"
        Me.rdoSalesDM.UseVisualStyleBackColor = True
        '
        'grpDataOptionsSales
        '
        Me.grpDataOptionsSales.Controls.Add(Me.chkNotHitSales)
        Me.grpDataOptionsSales.Controls.Add(Me.chkNoDemoSales)
        Me.grpDataOptionsSales.Controls.Add(Me.chkDemoNoSale)
        Me.grpDataOptionsSales.Controls.Add(Me.chkBankRejectedSales)
        Me.grpDataOptionsSales.Controls.Add(Me.chkLostResultSale)
        Me.grpDataOptionsSales.Controls.Add(Me.chkSalesSale)
        Me.grpDataOptionsSales.Controls.Add(Me.chkRecissionCancel)
        Me.grpDataOptionsSales.Controls.Add(Me.chkResetSales)
        Me.grpDataOptionsSales.Controls.Add(Me.chkSalesNotIssued)
        Me.grpDataOptionsSales.Location = New System.Drawing.Point(6, 178)
        Me.grpDataOptionsSales.Name = "grpDataOptionsSales"
        Me.grpDataOptionsSales.Size = New System.Drawing.Size(305, 112)
        Me.grpDataOptionsSales.TabIndex = 22
        Me.grpDataOptionsSales.TabStop = False
        Me.grpDataOptionsSales.Text = "Data To Plot: Sales Results"
        '
        'chkNotHitSales
        '
        Me.chkNotHitSales.AutoSize = True
        Me.chkNotHitSales.Location = New System.Drawing.Point(217, 20)
        Me.chkNotHitSales.Name = "chkNotHitSales"
        Me.chkNotHitSales.Size = New System.Drawing.Size(59, 17)
        Me.chkNotHitSales.TabIndex = 8
        Me.chkNotHitSales.Text = "Not Hit"
        Me.chkNotHitSales.UseVisualStyleBackColor = True
        '
        'chkNoDemoSales
        '
        Me.chkNoDemoSales.AutoSize = True
        Me.chkNoDemoSales.Location = New System.Drawing.Point(113, 89)
        Me.chkNoDemoSales.Name = "chkNoDemoSales"
        Me.chkNoDemoSales.Size = New System.Drawing.Size(71, 17)
        Me.chkNoDemoSales.TabIndex = 7
        Me.chkNoDemoSales.Text = "No Demo"
        Me.chkNoDemoSales.UseVisualStyleBackColor = True
        '
        'chkDemoNoSale
        '
        Me.chkDemoNoSale.AutoSize = True
        Me.chkDemoNoSale.Location = New System.Drawing.Point(113, 43)
        Me.chkDemoNoSale.Name = "chkDemoNoSale"
        Me.chkDemoNoSale.Size = New System.Drawing.Size(97, 17)
        Me.chkDemoNoSale.TabIndex = 6
        Me.chkDemoNoSale.Text = "Demo/No Sale"
        Me.chkDemoNoSale.UseVisualStyleBackColor = True
        '
        'chkBankRejectedSales
        '
        Me.chkBankRejectedSales.AutoSize = True
        Me.chkBankRejectedSales.Location = New System.Drawing.Point(113, 20)
        Me.chkBankRejectedSales.Name = "chkBankRejectedSales"
        Me.chkBankRejectedSales.Size = New System.Drawing.Size(97, 17)
        Me.chkBankRejectedSales.TabIndex = 5
        Me.chkBankRejectedSales.Text = "Bank Rejected"
        Me.chkBankRejectedSales.UseVisualStyleBackColor = True
        '
        'chkLostResultSale
        '
        Me.chkLostResultSale.AutoSize = True
        Me.chkLostResultSale.Location = New System.Drawing.Point(113, 66)
        Me.chkLostResultSale.Name = "chkLostResultSale"
        Me.chkLostResultSale.Size = New System.Drawing.Size(84, 17)
        Me.chkLostResultSale.TabIndex = 4
        Me.chkLostResultSale.Text = "Lost Results"
        Me.chkLostResultSale.UseVisualStyleBackColor = True
        '
        'chkSalesSale
        '
        Me.chkSalesSale.AutoSize = True
        Me.chkSalesSale.Location = New System.Drawing.Point(6, 89)
        Me.chkSalesSale.Name = "chkSalesSale"
        Me.chkSalesSale.Size = New System.Drawing.Size(47, 17)
        Me.chkSalesSale.TabIndex = 3
        Me.chkSalesSale.Text = "Sale"
        Me.chkSalesSale.UseVisualStyleBackColor = True
        '
        'chkRecissionCancel
        '
        Me.chkRecissionCancel.AutoSize = True
        Me.chkRecissionCancel.Location = New System.Drawing.Point(7, 66)
        Me.chkRecissionCancel.Name = "chkRecissionCancel"
        Me.chkRecissionCancel.Size = New System.Drawing.Size(108, 17)
        Me.chkRecissionCancel.TabIndex = 2
        Me.chkRecissionCancel.Text = "Recission Cancel"
        Me.chkRecissionCancel.UseVisualStyleBackColor = True
        '
        'chkResetSales
        '
        Me.chkResetSales.AutoSize = True
        Me.chkResetSales.Location = New System.Drawing.Point(7, 43)
        Me.chkResetSales.Name = "chkResetSales"
        Me.chkResetSales.Size = New System.Drawing.Size(54, 17)
        Me.chkResetSales.TabIndex = 1
        Me.chkResetSales.Text = "Reset"
        Me.chkResetSales.UseVisualStyleBackColor = True
        '
        'chkSalesNotIssued
        '
        Me.chkSalesNotIssued.AutoSize = True
        Me.chkSalesNotIssued.Location = New System.Drawing.Point(7, 20)
        Me.chkSalesNotIssued.Name = "chkSalesNotIssued"
        Me.chkSalesNotIssued.Size = New System.Drawing.Size(77, 17)
        Me.chkSalesNotIssued.TabIndex = 0
        Me.chkSalesNotIssued.Text = "Not Issued"
        Me.chkSalesNotIssued.UseVisualStyleBackColor = True
        '
        'frmMappointEX
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1125, 730)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.axTarget)
        Me.Controls.Add(Me.tbMain)
        Me.Name = "frmMappointEX"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mappoint Tools"
        Me.tbSalesAndMarketing.ResumeLayout(False)
        Me.tbSalesAndMarketing.PerformLayout()
        CType(Me.nmRadiusPlot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.ctxViewIn.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.nmPvsSRecords, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDataOptions.ResumeLayout(False)
        Me.grpDataOptions.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.grpINFO.ResumeLayout(False)
        Me.grpINFO.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.axTarget, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.tbMain.ResumeLayout(False)
        Me.tbSingle.ResumeLayout(False)
        Me.tbSingle.PerformLayout()
        CType(Me.nmNumRecords, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tbDataMaps.ResumeLayout(False)
        Me.tbDataMaps.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.grpDataOptionsSales.ResumeLayout(False)
        Me.grpDataOptionsSales.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnXReference As System.Windows.Forms.Button
    Friend WithEvents btnGenerateRadius As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents ttCTXMenu As System.Windows.Forms.ToolTip
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbSalesAndMarketing As System.Windows.Forms.TabPage
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents nmRadiusPlot As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkSecondaryDataSet As System.Windows.Forms.CheckedListBox
    Friend WithEvents chkListPrimaryDataSet As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents lsRadiusFound As System.Windows.Forms.ListView
    Friend WithEvents colIDSandMRadius As System.Windows.Forms.ColumnHeader
    Friend WithEvents ctxViewIn As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SalesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MarketingManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FinanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InstallationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConfirmingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WarmCallingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SeparateMapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents nmPvsSRecords As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dtpPvsSEnd As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents dtpPvsSBegin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtpEndDM As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpBeginDM As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents bgPlotPriDSETS As System.ComponentModel.BackgroundWorker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cboTargetCity As System.Windows.Forms.ComboBox
    Friend WithEvents chkFocusTargetCity As System.Windows.Forms.CheckBox
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents grpDataOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkNotHit As System.Windows.Forms.CheckBox
    Friend WithEvents chkCandC As System.Windows.Forms.CheckBox
    Friend WithEvents chkConfirmed As System.Windows.Forms.CheckBox
    Friend WithEvents chkKill As System.Windows.Forms.CheckBox
    Friend WithEvents chkReset As System.Windows.Forms.CheckBox
    Friend WithEvents chkNotIssued As System.Windows.Forms.CheckBox
    Friend WithEvents chkUnconfirmed As System.Windows.Forms.CheckBox
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnGenDataMap As System.Windows.Forms.Button
    Friend WithEvents tbReferences As System.Windows.Forms.TabPage
    Friend WithEvents bgGetDataSet As System.ComponentModel.BackgroundWorker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents bgPlotDataSet As System.ComponentModel.BackgroundWorker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents bgDM As System.ComponentModel.BackgroundWorker
    Friend WithEvents bgDMSalesResults As System.ComponentModel.BackgroundWorker
    Friend WithEvents tbDriveTimesDistances As System.Windows.Forms.TabPage
    Friend WithEvents bgPlotSecDSETS As System.ComponentModel.BackgroundWorker
    Friend WithEvents cboCityStateFlag As System.Windows.Forms.ComboBox
    Friend WithEvents rdoColumn As System.Windows.Forms.RadioButton
    Friend WithEvents colID As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents grpINFO As System.Windows.Forms.GroupBox
    Friend WithEvents lblGeneratedOn As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblInterest As System.Windows.Forms.Label
    Friend WithEvents lblPhones As System.Windows.Forms.Label
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoPie As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tslblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tspbOperationProgress As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents axTarget As AxMapPoint.AxMappointControl
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents zoomIn As System.Windows.Forms.Button
    Friend WithEvents zoomOut As System.Windows.Forms.Button
    Friend WithEvents pnDown As System.Windows.Forms.Button
    Friend WithEvents pnUP As System.Windows.Forms.Button
    Friend WithEvents pnRight As System.Windows.Forms.Button
    Friend WithEvents pnLeft As System.Windows.Forms.Button
    Friend WithEvents tbMain As System.Windows.Forms.TabControl
    Friend WithEvents tbSingle As System.Windows.Forms.TabPage
    Friend WithEvents lsFound As System.Windows.Forms.ListView
    Friend WithEvents lblPlotCount As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents nmNumRecords As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblNumRecordsToPlot As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpEndSPR As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpBeginSPR As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboMarketingSPR As System.Windows.Forms.ComboBox
    Friend WithEvents lblMarketing As System.Windows.Forms.Label
    Friend WithEvents cboSalesSPR As System.Windows.Forms.ComboBox
    Friend WithEvents lblSales As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoPCs As System.Windows.Forms.RadioButton
    Friend WithEvents rdoMarketing As System.Windows.Forms.RadioButton
    Friend WithEvents rdoSales As System.Windows.Forms.RadioButton
    Friend WithEvents tbDataMaps As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoMarketingDM As System.Windows.Forms.RadioButton
    Friend WithEvents rdoSalesDM As System.Windows.Forms.RadioButton
    Friend WithEvents grpDataOptionsSales As System.Windows.Forms.GroupBox
    Friend WithEvents chkNotHitSales As System.Windows.Forms.CheckBox
    Friend WithEvents chkNoDemoSales As System.Windows.Forms.CheckBox
    Friend WithEvents chkDemoNoSale As System.Windows.Forms.CheckBox
    Friend WithEvents chkBankRejectedSales As System.Windows.Forms.CheckBox
    Friend WithEvents chkLostResultSale As System.Windows.Forms.CheckBox
    Friend WithEvents chkSalesSale As System.Windows.Forms.CheckBox
    Friend WithEvents chkRecissionCancel As System.Windows.Forms.CheckBox
    Friend WithEvents chkResetSales As System.Windows.Forms.CheckBox
    Friend WithEvents chkSalesNotIssued As System.Windows.Forms.CheckBox
End Class
